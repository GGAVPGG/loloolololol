.class final LE1/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LE1/d;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LE1/d;

    invoke-direct {v0}, LE1/d;-><init>()V

    sput-object v0, LE1/d;->a:LE1/d;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
