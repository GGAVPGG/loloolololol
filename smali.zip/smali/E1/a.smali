.class public final LE1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD1/b;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LD1/q;LD1/o;LH1/n;LD9/e;)Ljava/lang/Object;
    .locals 0

    new-instance p0, LD1/b$b;

    invoke-direct {p0, p1}, LD1/b$b;-><init>(LD1/q;)V

    return-object p0
.end method

.method public b(LD1/q;LD1/o;LD1/q;LH1/n;LD9/e;)Ljava/lang/Object;
    .locals 11

    invoke-virtual {p3}, LD1/q;->d()I

    move-result p0

    const/16 p2, 0x130

    if-ne p0, p2, :cond_0

    if-eqz p1, :cond_0

    invoke-virtual {p1}, LD1/q;->e()LD1/n;

    move-result-object p0

    invoke-virtual {p3}, LD1/q;->e()LD1/n;

    move-result-object p1

    invoke-static {p0, p1}, LE1/e;->d(LD1/n;LD1/n;)LD1/n;

    move-result-object v6

    new-instance p0, LD1/b$c;

    const/16 v9, 0x27

    const/4 v10, 0x0

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v0, p3

    invoke-static/range {v0 .. v10}, LD1/q;->b(LD1/q;IJJLD1/n;LD1/r;Ljava/lang/Object;ILjava/lang/Object;)LD1/q;

    move-result-object p1

    invoke-direct {p0, p1}, LD1/b$c;-><init>(LD1/q;)V

    return-object p0

    :cond_0
    new-instance p0, LD1/b$c;

    invoke-direct {p0, p3}, LD1/b$c;-><init>(LD1/q;)V

    return-object p0
.end method
