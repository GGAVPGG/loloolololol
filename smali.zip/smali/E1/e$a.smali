.class final LE1/e$a;
.super LF9/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LE1/e;->e(LD1/r;LD9/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field i:Ljava/lang/Object;

.field j:Ljava/lang/Object;

.field synthetic k:Ljava/lang/Object;

.field l:I


# direct methods
.method constructor <init>(LD9/e;)V
    .locals 0

    invoke-direct {p0, p1}, LF9/d;-><init>(LD9/e;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, LE1/e$a;->k:Ljava/lang/Object;

    iget p1, p0, LE1/e$a;->l:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LE1/e$a;->l:I

    const/4 p1, 0x0

    invoke-static {p1, p0}, LE1/e;->e(LD1/r;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
