.class public abstract LE1/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(Lkotlin/jvm/functions/Function1;)LE1/b;
    .locals 1

    new-instance v0, LE1/b;

    invoke-direct {v0, p0}, LE1/b;-><init>(Lkotlin/jvm/functions/Function1;)V

    return-object v0
.end method
