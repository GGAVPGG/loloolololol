.class public final enum LD/b;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum f:LD/b;

.field public static final enum g:LD/b;

.field public static final enum h:LD/b;

.field public static final enum i:LD/b;

.field private static final synthetic j:[LD/b;

.field private static final synthetic k:Lkotlin/enums/EnumEntries;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, LD/b;

    const-string v1, "DYNAMIC_RANGE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, LD/b;-><init>(Ljava/lang/String;I)V

    sput-object v0, LD/b;->f:LD/b;

    new-instance v0, LD/b;

    const-string v1, "FPS_RANGE"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, LD/b;-><init>(Ljava/lang/String;I)V

    sput-object v0, LD/b;->g:LD/b;

    new-instance v0, LD/b;

    const-string v1, "VIDEO_STABILIZATION"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, LD/b;-><init>(Ljava/lang/String;I)V

    sput-object v0, LD/b;->h:LD/b;

    new-instance v0, LD/b;

    const-string v1, "IMAGE_FORMAT"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, LD/b;-><init>(Ljava/lang/String;I)V

    sput-object v0, LD/b;->i:LD/b;

    invoke-static {}, LD/b;->c()[LD/b;

    move-result-object v0

    sput-object v0, LD/b;->j:[LD/b;

    invoke-static {v0}, LG9/a;->a([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, LD/b;->k:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static final synthetic c()[LD/b;
    .locals 4

    sget-object v0, LD/b;->f:LD/b;

    sget-object v1, LD/b;->g:LD/b;

    sget-object v2, LD/b;->h:LD/b;

    sget-object v3, LD/b;->i:LD/b;

    filled-new-array {v0, v1, v2, v3}, [LD/b;

    move-result-object v0

    return-object v0
.end method

.method public static d()Lkotlin/enums/EnumEntries;
    .locals 1

    sget-object v0, LD/b;->k:Lkotlin/enums/EnumEntries;

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LD/b;
    .locals 1

    const-class v0, LD/b;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LD/b;

    return-object p0
.end method

.method public static values()[LD/b;
    .locals 1

    sget-object v0, LD/b;->j:[LD/b;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LD/b;

    return-object v0
.end method
