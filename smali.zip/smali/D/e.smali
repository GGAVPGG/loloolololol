.class public final LD/e;
.super LB/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD/e$a;,
        LD/e$b;
    }
.end annotation


# static fields
.field public static final i:LD/e$a;

.field public static final j:LD/e$b;


# instance fields
.field private final g:LD/e$b;

.field private final h:LD/b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LD/e$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD/e$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LD/e;->i:LD/e$a;

    sget-object v0, LD/e$b;->f:LD/e$b;

    sput-object v0, LD/e;->j:LD/e$b;

    return-void
.end method

.method public constructor <init>(LD/e$b;)V
    .locals 1

    const-string v0, "mode"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, LB/b;-><init>()V

    iput-object p1, p0, LD/e;->g:LD/e$b;

    sget-object p1, LD/b;->h:LD/b;

    iput-object p1, p0, LD/e;->h:LD/b;

    return-void
.end method


# virtual methods
.method public c()LD/b;
    .locals 0

    iget-object p0, p0, LD/e;->h:LD/b;

    return-object p0
.end method

.method public final f()LD/e$b;
    .locals 0

    iget-object p0, p0, LD/e;->g:LD/e$b;

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "VideoStabilizationFeature(mode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, LD/e;->g:LD/e$b;

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
