.class public final LD/c;
.super LB/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD/c$a;
    }
.end annotation


# static fields
.field public static final j:LD/c$a;

.field public static final k:Landroid/util/Range;


# instance fields
.field private final g:I

.field private final h:I

.field private final i:LD/b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LD/c$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD/c$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LD/c;->j:LD/c$a;

    new-instance v0, Landroid/util/Range;

    const/16 v1, 0x1e

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-direct {v0, v1, v1}, Landroid/util/Range;-><init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V

    sput-object v0, LD/c;->k:Landroid/util/Range;

    return-void
.end method

.method public constructor <init>(II)V
    .locals 0

    invoke-direct {p0}, LB/b;-><init>()V

    iput p1, p0, LD/c;->g:I

    iput p2, p0, LD/c;->h:I

    sget-object p1, LD/b;->g:LD/b;

    iput-object p1, p0, LD/c;->i:LD/b;

    return-void
.end method


# virtual methods
.method public c()LD/b;
    .locals 0

    iget-object p0, p0, LD/c;->i:LD/b;

    return-object p0
.end method

.method public final f()I
    .locals 0

    iget p0, p0, LD/c;->h:I

    return p0
.end method

.method public final g()I
    .locals 0

    iget p0, p0, LD/c;->g:I

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "FpsRangeFeature(minFps="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LD/c;->g:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", maxFps="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, LD/c;->h:I

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
