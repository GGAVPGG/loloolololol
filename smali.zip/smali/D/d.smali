.class public final LD/d;
.super LB/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD/d$a;
    }
.end annotation


# static fields
.field public static final i:LD/d$a;


# instance fields
.field private final g:I

.field private final h:LD/b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LD/d$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD/d$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LD/d;->i:LD/d$a;

    return-void
.end method

.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, LB/b;-><init>()V

    iput p1, p0, LD/d;->g:I

    sget-object p1, LD/b;->i:LD/b;

    iput-object p1, p0, LD/d;->h:LD/b;

    return-void
.end method

.method private final g()Ljava/lang/String;
    .locals 2

    iget v0, p0, LD/d;->g:I

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "UNDEFINED("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, LD/d;->g:I

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-string p0, "JPEG_R"

    return-object p0

    :cond_1
    const-string p0, "JPEG"

    return-object p0
.end method


# virtual methods
.method public c()LD/b;
    .locals 0

    iget-object p0, p0, LD/d;->h:LD/b;

    return-object p0
.end method

.method public final f()I
    .locals 0

    iget p0, p0, LD/d;->g:I

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "ImageFormatFeature(imageCaptureOutputFormat="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {p0}, LD/d;->g()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
