.class public final synthetic LE4/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/M$b;


# instance fields
.field public final synthetic a:LE4/M;

.field public final synthetic b:Ljava/util/List;

.field public final synthetic c:Lw4/o;


# direct methods
.method public synthetic constructor <init>(LE4/M;Ljava/util/List;Lw4/o;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE4/v;->a:LE4/M;

    iput-object p2, p0, LE4/v;->b:Ljava/util/List;

    iput-object p3, p0, LE4/v;->c:Lw4/o;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LE4/v;->a:LE4/M;

    iget-object v1, p0, LE4/v;->b:Ljava/util/List;

    iget-object p0, p0, LE4/v;->c:Lw4/o;

    check-cast p1, Landroid/database/Cursor;

    invoke-static {v0, v1, p0, p1}, LE4/M;->c2(LE4/M;Ljava/util/List;Lw4/o;Landroid/database/Cursor;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
