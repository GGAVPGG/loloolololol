.class public interface abstract LE4/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# virtual methods
.method public abstract I(Ljava/lang/Iterable;)V
.end method

.method public abstract J(Lw4/o;)Z
.end method

.method public abstract L1(Lw4/o;Lw4/i;)LE4/k;
.end method

.method public abstract O1(Lw4/o;J)V
.end method

.method public abstract R1(Ljava/lang/Iterable;)V
.end method

.method public abstract e1(Lw4/o;)Ljava/lang/Iterable;
.end method

.method public abstract k1(Lw4/o;)J
.end method

.method public abstract l0()Ljava/lang/Iterable;
.end method

.method public abstract o()I
.end method
