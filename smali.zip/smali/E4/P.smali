.class public final synthetic LE4/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/U$a;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 0

    invoke-static {p1}, LE4/U;->t(Landroid/database/sqlite/SQLiteDatabase;)V

    return-void
.end method
