.class public final LE4/N;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/b;


# instance fields
.field private final a:Ljavax/inject/Provider;

.field private final b:Ljavax/inject/Provider;

.field private final c:Ljavax/inject/Provider;

.field private final d:Ljavax/inject/Provider;

.field private final e:Ljavax/inject/Provider;


# direct methods
.method public constructor <init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE4/N;->a:Ljavax/inject/Provider;

    iput-object p2, p0, LE4/N;->b:Ljavax/inject/Provider;

    iput-object p3, p0, LE4/N;->c:Ljavax/inject/Provider;

    iput-object p4, p0, LE4/N;->d:Ljavax/inject/Provider;

    iput-object p5, p0, LE4/N;->e:Ljavax/inject/Provider;

    return-void
.end method

.method public static a(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)LE4/N;
    .locals 6

    new-instance v0, LE4/N;

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, LE4/N;-><init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V

    return-object v0
.end method

.method public static c(LG4/a;LG4/a;Ljava/lang/Object;Ljava/lang/Object;Ljavax/inject/Provider;)LE4/M;
    .locals 6

    new-instance v0, LE4/M;

    move-object v3, p2

    check-cast v3, LE4/e;

    move-object v4, p3

    check-cast v4, LE4/U;

    move-object v1, p0

    move-object v2, p1

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, LE4/M;-><init>(LG4/a;LG4/a;LE4/e;LE4/U;Ljavax/inject/Provider;)V

    return-object v0
.end method


# virtual methods
.method public b()LE4/M;
    .locals 4

    iget-object v0, p0, LE4/N;->a:Ljavax/inject/Provider;

    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LG4/a;

    iget-object v1, p0, LE4/N;->b:Ljavax/inject/Provider;

    invoke-interface {v1}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LG4/a;

    iget-object v2, p0, LE4/N;->c:Ljavax/inject/Provider;

    invoke-interface {v2}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v2

    iget-object v3, p0, LE4/N;->d:Ljavax/inject/Provider;

    invoke-interface {v3}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v3

    iget-object p0, p0, LE4/N;->e:Ljavax/inject/Provider;

    invoke-static {v0, v1, v2, v3, p0}, LE4/N;->c(LG4/a;LG4/a;Ljava/lang/Object;Ljava/lang/Object;Ljavax/inject/Provider;)LE4/M;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, LE4/N;->b()LE4/M;

    move-result-object p0

    return-object p0
.end method
