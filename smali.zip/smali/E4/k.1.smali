.class public abstract LE4/k;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(JLw4/o;Lw4/i;)LE4/k;
    .locals 1

    new-instance v0, LE4/b;

    invoke-direct {v0, p0, p1, p2, p3}, LE4/b;-><init>(JLw4/o;Lw4/i;)V

    return-object v0
.end method


# virtual methods
.method public abstract b()Lw4/i;
.end method

.method public abstract c()J
.end method

.method public abstract d()Lw4/o;
.end method
