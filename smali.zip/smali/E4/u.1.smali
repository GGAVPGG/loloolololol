.class public final synthetic LE4/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/M$b;


# instance fields
.field public final synthetic a:LE4/M;


# direct methods
.method public synthetic constructor <init>(LE4/M;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE4/u;->a:LE4/M;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LE4/u;->a:LE4/M;

    check-cast p1, Landroid/database/Cursor;

    invoke-static {p0, p1}, LE4/M;->a0(LE4/M;Landroid/database/Cursor;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
