.class public final synthetic LE4/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/M$d;


# instance fields
.field public final synthetic a:LE4/U;


# direct methods
.method public synthetic constructor <init>(LE4/U;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE4/E;->a:LE4/U;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LE4/E;->a:LE4/U;

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    return-object p0
.end method
