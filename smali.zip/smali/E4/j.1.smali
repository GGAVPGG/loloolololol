.class public final LE4/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LE4/j$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()LE4/j;
    .locals 1

    invoke-static {}, LE4/j$a;->a()LE4/j;

    move-result-object v0

    return-object v0
.end method

.method public static c()LE4/e;
    .locals 2

    invoke-static {}, LE4/f;->d()LE4/e;

    move-result-object v0

    const-string v1, "Cannot return null from a non-@Nullable @Provides method"

    invoke-static {v0, v1}, Ly4/d;->c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LE4/e;

    return-object v0
.end method


# virtual methods
.method public b()LE4/e;
    .locals 0

    invoke-static {}, LE4/j;->c()LE4/e;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, LE4/j;->b()LE4/e;

    move-result-object p0

    return-object p0
.end method
