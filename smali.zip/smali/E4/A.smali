.class public final synthetic LE4/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/M$b;


# instance fields
.field public final synthetic a:LE4/M;

.field public final synthetic b:Ljava/util/Map;

.field public final synthetic c:Lz4/a$a;


# direct methods
.method public synthetic constructor <init>(LE4/M;Ljava/util/Map;Lz4/a$a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE4/A;->a:LE4/M;

    iput-object p2, p0, LE4/A;->b:Ljava/util/Map;

    iput-object p3, p0, LE4/A;->c:Lz4/a$a;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LE4/A;->a:LE4/M;

    iget-object v1, p0, LE4/A;->b:Ljava/util/Map;

    iget-object p0, p0, LE4/A;->c:Lz4/a$a;

    check-cast p1, Landroid/database/Cursor;

    invoke-static {v0, v1, p0, p1}, LE4/M;->c1(LE4/M;Ljava/util/Map;Lz4/a$a;Landroid/database/Cursor;)Lz4/a;

    move-result-object p0

    return-object p0
.end method
