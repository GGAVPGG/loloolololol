.class abstract LE4/i$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE4/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# static fields
.field private static final a:LE4/i;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LE4/i;

    invoke-direct {v0}, LE4/i;-><init>()V

    sput-object v0, LE4/i$a;->a:LE4/i;

    return-void
.end method

.method static synthetic a()LE4/i;
    .locals 1

    sget-object v0, LE4/i$a;->a:LE4/i;

    return-object v0
.end method
