.class public final synthetic LE4/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE4/M$b;


# instance fields
.field public final synthetic a:LE4/M;

.field public final synthetic b:Lw4/i;

.field public final synthetic c:Lw4/o;


# direct methods
.method public synthetic constructor <init>(LE4/M;Lw4/i;Lw4/o;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE4/m;->a:LE4/M;

    iput-object p2, p0, LE4/m;->b:Lw4/i;

    iput-object p3, p0, LE4/m;->c:Lw4/o;

    return-void
.end method


# virtual methods
.method public final apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LE4/m;->a:LE4/M;

    iget-object v1, p0, LE4/m;->b:Lw4/i;

    iget-object p0, p0, LE4/m;->c:Lw4/o;

    check-cast p1, Landroid/database/sqlite/SQLiteDatabase;

    invoke-static {v0, v1, p0, p1}, LE4/M;->l1(LE4/M;Lw4/i;Lw4/o;Landroid/database/sqlite/SQLiteDatabase;)Ljava/lang/Long;

    move-result-object p0

    return-object p0
.end method
