.class public final LC2/b$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC2/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LC2/b$a;-><init>()V

    return-void
.end method

.method public static final synthetic a(LC2/b$a;Lc2/a;)Lc2/a;
    .locals 0

    invoke-direct {p0, p1}, LC2/b$a;->c(Lc2/a;)Lc2/a;

    move-result-object p0

    return-object p0
.end method

.method private final c(Lc2/a;)Lc2/a;
    .locals 1

    sget-object p0, Le3/o;->d:Le3/p;

    const/4 v0, 0x0

    invoke-static {p1, p0, v0}, Le3/f;->U1(Lc2/a;Le3/p;I)Le3/f;

    move-result-object p0

    const-string p1, "of(...)"

    invoke-static {p0, p1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0}, Lc2/a;->g1(Ljava/io/Closeable;)Lc2/a;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final b(Lc2/a;)Lc2/a;
    .locals 1

    :try_start_0
    invoke-static {p1}, Lc2/a;->c1(Lc2/a;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {p1}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object p0

    instance-of p0, p0, Le3/f;

    if-eqz p0, :cond_0

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object p0

    const-string v0, "null cannot be cast to non-null type com.facebook.imagepipeline.image.CloseableStaticBitmap"

    invoke-static {p0, v0}, LO9/l;->e(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, Le3/f;

    invoke-interface {p0}, Le3/f;->T()Lc2/a;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {p1}, Lc2/a;->a0(Lc2/a;)V

    return-object p0

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    invoke-static {p1}, Lc2/a;->a0(Lc2/a;)V

    const/4 p0, 0x0

    return-object p0

    :goto_0
    invoke-static {p1}, Lc2/a;->a0(Lc2/a;)V

    throw p0
.end method
