.class public final LC2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB2/b;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 0

    return-void
.end method

.method public t(I)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public u(III)Lc2/a;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public v(ILc2/a;I)V
    .locals 0

    const-string p0, "bitmapReference"

    invoke-static {p2, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method

.method public w(I)Lc2/a;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public x(I)Lc2/a;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public y(ILc2/a;I)V
    .locals 0

    const-string p0, "bitmapReference"

    invoke-static {p2, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    return-void
.end method
