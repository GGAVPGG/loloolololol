.class public final LB0/a$d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LB0/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field private final a:LB0/a$e;


# direct methods
.method public constructor <init>(LB0/a$e;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/a$d;->a:LB0/a$e;

    return-void
.end method


# virtual methods
.method public a()LB0/a$e;
    .locals 0

    iget-object p0, p0, LB0/a$d;->a:LB0/a$e;

    return-object p0
.end method
