.class LB0/a$a;
.super Landroid/hardware/fingerprint/FingerprintManager$AuthenticationCallback;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB0/a;->h(LB0/a$c;)Landroid/hardware/fingerprint/FingerprintManager$AuthenticationCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LB0/a$c;


# direct methods
.method constructor <init>(LB0/a$c;)V
    .locals 0

    iput-object p1, p0, LB0/a$a;->a:LB0/a$c;

    invoke-direct {p0}, Landroid/hardware/fingerprint/FingerprintManager$AuthenticationCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAuthenticationError(ILjava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, LB0/a$a;->a:LB0/a$c;

    invoke-virtual {p0, p1, p2}, LB0/a$c;->a(ILjava/lang/CharSequence;)V

    return-void
.end method

.method public onAuthenticationFailed()V
    .locals 0

    iget-object p0, p0, LB0/a$a;->a:LB0/a$c;

    invoke-virtual {p0}, LB0/a$c;->b()V

    return-void
.end method

.method public onAuthenticationHelp(ILjava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, LB0/a$a;->a:LB0/a$c;

    invoke-virtual {p0, p1, p2}, LB0/a$c;->c(ILjava/lang/CharSequence;)V

    return-void
.end method

.method public onAuthenticationSucceeded(Landroid/hardware/fingerprint/FingerprintManager$AuthenticationResult;)V
    .locals 1

    iget-object p0, p0, LB0/a$a;->a:LB0/a$c;

    new-instance v0, LB0/a$d;

    invoke-static {p1}, LB0/a$b;->b(Ljava/lang/Object;)Landroid/hardware/fingerprint/FingerprintManager$CryptoObject;

    move-result-object p1

    invoke-static {p1}, LB0/a;->g(Landroid/hardware/fingerprint/FingerprintManager$CryptoObject;)LB0/a$e;

    move-result-object p1

    invoke-direct {v0, p1}, LB0/a$d;-><init>(LB0/a$e;)V

    invoke-virtual {p0, v0}, LB0/a$c;->d(LB0/a$d;)V

    return-void
.end method
