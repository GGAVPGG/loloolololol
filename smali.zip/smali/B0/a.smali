.class public LB0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LB0/a$b;,
        LB0/a$e;,
        LB0/a$c;,
        LB0/a$d;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB0/a;->a:Landroid/content/Context;

    return-void
.end method

.method public static c(Landroid/content/Context;)LB0/a;
    .locals 1

    new-instance v0, LB0/a;

    invoke-direct {v0, p0}, LB0/a;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method private static d(Landroid/content/Context;)Landroid/hardware/fingerprint/FingerprintManager;
    .locals 0

    invoke-static {p0}, LB0/a$b;->c(Landroid/content/Context;)Landroid/hardware/fingerprint/FingerprintManager;

    move-result-object p0

    return-object p0
.end method

.method static g(Landroid/hardware/fingerprint/FingerprintManager$CryptoObject;)LB0/a$e;
    .locals 0

    invoke-static {p0}, LB0/a$b;->f(Ljava/lang/Object;)LB0/a$e;

    move-result-object p0

    return-object p0
.end method

.method private static h(LB0/a$c;)Landroid/hardware/fingerprint/FingerprintManager$AuthenticationCallback;
    .locals 1

    new-instance v0, LB0/a$a;

    invoke-direct {v0, p0}, LB0/a$a;-><init>(LB0/a$c;)V

    return-object v0
.end method

.method private static i(LB0/a$e;)Landroid/hardware/fingerprint/FingerprintManager$CryptoObject;
    .locals 0

    invoke-static {p0}, LB0/a$b;->g(LB0/a$e;)Landroid/hardware/fingerprint/FingerprintManager$CryptoObject;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public a(LB0/a$e;ILE0/c;LB0/a$c;Landroid/os/Handler;)V
    .locals 6

    if-eqz p3, :cond_0

    invoke-virtual {p3}, LE0/c;->b()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/os/CancellationSignal;

    :goto_0
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    goto :goto_1

    :cond_0
    const/4 p3, 0x0

    goto :goto_0

    :goto_1
    invoke-virtual/range {v0 .. v5}, LB0/a;->b(LB0/a$e;ILandroid/os/CancellationSignal;LB0/a$c;Landroid/os/Handler;)V

    return-void
.end method

.method public b(LB0/a$e;ILandroid/os/CancellationSignal;LB0/a$c;Landroid/os/Handler;)V
    .locals 6

    iget-object p0, p0, LB0/a;->a:Landroid/content/Context;

    invoke-static {p0}, LB0/a;->d(Landroid/content/Context;)Landroid/hardware/fingerprint/FingerprintManager;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {p1}, LB0/a;->i(LB0/a$e;)Landroid/hardware/fingerprint/FingerprintManager$CryptoObject;

    move-result-object v1

    invoke-static {p4}, LB0/a;->h(LB0/a$c;)Landroid/hardware/fingerprint/FingerprintManager$AuthenticationCallback;

    move-result-object v4

    move v3, p2

    move-object v2, p3

    move-object v5, p5

    invoke-static/range {v0 .. v5}, LB0/a$b;->a(Ljava/lang/Object;Ljava/lang/Object;Landroid/os/CancellationSignal;ILjava/lang/Object;Landroid/os/Handler;)V

    :cond_0
    return-void
.end method

.method public e()Z
    .locals 0

    iget-object p0, p0, LB0/a;->a:Landroid/content/Context;

    invoke-static {p0}, LB0/a;->d(Landroid/content/Context;)Landroid/hardware/fingerprint/FingerprintManager;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-static {p0}, LB0/a$b;->d(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public f()Z
    .locals 0

    iget-object p0, p0, LB0/a;->a:Landroid/content/Context;

    invoke-static {p0}, LB0/a;->d(Landroid/content/Context;)Landroid/hardware/fingerprint/FingerprintManager;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-static {p0}, LB0/a$b;->e(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method
