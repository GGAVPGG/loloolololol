.class public interface abstract LF4/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF4/b$a;
    }
.end annotation


# virtual methods
.method public abstract d(LF4/b$a;)Ljava/lang/Object;
.end method
