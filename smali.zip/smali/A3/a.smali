.class public final LA3/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LA3/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LA3/a;

    invoke-direct {v0}, LA3/a;-><init>()V

    sput-object v0, LA3/a;->a:LA3/a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final a(Lxb/A;Ljava/lang/Object;)V
    .locals 3

    const-string v0, "client"

    invoke-static {p0, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "tag"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, Lxb/A;->d()Lxb/p;

    move-result-object p0

    invoke-virtual {p0}, Lxb/p;->j()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lxb/e;

    invoke-interface {v1}, Lxb/e;->z()Lxb/C;

    move-result-object v2

    invoke-virtual {v2}, Lxb/C;->l()Ljava/lang/Object;

    move-result-object v2

    invoke-static {p1, v2}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Lxb/e;->cancel()V

    return-void

    :cond_1
    invoke-virtual {p0}, Lxb/p;->k()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_2
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lxb/e;

    invoke-interface {v0}, Lxb/e;->z()Lxb/C;

    move-result-object v1

    invoke-virtual {v1}, Lxb/C;->l()Ljava/lang/Object;

    move-result-object v1

    invoke-static {p1, v1}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Lxb/e;->cancel()V

    :cond_3
    return-void
.end method
