.class public abstract LA2/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA2/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LA2/b$a;
    }
.end annotation


# static fields
.field public static final e:LA2/b$a;


# instance fields
.field private a:LA2/a;

.field private b:I

.field private c:Landroid/graphics/ColorFilter;

.field private d:Landroid/graphics/Rect;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LA2/b$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LA2/b$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LA2/b;->e:LA2/b$a;

    return-void
.end method

.method public constructor <init>(LA2/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LA2/b;->a:LA2/a;

    const/4 p1, -0x1

    iput p1, p0, LA2/b;->b:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, -0x1

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/a;->a()I

    move-result p0

    return p0
.end method

.method public b(Landroid/graphics/Rect;)V
    .locals 1

    const-string v0, "bounds"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LA2/b;->a:LA2/a;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, LA2/a;->b(Landroid/graphics/Rect;)V

    :cond_0
    iput-object p1, p0, LA2/b;->d:Landroid/graphics/Rect;

    return-void
.end method

.method public c()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/d;->c()I

    move-result p0

    return p0
.end method

.method public clear()V
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-eqz p0, :cond_0

    invoke-interface {p0}, LA2/a;->clear()V

    :cond_0
    return-void
.end method

.method public d()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/d;->d()I

    move-result p0

    return p0
.end method

.method public e()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, -0x1

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/a;->e()I

    move-result p0

    return p0
.end method

.method public g(LA2/a$a;)V
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-eqz p0, :cond_0

    invoke-interface {p0, p1}, LA2/a;->g(LA2/a$a;)V

    :cond_0
    return-void
.end method

.method public h(Landroid/graphics/ColorFilter;)V
    .locals 1

    iget-object v0, p0, LA2/b;->a:LA2/a;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, LA2/a;->h(Landroid/graphics/ColorFilter;)V

    :cond_0
    iput-object p1, p0, LA2/b;->c:Landroid/graphics/ColorFilter;

    return-void
.end method

.method public i()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/d;->i()I

    move-result p0

    return p0
.end method

.method public j()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/d;->j()I

    move-result p0

    return p0
.end method

.method public k(I)I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0, p1}, LA2/d;->k(I)I

    move-result p0

    return p0
.end method

.method public l(I)V
    .locals 1

    iget-object v0, p0, LA2/b;->a:LA2/a;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, LA2/a;->l(I)V

    :cond_0
    iput p1, p0, LA2/b;->b:I

    return-void
.end method

.method public m()I
    .locals 0

    iget-object p0, p0, LA2/b;->a:LA2/a;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    invoke-interface {p0}, LA2/d;->m()I

    move-result p0

    return p0
.end method

.method public n(Landroid/graphics/drawable/Drawable;Landroid/graphics/Canvas;I)Z
    .locals 1

    const-string v0, "parent"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "canvas"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, LA2/b;->a:LA2/a;

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    invoke-interface {p0, p1, p2, p3}, LA2/a;->n(Landroid/graphics/drawable/Drawable;Landroid/graphics/Canvas;I)Z

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_0

    return p1

    :cond_0
    return v0
.end method
