.class LA2/c$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LA2/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic f:LA2/c;


# direct methods
.method constructor <init>(LA2/c;)V
    .locals 0

    iput-object p1, p0, LA2/c$a;->f:LA2/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    iget-object v0, p0, LA2/c$a;->f:LA2/c;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, LA2/c$a;->f:LA2/c;

    const/4 v2, 0x0

    invoke-static {v1, v2}, LA2/c;->o(LA2/c;Z)V

    iget-object v1, p0, LA2/c$a;->f:LA2/c;

    invoke-static {v1}, LA2/c;->p(LA2/c;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, LA2/c$a;->f:LA2/c;

    invoke-static {v1}, LA2/c;->f(LA2/c;)LA2/c$b;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object p0, p0, LA2/c$a;->f:LA2/c;

    invoke-static {p0}, LA2/c;->f(LA2/c;)LA2/c$b;

    move-result-object p0

    invoke-interface {p0}, LA2/c$b;->f()V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    iget-object p0, p0, LA2/c$a;->f:LA2/c;

    invoke-static {p0}, LA2/c;->q(LA2/c;)V

    :cond_1
    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method
