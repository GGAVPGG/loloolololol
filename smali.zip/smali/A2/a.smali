.class public interface abstract LA2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA2/d;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LA2/a$a;
    }
.end annotation


# virtual methods
.method public abstract a()I
.end method

.method public abstract b(Landroid/graphics/Rect;)V
.end method

.method public abstract clear()V
.end method

.method public abstract e()I
.end method

.method public abstract g(LA2/a$a;)V
.end method

.method public abstract h(Landroid/graphics/ColorFilter;)V
.end method

.method public abstract l(I)V
.end method

.method public abstract n(Landroid/graphics/drawable/Drawable;Landroid/graphics/Canvas;I)Z
.end method
