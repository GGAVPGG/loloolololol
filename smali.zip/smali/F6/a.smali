.class public interface abstract LF6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LN4/i;


# virtual methods
.method public abstract n()Lv5/l;
.end method
