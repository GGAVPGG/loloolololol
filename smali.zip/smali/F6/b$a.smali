.class public LF6/b$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF6/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private a:I

.field private b:Z

.field private c:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, LF6/b$a;->a:I

    return-void
.end method


# virtual methods
.method public a()LF6/b;
    .locals 4

    new-instance v0, LF6/b;

    iget v1, p0, LF6/b$a;->a:I

    iget-boolean v2, p0, LF6/b$a;->b:Z

    iget-boolean p0, p0, LF6/b$a;->c:Z

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2, p0, v3}, LF6/b;-><init>(IZZLF6/d;)V

    return-object v0
.end method

.method public varargs b(I[I)LF6/b$a;
    .locals 3

    iput p1, p0, LF6/b$a;->a:I

    array-length p1, p2

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p1, :cond_0

    aget v1, p2, v0

    iget v2, p0, LF6/b$a;->a:I

    or-int/2addr v1, v2

    iput v1, p0, LF6/b$a;->a:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-object p0
.end method
