.class public abstract LF6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/content/Context;LF6/b;)LF6/a;
    .locals 1

    new-instance v0, LG6/e;

    invoke-direct {v0, p0, p1}, LG6/e;-><init>(Landroid/content/Context;LF6/b;)V

    return-object v0
.end method
