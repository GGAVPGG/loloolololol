.class public abstract LF1/b;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static synthetic a()LD1/i;
    .locals 1

    invoke-static {}, LF1/b;->b()LD1/i;

    move-result-object v0

    return-object v0
.end method

.method private static final b()LD1/i;
    .locals 1

    new-instance v0, Lxb/A;

    invoke-direct {v0}, Lxb/A;-><init>()V

    invoke-static {v0}, LF1/b;->c(Lxb/e$a;)LD1/i;

    move-result-object v0

    return-object v0
.end method

.method public static final c(Lxb/e$a;)LD1/i;
    .locals 0

    invoke-static {p0}, LG1/a;->c(Lxb/e$a;)Lxb/e$a;

    move-result-object p0

    invoke-static {p0}, LG1/a;->b(Lxb/e$a;)LG1/a;

    move-result-object p0

    return-object p0
.end method

.method public static final d()LD1/m$a;
    .locals 6

    new-instance v0, LD1/m$a;

    new-instance v1, LF1/a;

    invoke-direct {v1}, LF1/a;-><init>()V

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct/range {v0 .. v5}, LD1/m$a;-><init>(LN9/a;LN9/a;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method
