.class public final LE/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LE/a$a;
    }
.end annotation


# static fields
.field private static final b:LE/a$a;


# instance fields
.field private final a:LG/L;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LE/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LE/a$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LE/a;->b:LE/a$a;

    return-void
.end method

.method public constructor <init>(LG/L;)V
    .locals 1

    const-string v0, "cameraInfoInternal"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE/a;->a:LG/L;

    return-void
.end method

.method private final b(Lz/v0;Ljava/util/List;ILjava/util/List;)LE/b;
    .locals 2

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    if-lt p3, v0, :cond_1

    invoke-virtual {p1}, Lz/v0;->h()Ljava/util/Set;

    move-result-object p2

    invoke-static {p2, p4}, Lz9/U;->j(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p2

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string p4, "getFeatureListResolvedByPriority: features = "

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p4, ", useCases = "

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lz/v0;->k()Ljava/util/List;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const-string p4, "DefaultFeatureGroupResolver"

    invoke-static {p4, p3}, Lz/h0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p0, p0, LE/a;->a:LG/L;

    new-instance p3, LC/b;

    invoke-direct {p3, p2}, LC/b;-><init>(Ljava/util/Set;)V

    invoke-interface {p0, p3, p1}, LG/L;->j(LC/b;Lz/v0;)Z

    move-result p0

    if-eqz p0, :cond_0

    new-instance p0, LE/b$a;

    new-instance p1, LC/b;

    invoke-direct {p1, p2}, LC/b;-><init>(Ljava/util/Set;)V

    invoke-direct {p0, p1}, LE/b$a;-><init>(LC/b;)V

    return-object p0

    :cond_0
    sget-object p0, LE/b$b;->a:LE/b$b;

    return-object p0

    :cond_1
    add-int/lit8 v0, p3, 0x1

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    invoke-static {p4, p3}, Lz9/q;->C0(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/List;

    move-result-object p3

    invoke-direct {p0, p1, p2, v0, p3}, LE/a;->b(Lz/v0;Ljava/util/List;ILjava/util/List;)LE/b;

    move-result-object p3

    instance-of v1, p3, LE/b$a;

    if-eqz v1, :cond_2

    return-object p3

    :cond_2
    invoke-direct {p0, p1, p2, v0, p4}, LE/a;->b(Lz/v0;Ljava/util/List;ILjava/util/List;)LE/b;

    move-result-object p0

    return-object p0
.end method

.method static synthetic c(LE/a;Lz/v0;Ljava/util/List;ILjava/util/List;ILjava/lang/Object;)LE/b;
    .locals 0

    and-int/lit8 p6, p5, 0x4

    if-eqz p6, :cond_0

    const/4 p3, 0x0

    :cond_0
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_1

    invoke-static {}, Lz9/q;->k()Ljava/util/List;

    move-result-object p4

    :cond_1
    invoke-direct {p0, p1, p2, p3, p4}, LE/a;->b(Lz/v0;Ljava/util/List;ILjava/util/List;)LE/b;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public a(Lz/v0;)LE/b;
    .locals 9

    const-string v0, "sessionConfig"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, Lz/v0;->k()Ljava/util/List;

    move-result-object v0

    invoke-virtual {p1}, Lz/v0;->h()Ljava/util/Set;

    move-result-object v1

    invoke-virtual {p1}, Lz/v0;->g()Ljava/util/List;

    move-result-object v2

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Must have at least one required or preferred feature"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_3

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    :cond_2
    move v5, v4

    goto :goto_1

    :cond_3
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lz/J0;

    instance-of v6, v6, Lz/V;

    if-eqz v6, :cond_4

    move v5, v3

    :goto_1
    if-eqz v0, :cond_5

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_5

    goto :goto_2

    :cond_5
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_6
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_8

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lz/J0;

    instance-of v8, v7, Lz/p0;

    if-nez v8, :cond_7

    invoke-static {v7}, LL/f;->e0(Lz/J0;)Z

    move-result v7

    if-eqz v7, :cond_6

    :cond_7
    move v4, v3

    :cond_8
    :goto_2
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_9
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lz/J0;

    sget-object v7, LC/c;->h:LC/c$a;

    invoke-virtual {v7, v6}, LC/c$a;->c(Lz/J0;)LC/c;

    move-result-object v7

    sget-object v8, LC/c;->m:LC/c;

    if-ne v7, v8, :cond_9

    new-instance p0, LE/b$c;

    invoke-direct {p0, v6}, LE/b$c;-><init>(Lz/J0;)V

    return-object p0

    :cond_a
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LB/b;

    instance-of v6, v1, LD/d;

    if-eqz v6, :cond_c

    if-nez v5, :cond_b

    new-instance p0, LE/b$d;

    sget-object p1, LC/c;->j:LC/c;

    invoke-virtual {p1}, LC/c;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v1}, LE/b$d;-><init>(Ljava/lang/String;LB/b;)V

    return-object p0

    :cond_c
    instance-of v6, v1, LD/a;

    if-nez v6, :cond_d

    instance-of v6, v1, LD/c;

    if-nez v6, :cond_d

    instance-of v6, v1, LD/e;

    if-eqz v6, :cond_b

    :cond_d
    if-nez v4, :cond_b

    new-instance p0, LE/b$d;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v0, LC/c;->i:LC/c;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " or "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, LC/c;->k:LC/c;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v1}, LE/b$d;-><init>(Ljava/lang/String;LB/b;)V

    return-object p0

    :cond_e
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_f
    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_11

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, LB/b;

    instance-of v2, v2, LD/d;

    if-eqz v2, :cond_10

    move v2, v5

    goto :goto_4

    :cond_10
    move v2, v3

    :goto_4
    if-eqz v2, :cond_f

    invoke-interface {v4, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_11
    const/16 v7, 0xc

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    move-object v3, p1

    invoke-static/range {v2 .. v8}, LE/a;->c(LE/a;Lz/v0;Ljava/util/List;ILjava/util/List;ILjava/lang/Object;)LE/b;

    move-result-object p0

    return-object p0
.end method
