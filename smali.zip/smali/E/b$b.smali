.class public final LE/b$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LE/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field public static final a:LE/b$b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LE/b$b;

    invoke-direct {v0}, LE/b$b;-><init>()V

    sput-object v0, LE/b$b;->a:LE/b$b;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
