.class public final LA1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA1/c;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;LH1/n;)Ljava/lang/String;
    .locals 0

    check-cast p1, Lv1/C;

    invoke-virtual {p0, p1, p2}, LA1/d;->b(Lv1/C;LH1/n;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public b(Lv1/C;LH1/n;)Ljava/lang/String;
    .locals 0

    invoke-virtual {p1}, Lv1/C;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
