.class public final LA1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA1/c;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;LH1/n;)Ljava/lang/String;
    .locals 0

    check-cast p1, Lv1/C;

    invoke-virtual {p0, p1, p2}, LA1/b;->b(Lv1/C;LH1/n;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public b(Lv1/C;LH1/n;)Ljava/lang/String;
    .locals 4

    invoke-static {p1}, LN1/C;->l(Lv1/C;)Z

    move-result p0

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    invoke-static {p2}, LH1/g;->a(LH1/n;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {p1}, Lv1/D;->d(Lv1/C;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p2}, LH1/n;->g()LNb/o;

    move-result-object p2

    sget-object v1, LNb/F;->g:LNb/F$a;

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v1, p0, v2, v3, v0}, LNb/F$a;->e(LNb/F$a;Ljava/lang/String;ZILjava/lang/Object;)LNb/F;

    move-result-object p0

    invoke-virtual {p2, p0}, LNb/o;->l(LNb/F;)LNb/n;

    move-result-object p0

    invoke-virtual {p0}, LNb/n;->c()Ljava/lang/Long;

    move-result-object p0

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p1, 0x2d

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v0
.end method
