.class public final LD2/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD2/a;


# instance fields
.field private final a:LA2/d;

.field private final b:LB2/c;

.field private final c:LF2/k;

.field private final d:Z

.field private final e:Ljava/lang/String;

.field private final f:I

.field private final g:I

.field private h:LF2/j;

.field private final i:I

.field private j:I

.field private final k:LD2/f$a;


# direct methods
.method public constructor <init>(Ljava/lang/String;LA2/d;LB2/c;LF2/k;Z)V
    .locals 1

    const-string v0, "animationInformation"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapFrameRenderer"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "frameLoaderFactory"

    invoke-static {p4, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LD2/f;->a:LA2/d;

    iput-object p3, p0, LD2/f;->b:LB2/c;

    iput-object p4, p0, LD2/f;->c:LF2/k;

    iput-boolean p5, p0, LD2/f;->d:Z

    if-nez p1, :cond_0

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    :cond_0
    iput-object p1, p0, LD2/f;->e:Ljava/lang/String;

    invoke-interface {p2}, LA2/d;->m()I

    move-result p1

    iput p1, p0, LD2/f;->f:I

    invoke-interface {p2}, LA2/d;->i()I

    move-result p1

    iput p1, p0, LD2/f;->g:I

    invoke-direct {p0, p2}, LD2/f;->l(LA2/d;)I

    move-result p1

    iput p1, p0, LD2/f;->i:I

    iput p1, p0, LD2/f;->j:I

    new-instance p1, LD2/f$a;

    invoke-direct {p1, p0}, LD2/f$a;-><init>(LD2/f;)V

    iput-object p1, p0, LD2/f;->k:LD2/f$a;

    return-void
.end method

.method public static synthetic f()Ly9/A;
    .locals 1

    invoke-static {}, LD2/f;->n()Ly9/A;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic g(LD2/f;)I
    .locals 0

    iget p0, p0, LD2/f;->j:I

    return p0
.end method

.method public static final synthetic h(LD2/f;)LF2/j;
    .locals 0

    invoke-direct {p0}, LD2/f;->m()LF2/j;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic i(LD2/f;)I
    .locals 0

    iget p0, p0, LD2/f;->i:I

    return p0
.end method

.method public static final synthetic j(LD2/f;I)V
    .locals 0

    iput p1, p0, LD2/f;->j:I

    return-void
.end method

.method private final k(II)LD2/g;
    .locals 5

    iget-boolean v0, p0, LD2/f;->d:Z

    if-nez v0, :cond_0

    new-instance p1, LD2/g;

    iget p2, p0, LD2/f;->f:I

    iget p0, p0, LD2/f;->g:I

    invoke-direct {p1, p2, p0}, LD2/g;-><init>(II)V

    return-object p1

    :cond_0
    iget v0, p0, LD2/f;->f:I

    iget p0, p0, LD2/f;->g:I

    if-lt p1, v0, :cond_1

    if-ge p2, p0, :cond_3

    :cond_1
    int-to-double v1, v0

    int-to-double v3, p0

    div-double/2addr v1, v3

    if-le p2, p1, :cond_2

    invoke-static {p2, p0}, LU9/g;->h(II)I

    move-result p0

    int-to-double p1, p0

    mul-double/2addr p1, v1

    double-to-int v0, p1

    goto :goto_0

    :cond_2
    invoke-static {p1, v0}, LU9/g;->h(II)I

    move-result v0

    int-to-double p0, v0

    div-double/2addr p0, v1

    double-to-int p0, p0

    :cond_3
    :goto_0
    new-instance p1, LD2/g;

    invoke-direct {p1, v0, p0}, LD2/g;-><init>(II)V

    return-object p1
.end method

.method private final l(LA2/d;)I
    .locals 4

    sget-object p0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v0, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v2

    invoke-interface {p1}, LA2/d;->j()I

    move-result p0

    invoke-interface {p1}, LA2/d;->c()I

    move-result p1

    div-int/2addr p0, p1

    int-to-long p0, p0

    div-long/2addr v2, p0

    invoke-static {v2, v3, v0, v1}, LU9/g;->e(JJ)J

    move-result-wide p0

    long-to-int p0, p0

    return p0
.end method

.method private final m()LF2/j;
    .locals 4

    iget-object v0, p0, LD2/f;->h:LF2/j;

    if-nez v0, :cond_0

    iget-object v0, p0, LD2/f;->c:LF2/k;

    iget-object v1, p0, LD2/f;->e:Ljava/lang/String;

    iget-object v2, p0, LD2/f;->b:LB2/c;

    iget-object v3, p0, LD2/f;->a:LA2/d;

    invoke-virtual {v0, v1, v2, v3}, LF2/k;->b(Ljava/lang/String;LB2/c;LA2/d;)LF2/j;

    move-result-object v0

    iput-object v0, p0, LD2/f;->h:LF2/j;

    :cond_0
    iget-object p0, p0, LD2/f;->h:LF2/j;

    return-object p0
.end method

.method private static final n()Ly9/A;
    .locals 1

    sget-object v0, Ly9/A;->a:Ly9/A;

    return-object v0
.end method


# virtual methods
.method public a()V
    .locals 1

    invoke-direct {p0}, LD2/f;->m()LF2/j;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-interface {v0}, LF2/j;->a()V

    :cond_0
    invoke-virtual {p0}, LD2/f;->d()V

    return-void
.end method

.method public b(IILN9/a;)V
    .locals 1

    if-lez p1, :cond_2

    if-lez p2, :cond_2

    iget v0, p0, LD2/f;->f:I

    if-lez v0, :cond_2

    iget v0, p0, LD2/f;->g:I

    if-gtz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1, p2}, LD2/f;->k(II)LD2/g;

    move-result-object p1

    invoke-direct {p0}, LD2/f;->m()LF2/j;

    move-result-object p0

    if-eqz p0, :cond_2

    invoke-virtual {p1}, LD2/g;->b()I

    move-result p2

    invoke-virtual {p1}, LD2/g;->b()I

    move-result p1

    if-nez p3, :cond_1

    new-instance p3, LD2/e;

    invoke-direct {p3}, LD2/e;-><init>()V

    :cond_1
    invoke-interface {p0, p2, p1, p3}, LF2/j;->b(IILN9/a;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public c(III)Lc2/a;
    .locals 2

    invoke-direct {p0, p2, p3}, LD2/f;->k(II)LD2/g;

    move-result-object p2

    invoke-direct {p0}, LD2/f;->m()LF2/j;

    move-result-object p3

    const/4 v0, 0x0

    if-eqz p3, :cond_0

    invoke-virtual {p2}, LD2/g;->b()I

    move-result v1

    invoke-virtual {p2}, LD2/g;->a()I

    move-result p2

    invoke-interface {p3, p1, v1, p2}, LF2/j;->c(III)LF2/l;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v0

    :goto_0
    if-eqz p1, :cond_1

    sget-object p2, LF2/e;->a:LF2/e;

    iget-object p0, p0, LD2/f;->k:LD2/f$a;

    invoke-virtual {p2, p0, p1}, LF2/e;->h(LF2/i;LF2/l;)V

    :cond_1
    if-eqz p1, :cond_2

    invoke-virtual {p1}, LF2/l;->a()Lc2/a;

    move-result-object p0

    return-object p0

    :cond_2
    return-object v0
.end method

.method public d()V
    .locals 3

    invoke-direct {p0}, LD2/f;->m()LF2/j;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v1, LF2/k;->d:LF2/k$a;

    iget-object v2, p0, LD2/f;->e:Ljava/lang/String;

    invoke-virtual {v1, v2, v0}, LF2/k$a;->b(Ljava/lang/String;LF2/j;)V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, LD2/f;->h:LF2/j;

    return-void
.end method

.method public e(LD2/b;LB2/b;LA2/a;ILN9/a;)V
    .locals 0

    invoke-static/range {p0 .. p5}, LD2/a$a;->e(LD2/a;LD2/b;LB2/b;LA2/a;ILN9/a;)V

    return-void
.end method
