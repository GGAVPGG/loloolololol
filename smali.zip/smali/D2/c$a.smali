.class final LD2/c$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD2/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation


# instance fields
.field private final f:LA2/a;

.field private final g:LB2/b;

.field private final h:I

.field private final i:I

.field final synthetic j:LD2/c;


# direct methods
.method public constructor <init>(LD2/c;LA2/a;LB2/b;II)V
    .locals 1

    const-string v0, "animationBackend"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapFrameCache"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object p1, p0, LD2/c$a;->j:LD2/c;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, LD2/c$a;->f:LA2/a;

    iput-object p3, p0, LD2/c$a;->g:LB2/b;

    iput p4, p0, LD2/c$a;->h:I

    iput p5, p0, LD2/c$a;->i:I

    return-void
.end method

.method private final a(II)Z
    .locals 7

    const/4 v0, 0x1

    const/4 v1, -0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq p2, v0, :cond_1

    const/4 v0, 0x0

    if-eq p2, v2, :cond_0

    invoke-static {v3}, Lc2/a;->a0(Lc2/a;)V

    return v0

    :cond_0
    :try_start_0
    iget-object v2, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v2}, LD2/c;->e(LD2/c;)LW2/d;

    move-result-object v2

    iget-object v4, p0, LD2/c$a;->f:LA2/a;

    invoke-interface {v4}, LA2/a;->e()I

    move-result v4

    iget-object v5, p0, LD2/c$a;->f:LA2/a;

    invoke-interface {v5}, LA2/a;->a()I

    move-result v5

    iget-object v6, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v6}, LD2/c;->b(LD2/c;)Landroid/graphics/Bitmap$Config;

    move-result-object v6

    invoke-virtual {v2, v4, v5, v6}, LW2/d;->b(IILandroid/graphics/Bitmap$Config;)Lc2/a;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move v2, v1

    :goto_0
    move-object v3, v0

    goto :goto_1

    :catchall_0
    move-exception p0

    goto :goto_3

    :catch_0
    move-exception p1

    :try_start_1
    iget-object p0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {p0}, LD2/c;->f(LD2/c;)Ljava/lang/Class;

    move-result-object p0

    const-string p2, "Failed to create frame bitmap"

    invoke-static {p0, p2, p1}, LZ1/a;->F(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-static {v3}, Lc2/a;->a0(Lc2/a;)V

    return v0

    :cond_1
    :try_start_2
    iget-object v0, p0, LD2/c$a;->g:LB2/b;

    iget-object v4, p0, LD2/c$a;->f:LA2/a;

    invoke-interface {v4}, LA2/a;->e()I

    move-result v4

    iget-object v5, p0, LD2/c$a;->f:LA2/a;

    invoke-interface {v5}, LA2/a;->a()I

    move-result v5

    invoke-interface {v0, p1, v4, v5}, LB2/b;->u(III)Lc2/a;

    move-result-object v0

    goto :goto_0

    :goto_1
    invoke-direct {p0, p1, v3, p2}, LD2/c$a;->b(ILc2/a;I)Z

    move-result p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-static {v3}, Lc2/a;->a0(Lc2/a;)V

    if-nez p2, :cond_3

    if-ne v2, v1, :cond_2

    goto :goto_2

    :cond_2
    invoke-direct {p0, p1, v2}, LD2/c$a;->a(II)Z

    move-result p0

    return p0

    :cond_3
    :goto_2
    return p2

    :goto_3
    invoke-static {v3}, Lc2/a;->a0(Lc2/a;)V

    throw p0
.end method

.method private final b(ILc2/a;I)Z
    .locals 4

    invoke-static {p2}, Lc2/a;->c1(Lc2/a;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    if-eqz p2, :cond_2

    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->c(LD2/c;)LB2/c;

    move-result-object v0

    invoke-virtual {p2}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v2

    const-string v3, "get(...)"

    invoke-static {v2, v3}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/graphics/Bitmap;

    invoke-interface {v0, p1, v2}, LB2/c;->c(ILandroid/graphics/Bitmap;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->f(LD2/c;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "Frame %d ready."

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v0, v1, v2}, LZ1/a;->y(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V

    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v0

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, LD2/c$a;->g:LB2/b;

    invoke-interface {p0, p1, p2, p3}, LB2/b;->v(ILc2/a;I)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    const/4 p0, 0x1

    return p0

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0

    :cond_2
    :goto_0
    return v1
.end method


# virtual methods
.method public run()V
    .locals 3

    :try_start_0
    iget-object v0, p0, LD2/c$a;->g:LB2/b;

    iget v1, p0, LD2/c$a;->h:I

    invoke-interface {v0, v1}, LB2/b;->t(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->f(LD2/c;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "Frame %d is cached already."

    iget v2, p0, LD2/c$a;->h:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v0, v1, v2}, LZ1/a;->y(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v0

    iget-object v1, p0, LD2/c$a;->j:LD2/c;

    monitor-enter v0

    :try_start_1
    invoke-static {v1}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v1

    iget p0, p0, LD2/c$a;->i:I

    invoke-virtual {v1, p0}, Landroid/util/SparseArray;->remove(I)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0

    :catchall_1
    move-exception v0

    goto :goto_1

    :cond_0
    :try_start_2
    iget v0, p0, LD2/c$a;->h:I

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, LD2/c$a;->a(II)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->f(LD2/c;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "Prepared frame %d."

    iget v2, p0, LD2/c$a;->h:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v0, v1, v2}, LZ1/a;->y(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->f(LD2/c;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "Could not prepare frame %d."

    iget v2, p0, LD2/c$a;->h:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v0, v1, v2}, LZ1/a;->k(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :goto_0
    iget-object v0, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v0}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v0

    iget-object v1, p0, LD2/c$a;->j:LD2/c;

    monitor-enter v0

    :try_start_3
    invoke-static {v1}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v1

    iget p0, p0, LD2/c$a;->i:I

    invoke-virtual {v1, p0}, Landroid/util/SparseArray;->remove(I)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    monitor-exit v0

    return-void

    :catchall_2
    move-exception p0

    monitor-exit v0

    throw p0

    :goto_1
    iget-object v1, p0, LD2/c$a;->j:LD2/c;

    invoke-static {v1}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v1

    iget-object v2, p0, LD2/c$a;->j:LD2/c;

    monitor-enter v1

    :try_start_4
    invoke-static {v2}, LD2/c;->d(LD2/c;)Landroid/util/SparseArray;

    move-result-object v2

    iget p0, p0, LD2/c$a;->i:I

    invoke-virtual {v2, p0}, Landroid/util/SparseArray;->remove(I)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    monitor-exit v1

    throw v0

    :catchall_3
    move-exception p0

    monitor-exit v1

    throw p0
.end method
