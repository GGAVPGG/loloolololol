.class public final LD2/f$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF2/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD2/f;-><init>(Ljava/lang/String;LA2/d;LB2/c;LF2/k;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field private final a:I

.field final synthetic b:LD2/f;


# direct methods
.method constructor <init>(LD2/f;)V
    .locals 0

    iput-object p1, p0, LD2/f$a;->b:LD2/f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, LD2/f;->i(LD2/f;)I

    move-result p1

    iput p1, p0, LD2/f$a;->a:I

    return-void
.end method


# virtual methods
.method public a()I
    .locals 0

    iget p0, p0, LD2/f$a;->a:I

    return p0
.end method

.method public b()I
    .locals 0

    iget-object p0, p0, LD2/f$a;->b:LD2/f;

    invoke-static {p0}, LD2/f;->g(LD2/f;)I

    move-result p0

    return p0
.end method

.method public c(I)V
    .locals 3

    iget-object v0, p0, LD2/f$a;->b:LD2/f;

    invoke-static {v0}, LD2/f;->g(LD2/f;)I

    move-result v0

    if-eq p1, v0, :cond_0

    iget-object v0, p0, LD2/f$a;->b:LD2/f;

    const/4 v1, 0x1

    invoke-static {v0}, LD2/f;->i(LD2/f;)I

    move-result v2

    invoke-static {p1, v1, v2}, LU9/g;->k(III)I

    move-result p1

    invoke-static {v0, p1}, LD2/f;->j(LD2/f;I)V

    iget-object p1, p0, LD2/f$a;->b:LD2/f;

    invoke-static {p1}, LD2/f;->h(LD2/f;)LF2/j;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p0, p0, LD2/f$a;->b:LD2/f;

    invoke-static {p0}, LD2/f;->g(LD2/f;)I

    move-result p0

    invoke-interface {p1, p0}, LF2/j;->d(I)V

    :cond_0
    return-void
.end method
