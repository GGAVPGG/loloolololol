.class public final synthetic LD2/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LN9/a;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    invoke-static {}, LD2/f;->f()Ly9/A;

    move-result-object p0

    return-object p0
.end method
