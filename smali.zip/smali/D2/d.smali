.class public final LD2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD2/a;


# instance fields
.field private final a:I

.field private final b:Ljava/lang/Class;


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LD2/d;->a:I

    const-class p1, LD2/d;

    iput-object p1, p0, LD2/d;->b:Ljava/lang/Class;

    return-void
.end method


# virtual methods
.method public a()V
    .locals 0

    invoke-static {p0}, LD2/a$a;->c(LD2/a;)V

    return-void
.end method

.method public b(IILN9/a;)V
    .locals 0

    invoke-static {p0, p1, p2, p3}, LD2/a$a;->d(LD2/a;IILN9/a;)V

    return-void
.end method

.method public c(III)Lc2/a;
    .locals 0

    invoke-static {p0, p1, p2, p3}, LD2/a$a;->b(LD2/a;III)Lc2/a;

    move-result-object p0

    return-object p0
.end method

.method public d()V
    .locals 0

    invoke-static {p0}, LD2/a$a;->a(LD2/a;)V

    return-void
.end method

.method public e(LD2/b;LB2/b;LA2/a;ILN9/a;)V
    .locals 7

    const-string v0, "bitmapFramePreparer"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapFrameCache"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "animationBackend"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget v0, p0, LD2/d;->a:I

    const/4 v1, 0x1

    if-gt v1, v0, :cond_2

    :goto_0
    add-int v2, p4, v1

    invoke-interface {p3}, LA2/d;->c()I

    move-result v3

    rem-int/2addr v2, v3

    const/4 v3, 0x2

    invoke-static {v3}, LZ1/a;->w(I)Z

    move-result v3

    if-eqz v3, :cond_0

    iget-object v3, p0, LD2/d;->b:Ljava/lang/Class;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "Preparing frame %d, last drawn: %d"

    invoke-static {v3, v6, v4, v5}, LZ1/a;->z(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_0
    invoke-interface {p1, p2, p3, v2}, LD2/b;->a(LB2/b;LA2/a;I)Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    if-eq v1, v0, :cond_2

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    if-eqz p5, :cond_3

    invoke-interface {p5}, LN9/a;->invoke()Ljava/lang/Object;

    :cond_3
    :goto_1
    return-void
.end method
