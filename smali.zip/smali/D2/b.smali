.class public interface abstract LD2/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LB2/b;LA2/a;I)Z
.end method
