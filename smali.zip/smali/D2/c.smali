.class public final LD2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD2/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD2/c$a;
    }
.end annotation


# instance fields
.field private final a:LW2/d;

.field private final b:LB2/c;

.field private final c:Landroid/graphics/Bitmap$Config;

.field private final d:Ljava/util/concurrent/ExecutorService;

.field private final e:Ljava/lang/Class;

.field private final f:Landroid/util/SparseArray;


# direct methods
.method public constructor <init>(LW2/d;LB2/c;Landroid/graphics/Bitmap$Config;Ljava/util/concurrent/ExecutorService;)V
    .locals 1

    const-string v0, "platformBitmapFactory"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapFrameRenderer"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapConfig"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "executorService"

    invoke-static {p4, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD2/c;->a:LW2/d;

    iput-object p2, p0, LD2/c;->b:LB2/c;

    iput-object p3, p0, LD2/c;->c:Landroid/graphics/Bitmap$Config;

    iput-object p4, p0, LD2/c;->d:Ljava/util/concurrent/ExecutorService;

    const-class p1, LD2/c;

    iput-object p1, p0, LD2/c;->e:Ljava/lang/Class;

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, LD2/c;->f:Landroid/util/SparseArray;

    return-void
.end method

.method public static final synthetic b(LD2/c;)Landroid/graphics/Bitmap$Config;
    .locals 0

    iget-object p0, p0, LD2/c;->c:Landroid/graphics/Bitmap$Config;

    return-object p0
.end method

.method public static final synthetic c(LD2/c;)LB2/c;
    .locals 0

    iget-object p0, p0, LD2/c;->b:LB2/c;

    return-object p0
.end method

.method public static final synthetic d(LD2/c;)Landroid/util/SparseArray;
    .locals 0

    iget-object p0, p0, LD2/c;->f:Landroid/util/SparseArray;

    return-object p0
.end method

.method public static final synthetic e(LD2/c;)LW2/d;
    .locals 0

    iget-object p0, p0, LD2/c;->a:LW2/d;

    return-object p0
.end method

.method public static final synthetic f(LD2/c;)Ljava/lang/Class;
    .locals 0

    iget-object p0, p0, LD2/c;->e:Ljava/lang/Class;

    return-object p0
.end method

.method private final g(LA2/a;I)I
    .locals 0

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p0

    mul-int/lit8 p0, p0, 0x1f

    add-int/2addr p0, p2

    return p0
.end method


# virtual methods
.method public a(LB2/b;LA2/a;I)Z
    .locals 9

    const-string v0, "bitmapFrameCache"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "animationBackend"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p2, p3}, LD2/c;->g(LA2/a;I)I

    move-result v6

    iget-object v7, p0, LD2/c;->f:Landroid/util/SparseArray;

    monitor-enter v7

    :try_start_0
    iget-object v0, p0, LD2/c;->f:Landroid/util/SparseArray;

    invoke-virtual {v0, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    iget-object p0, p0, LD2/c;->e:Ljava/lang/Class;

    const-string p1, "Already scheduled decode job for frame %d"

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-static {p0, p1, p2}, LZ1/a;->y(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v7

    return v8

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_0

    :cond_0
    :try_start_1
    invoke-interface {p1, p3}, LB2/b;->t(I)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, LD2/c;->e:Ljava/lang/Class;

    const-string p1, "Frame %d is cached already."

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-static {p0, p1, p2}, LZ1/a;->y(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v7

    return v8

    :cond_1
    :try_start_2
    new-instance v1, LD2/c$a;

    move-object v2, p0

    move-object v4, p1

    move-object v3, p2

    move v5, p3

    invoke-direct/range {v1 .. v6}, LD2/c$a;-><init>(LD2/c;LA2/a;LB2/b;II)V

    iget-object p0, v2, LD2/c;->f:Landroid/util/SparseArray;

    invoke-virtual {p0, v6, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    iget-object p0, v2, LD2/c;->d:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit v7

    return v8

    :goto_0
    monitor-exit v7

    throw p0
.end method
