.class public final LC4/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/b;


# instance fields
.field private final a:Ljavax/inject/Provider;

.field private final b:Ljavax/inject/Provider;

.field private final c:Ljavax/inject/Provider;

.field private final d:Ljavax/inject/Provider;


# direct methods
.method public constructor <init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC4/i;->a:Ljavax/inject/Provider;

    iput-object p2, p0, LC4/i;->b:Ljavax/inject/Provider;

    iput-object p3, p0, LC4/i;->c:Ljavax/inject/Provider;

    iput-object p4, p0, LC4/i;->d:Ljavax/inject/Provider;

    return-void
.end method

.method public static a(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)LC4/i;
    .locals 1

    new-instance v0, LC4/i;

    invoke-direct {v0, p0, p1, p2, p3}, LC4/i;-><init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V

    return-object v0
.end method

.method public static c(Landroid/content/Context;LE4/d;LD4/f;LG4/a;)LD4/x;
    .locals 0

    invoke-static {p0, p1, p2, p3}, LC4/h;->a(Landroid/content/Context;LE4/d;LD4/f;LG4/a;)LD4/x;

    move-result-object p0

    const-string p1, "Cannot return null from a non-@Nullable @Provides method"

    invoke-static {p0, p1}, Ly4/d;->c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LD4/x;

    return-object p0
.end method


# virtual methods
.method public b()LD4/x;
    .locals 3

    iget-object v0, p0, LC4/i;->a:Ljavax/inject/Provider;

    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, LC4/i;->b:Ljavax/inject/Provider;

    invoke-interface {v1}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LE4/d;

    iget-object v2, p0, LC4/i;->c:Ljavax/inject/Provider;

    invoke-interface {v2}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD4/f;

    iget-object p0, p0, LC4/i;->d:Ljavax/inject/Provider;

    invoke-interface {p0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG4/a;

    invoke-static {v0, v1, v2, p0}, LC4/i;->c(Landroid/content/Context;LE4/d;LD4/f;LG4/a;)LD4/x;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, LC4/i;->b()LD4/x;

    move-result-object p0

    return-object p0
.end method
