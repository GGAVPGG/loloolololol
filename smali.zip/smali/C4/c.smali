.class public LC4/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC4/e;


# static fields
.field private static final f:Ljava/util/logging/Logger;


# instance fields
.field private final a:LD4/x;

.field private final b:Ljava/util/concurrent/Executor;

.field private final c:Lx4/e;

.field private final d:LE4/d;

.field private final e:LF4/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-class v0, Lw4/t;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, LC4/c;->f:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/Executor;Lx4/e;LD4/x;LE4/d;LF4/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC4/c;->b:Ljava/util/concurrent/Executor;

    iput-object p2, p0, LC4/c;->c:Lx4/e;

    iput-object p3, p0, LC4/c;->a:LD4/x;

    iput-object p4, p0, LC4/c;->d:LE4/d;

    iput-object p5, p0, LC4/c;->e:LF4/b;

    return-void
.end method

.method public static synthetic b(LC4/c;Lw4/o;Lw4/i;)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, LC4/c;->d:LE4/d;

    invoke-interface {v0, p1, p2}, LE4/d;->L1(Lw4/o;Lw4/i;)LE4/k;

    iget-object p0, p0, LC4/c;->a:LD4/x;

    const/4 p2, 0x1

    invoke-interface {p0, p1, p2}, LD4/x;->b(Lw4/o;I)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic c(LC4/c;Lw4/o;Lu4/j;Lw4/i;)V
    .locals 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v0, p0, LC4/c;->c:Lx4/e;

    invoke-virtual {p1}, Lw4/o;->b()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lx4/e;->b(Ljava/lang/String;)Lx4/m;

    move-result-object v0

    if-nez v0, :cond_0

    const-string p0, "Transport backend \'%s\' is not registered"

    invoke-virtual {p1}, Lw4/o;->b()Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-static {p0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    sget-object p1, LC4/c;->f:Ljava/util/logging/Logger;

    invoke-virtual {p1, p0}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    invoke-interface {p2, p1}, Lu4/j;->a(Ljava/lang/Exception;)V

    return-void

    :catch_0
    move-exception p0

    goto :goto_0

    :cond_0
    invoke-interface {v0, p3}, Lx4/m;->a(Lw4/i;)Lw4/i;

    move-result-object p3

    iget-object v0, p0, LC4/c;->e:LF4/b;

    new-instance v1, LC4/b;

    invoke-direct {v1, p0, p1, p3}, LC4/b;-><init>(LC4/c;Lw4/o;Lw4/i;)V

    invoke-interface {v0, v1}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    const/4 p0, 0x0

    invoke-interface {p2, p0}, Lu4/j;->a(Ljava/lang/Exception;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_0
    sget-object p1, LC4/c;->f:Ljava/util/logging/Logger;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Error scheduling event "

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    invoke-interface {p2, p0}, Lu4/j;->a(Ljava/lang/Exception;)V

    return-void
.end method


# virtual methods
.method public a(Lw4/o;Lw4/i;Lu4/j;)V
    .locals 2

    iget-object v0, p0, LC4/c;->b:Ljava/util/concurrent/Executor;

    new-instance v1, LC4/a;

    invoke-direct {v1, p0, p1, p3, p2}, LC4/a;-><init>(LC4/c;Lw4/o;Lu4/j;Lw4/i;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
