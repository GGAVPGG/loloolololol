.class public final LC4/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/b;


# instance fields
.field private final a:Ljavax/inject/Provider;

.field private final b:Ljavax/inject/Provider;

.field private final c:Ljavax/inject/Provider;

.field private final d:Ljavax/inject/Provider;

.field private final e:Ljavax/inject/Provider;


# direct methods
.method public constructor <init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC4/d;->a:Ljavax/inject/Provider;

    iput-object p2, p0, LC4/d;->b:Ljavax/inject/Provider;

    iput-object p3, p0, LC4/d;->c:Ljavax/inject/Provider;

    iput-object p4, p0, LC4/d;->d:Ljavax/inject/Provider;

    iput-object p5, p0, LC4/d;->e:Ljavax/inject/Provider;

    return-void
.end method

.method public static a(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)LC4/d;
    .locals 6

    new-instance v0, LC4/d;

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, LC4/d;-><init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V

    return-object v0
.end method

.method public static c(Ljava/util/concurrent/Executor;Lx4/e;LD4/x;LE4/d;LF4/b;)LC4/c;
    .locals 6

    new-instance v0, LC4/c;

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    invoke-direct/range {v0 .. v5}, LC4/c;-><init>(Ljava/util/concurrent/Executor;Lx4/e;LD4/x;LE4/d;LF4/b;)V

    return-object v0
.end method


# virtual methods
.method public b()LC4/c;
    .locals 4

    iget-object v0, p0, LC4/d;->a:Ljavax/inject/Provider;

    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Executor;

    iget-object v1, p0, LC4/d;->b:Ljavax/inject/Provider;

    invoke-interface {v1}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lx4/e;

    iget-object v2, p0, LC4/d;->c:Ljavax/inject/Provider;

    invoke-interface {v2}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD4/x;

    iget-object v3, p0, LC4/d;->d:Ljavax/inject/Provider;

    invoke-interface {v3}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE4/d;

    iget-object p0, p0, LC4/d;->e:Ljavax/inject/Provider;

    invoke-interface {p0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LF4/b;

    invoke-static {v0, v1, v2, v3, p0}, LC4/d;->c(Ljava/util/concurrent/Executor;Lx4/e;LD4/x;LE4/d;LF4/b;)LC4/c;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, LC4/d;->b()LC4/c;

    move-result-object p0

    return-object p0
.end method
