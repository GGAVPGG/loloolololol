.class public final synthetic LC4/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LC4/c;

.field public final synthetic b:Lw4/o;

.field public final synthetic c:Lw4/i;


# direct methods
.method public synthetic constructor <init>(LC4/c;Lw4/o;Lw4/i;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC4/b;->a:LC4/c;

    iput-object p2, p0, LC4/b;->b:Lw4/o;

    iput-object p3, p0, LC4/b;->c:Lw4/i;

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LC4/b;->a:LC4/c;

    iget-object v1, p0, LC4/b;->b:Lw4/o;

    iget-object p0, p0, LC4/b;->c:Lw4/i;

    invoke-static {v0, v1, p0}, LC4/c;->b(LC4/c;Lw4/o;Lw4/i;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
