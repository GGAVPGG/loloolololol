.class public abstract LC4/f;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static a(LG4/a;)LD4/f;
    .locals 0

    invoke-static {p0}, LD4/f;->f(LG4/a;)LD4/f;

    move-result-object p0

    return-object p0
.end method
