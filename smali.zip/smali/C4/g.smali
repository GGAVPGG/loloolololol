.class public final LC4/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/b;


# instance fields
.field private final a:Ljavax/inject/Provider;


# direct methods
.method public constructor <init>(Ljavax/inject/Provider;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC4/g;->a:Ljavax/inject/Provider;

    return-void
.end method

.method public static a(LG4/a;)LD4/f;
    .locals 1

    invoke-static {p0}, LC4/f;->a(LG4/a;)LD4/f;

    move-result-object p0

    const-string v0, "Cannot return null from a non-@Nullable @Provides method"

    invoke-static {p0, v0}, Ly4/d;->c(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LD4/f;

    return-object p0
.end method

.method public static b(Ljavax/inject/Provider;)LC4/g;
    .locals 1

    new-instance v0, LC4/g;

    invoke-direct {v0, p0}, LC4/g;-><init>(Ljavax/inject/Provider;)V

    return-object v0
.end method


# virtual methods
.method public c()LD4/f;
    .locals 0

    iget-object p0, p0, LC4/g;->a:Ljavax/inject/Provider;

    invoke-interface {p0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG4/a;

    invoke-static {p0}, LC4/g;->a(LG4/a;)LD4/f;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, LC4/g;->c()LD4/f;

    move-result-object p0

    return-object p0
.end method
