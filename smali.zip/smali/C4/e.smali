.class public interface abstract LC4/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lw4/o;Lw4/i;Lu4/j;)V
.end method
