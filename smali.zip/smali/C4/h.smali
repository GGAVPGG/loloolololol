.class public abstract LC4/h;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static a(Landroid/content/Context;LE4/d;LD4/f;LG4/a;)LD4/x;
    .locals 0

    new-instance p3, LD4/d;

    invoke-direct {p3, p0, p1, p2}, LD4/d;-><init>(Landroid/content/Context;LE4/d;LD4/f;)V

    return-object p3
.end method
