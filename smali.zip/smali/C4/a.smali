.class public final synthetic LC4/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LC4/c;

.field public final synthetic g:Lw4/o;

.field public final synthetic h:Lu4/j;

.field public final synthetic i:Lw4/i;


# direct methods
.method public synthetic constructor <init>(LC4/c;Lw4/o;Lu4/j;Lw4/i;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC4/a;->f:LC4/c;

    iput-object p2, p0, LC4/a;->g:Lw4/o;

    iput-object p3, p0, LC4/a;->h:Lu4/j;

    iput-object p4, p0, LC4/a;->i:Lw4/i;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, LC4/a;->f:LC4/c;

    iget-object v1, p0, LC4/a;->g:Lw4/o;

    iget-object v2, p0, LC4/a;->h:Lu4/j;

    iget-object p0, p0, LC4/a;->i:Lw4/i;

    invoke-static {v0, v1, v2, p0}, LC4/c;->c(LC4/c;Lw4/o;Lu4/j;Lw4/i;)V

    return-void
.end method
