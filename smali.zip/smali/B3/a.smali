.class public final LB3/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LB3/a;

.field private static b:Lxb/A;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LB3/a;

    invoke-direct {v0}, LB3/a;-><init>()V

    sput-object v0, LB3/a;->a:LB3/a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final a(Ljava/lang/String;Lcom/facebook/react/devsupport/inspector/InspectorNetworkRequestListener;)V
    .locals 4

    const-string v0, "url"

    invoke-static {p0, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "listener"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v0, LB3/a;->b:Lxb/A;

    if-nez v0, :cond_0

    new-instance v0, Lxb/A$a;

    invoke-direct {v0}, Lxb/A$a;-><init>()V

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0xa

    invoke-virtual {v0, v2, v3, v1}, Lxb/A$a;->f(JLjava/util/concurrent/TimeUnit;)Lxb/A$a;

    move-result-object v0

    invoke-virtual {v0, v2, v3, v1}, Lxb/A$a;->Q(JLjava/util/concurrent/TimeUnit;)Lxb/A$a;

    move-result-object v0

    const-wide/16 v1, 0x0

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v1, v2, v3}, Lxb/A$a;->P(JLjava/util/concurrent/TimeUnit;)Lxb/A$a;

    move-result-object v0

    invoke-virtual {v0}, Lxb/A$a;->c()Lxb/A;

    move-result-object v0

    sput-object v0, LB3/a;->b:Lxb/A;

    :cond_0
    :try_start_0
    new-instance v0, Lxb/C$a;

    invoke-direct {v0}, Lxb/C$a;-><init>()V

    invoke-virtual {v0, p0}, Lxb/C$a;->l(Ljava/lang/String;)Lxb/C$a;

    move-result-object v0

    invoke-virtual {v0}, Lxb/C$a;->b()Lxb/C;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    sget-object v0, LB3/a;->b:Lxb/A;

    if-nez v0, :cond_1

    const-string v0, "client"

    invoke-static {v0}, LO9/l;->w(Ljava/lang/String;)V

    const/4 v0, 0x0

    :cond_1
    invoke-virtual {v0, p0}, Lxb/A;->a(Lxb/C;)Lxb/e;

    move-result-object p0

    new-instance v0, LB3/a$a;

    invoke-direct {v0, p1}, LB3/a$a;-><init>(Lcom/facebook/react/devsupport/inspector/InspectorNetworkRequestListener;)V

    invoke-interface {p0, v0}, Lxb/e;->D0(Lxb/f;)V

    return-void

    :catch_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Not a valid URL: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/facebook/react/devsupport/inspector/InspectorNetworkRequestListener;->onError(Ljava/lang/String;)V

    return-void
.end method
