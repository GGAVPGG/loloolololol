.class public final LE6/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:LE6/h;

.field private final b:Lz6/d;

.field private final c:Lz6/i;


# direct methods
.method constructor <init>(LE6/h;Lz6/d;Lz6/i;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/f;->a:LE6/h;

    iput-object p2, p0, LE6/f;->b:Lz6/d;

    iput-object p3, p0, LE6/f;->c:Lz6/i;

    return-void
.end method


# virtual methods
.method public final a(LB6/b;)LE6/g;
    .locals 7

    iget-object v0, p0, LE6/f;->a:LE6/h;

    new-instance v1, LE6/g;

    invoke-virtual {v0, p1}, Lz6/e;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, LE6/k;

    iget-object v0, p0, LE6/f;->b:Lz6/d;

    invoke-virtual {p1}, LB6/b;->c()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-virtual {v0, v2}, Lz6/d;->a(Ljava/util/concurrent/Executor;)Ljava/util/concurrent/Executor;

    move-result-object v4

    invoke-static {}, LE6/b;->d()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Le5/Y9;->b(Ljava/lang/String;)Le5/M9;

    move-result-object v5

    iget-object v6, p0, LE6/f;->c:Lz6/i;

    move-object v2, p1

    invoke-direct/range {v1 .. v6}, LE6/g;-><init>(LB6/b;LE6/k;Ljava/util/concurrent/Executor;Le5/M9;Lz6/i;)V

    return-object v1
.end method
