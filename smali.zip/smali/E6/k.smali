.class public final LE6/k;
.super Lz6/f;
.source "SourceFile"


# static fields
.field private static final j:LI6/d;

.field static k:Z


# instance fields
.field private final d:LB6/b;

.field private final e:LE6/l;

.field private final f:Le5/M9;

.field private final g:Le5/O9;

.field private final h:LI6/a;

.field private i:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    invoke-static {}, LI6/d;->b()LI6/d;

    move-result-object v0

    sput-object v0, LE6/k;->j:LI6/d;

    const/4 v0, 0x1

    sput-boolean v0, LE6/k;->k:Z

    return-void
.end method

.method public constructor <init>(Lz6/i;LB6/b;LE6/l;Le5/M9;)V
    .locals 1

    invoke-direct {p0}, Lz6/f;-><init>()V

    new-instance v0, LI6/a;

    invoke-direct {v0}, LI6/a;-><init>()V

    iput-object v0, p0, LE6/k;->h:LI6/a;

    const-string v0, "MlKitContext can not be null"

    invoke-static {p1, v0}, LP4/p;->l(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "BarcodeScannerOptions can not be null"

    invoke-static {p2, v0}, LP4/p;->l(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p2, p0, LE6/k;->d:LB6/b;

    iput-object p3, p0, LE6/k;->e:LE6/l;

    iput-object p4, p0, LE6/k;->f:Le5/M9;

    invoke-virtual {p1}, Lz6/i;->b()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Le5/O9;->a(Landroid/content/Context;)Le5/O9;

    move-result-object p1

    iput-object p1, p0, LE6/k;->g:Le5/O9;

    return-void
.end method

.method private final m(Le5/X6;JLH6/a;Ljava/util/List;)V
    .locals 20

    new-instance v5, Le5/g0;

    invoke-direct {v5}, Le5/g0;-><init>()V

    new-instance v6, Le5/g0;

    invoke-direct {v6}, Le5/g0;-><init>()V

    if-eqz p5, :cond_0

    invoke-interface/range {p5 .. p5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LC6/a;

    invoke-virtual {v1}, LC6/a;->g()I

    move-result v2

    invoke-static {v2}, LE6/b;->a(I)Le5/j7;

    move-result-object v2

    invoke-virtual {v5, v2}, Le5/g0;->e(Ljava/lang/Object;)Le5/g0;

    invoke-virtual {v1}, LC6/a;->n()I

    move-result v1

    invoke-static {v1}, LE6/b;->b(I)Le5/k7;

    move-result-object v1

    invoke-virtual {v6, v1}, Le5/g0;->e(Ljava/lang/Object;)Le5/g0;

    goto :goto_0

    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sub-long v11, v0, p2

    new-instance v0, LE6/i;

    move-object/from16 v1, p0

    move-object/from16 v4, p1

    move-object/from16 v7, p4

    move-wide v2, v11

    invoke-direct/range {v0 .. v7}, LE6/i;-><init>(LE6/k;JLe5/X6;Le5/g0;Le5/g0;LH6/a;)V

    iget-object v2, v1, LE6/k;->f:Le5/M9;

    sget-object v3, Le5/Y6;->p:Le5/Y6;

    invoke-virtual {v2, v0, v3}, Le5/M9;->f(Le5/L9;Le5/Y6;)V

    new-instance v0, Le5/c1;

    invoke-direct {v0}, Le5/c1;-><init>()V

    invoke-virtual {v0, v4}, Le5/c1;->e(Le5/X6;)Le5/c1;

    sget-boolean v2, LE6/k;->k:Z

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v2}, Le5/c1;->f(Ljava/lang/Boolean;)Le5/c1;

    iget-object v2, v1, LE6/k;->d:LB6/b;

    invoke-static {v2}, LE6/b;->c(LB6/b;)Le5/v9;

    move-result-object v2

    invoke-virtual {v0, v2}, Le5/c1;->g(Le5/v9;)Le5/c1;

    invoke-virtual {v5}, Le5/g0;->g()Le5/j0;

    move-result-object v2

    invoke-virtual {v0, v2}, Le5/c1;->c(Le5/j0;)Le5/c1;

    invoke-virtual {v6}, Le5/g0;->g()Le5/j0;

    move-result-object v2

    invoke-virtual {v0, v2}, Le5/c1;->d(Le5/j0;)Le5/c1;

    invoke-virtual {v0}, Le5/c1;->h()Le5/e1;

    move-result-object v10

    new-instance v13, LE6/j;

    invoke-direct {v13, v1}, LE6/j;-><init>(LE6/k;)V

    iget-object v8, v1, LE6/k;->f:Le5/M9;

    sget-object v9, Le5/Y6;->k1:Le5/Y6;

    invoke-static {}, Lz6/g;->d()Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v7, Le5/K9;

    invoke-direct/range {v7 .. v13}, Le5/K9;-><init>(Le5/M9;Le5/Y6;Ljava/lang/Object;JLE6/j;)V

    invoke-interface {v0, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v18

    iget-boolean v0, v1, LE6/k;->i:Z

    sub-long v16, v18, v11

    iget-object v13, v1, LE6/k;->g:Le5/O9;

    const/4 v1, 0x1

    if-eq v1, v0, :cond_1

    const/16 v0, 0x5eed

    :goto_1
    move v14, v0

    goto :goto_2

    :cond_1
    const/16 v0, 0x5eee

    goto :goto_1

    :goto_2
    invoke-virtual {v4}, Le5/X6;->zza()I

    move-result v15

    invoke-virtual/range {v13 .. v19}, Le5/O9;->c(IIJJ)V

    return-void
.end method


# virtual methods
.method public final declared-synchronized b()V
    .locals 1

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, LE6/k;->e:LE6/l;

    invoke-interface {v0}, LE6/l;->d()Z

    move-result v0

    iput-boolean v0, p0, LE6/k;->i:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final declared-synchronized d()V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, LE6/k;->e:LE6/l;

    invoke-interface {v0}, LE6/l;->zzb()V

    const/4 v0, 0x1

    sput-boolean v0, LE6/k;->k:Z

    new-instance v0, Le5/Z6;

    invoke-direct {v0}, Le5/Z6;-><init>()V

    iget-boolean v1, p0, LE6/k;->i:Z

    if-eqz v1, :cond_0

    sget-object v1, Le5/W6;->i:Le5/W6;

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    sget-object v1, Le5/W6;->h:Le5/W6;

    :goto_0
    iget-object v2, p0, LE6/k;->f:Le5/M9;

    invoke-virtual {v0, v1}, Le5/Z6;->e(Le5/W6;)Le5/Z6;

    new-instance v1, Le5/l7;

    invoke-direct {v1}, Le5/l7;-><init>()V

    iget-object v3, p0, LE6/k;->d:LB6/b;

    invoke-static {v3}, LE6/b;->c(LB6/b;)Le5/v9;

    move-result-object v3

    invoke-virtual {v1, v3}, Le5/l7;->i(Le5/v9;)Le5/l7;

    invoke-virtual {v1}, Le5/l7;->j()Le5/n7;

    move-result-object v1

    invoke-virtual {v0, v1}, Le5/Z6;->g(Le5/n7;)Le5/Z6;

    invoke-static {v0}, Le5/P9;->e(Le5/Z6;)Le5/B9;

    move-result-object v0

    sget-object v1, Le5/Y6;->r:Le5/Y6;

    invoke-virtual {v2, v0, v1}, Le5/M9;->d(Le5/B9;Le5/Y6;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final bridge synthetic i(Lz6/h;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LH6/a;

    invoke-virtual {p0, p1}, LE6/k;->l(LH6/a;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method final synthetic j(JLe5/X6;Le5/g0;Le5/g0;LH6/a;)Le5/B9;
    .locals 2

    new-instance v0, Le5/l7;

    invoke-direct {v0}, Le5/l7;-><init>()V

    new-instance v1, Le5/J6;

    invoke-direct {v1}, Le5/J6;-><init>()V

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {v1, p1}, Le5/J6;->c(Ljava/lang/Long;)Le5/J6;

    invoke-virtual {v1, p3}, Le5/J6;->d(Le5/X6;)Le5/J6;

    sget-boolean p1, LE6/k;->k:Z

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {v1, p1}, Le5/J6;->e(Ljava/lang/Boolean;)Le5/J6;

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, p1}, Le5/J6;->a(Ljava/lang/Boolean;)Le5/J6;

    invoke-virtual {v1, p1}, Le5/J6;->b(Ljava/lang/Boolean;)Le5/J6;

    invoke-virtual {v1}, Le5/J6;->f()Le5/L6;

    move-result-object p1

    invoke-virtual {v0, p1}, Le5/l7;->h(Le5/L6;)Le5/l7;

    iget-object p1, p0, LE6/k;->d:LB6/b;

    invoke-static {p1}, LE6/b;->c(LB6/b;)Le5/v9;

    move-result-object p1

    invoke-virtual {v0, p1}, Le5/l7;->i(Le5/v9;)Le5/l7;

    invoke-virtual {p4}, Le5/g0;->g()Le5/j0;

    move-result-object p1

    invoke-virtual {v0, p1}, Le5/l7;->e(Le5/j0;)Le5/l7;

    invoke-virtual {p5}, Le5/g0;->g()Le5/j0;

    move-result-object p1

    invoke-virtual {v0, p1}, Le5/l7;->f(Le5/j0;)Le5/l7;

    invoke-virtual {p6}, LH6/a;->e()I

    move-result p1

    sget-object p2, LE6/k;->j:LI6/d;

    invoke-virtual {p2, p6}, LI6/d;->c(LH6/a;)I

    move-result p2

    new-instance p3, Le5/C6;

    invoke-direct {p3}, Le5/C6;-><init>()V

    const/4 p4, -0x1

    if-eq p1, p4, :cond_4

    const/16 p4, 0x23

    if-eq p1, p4, :cond_3

    const p4, 0x32315659

    if-eq p1, p4, :cond_2

    const/16 p4, 0x10

    if-eq p1, p4, :cond_1

    const/16 p4, 0x11

    if-eq p1, p4, :cond_0

    sget-object p1, Le5/D6;->g:Le5/D6;

    goto :goto_0

    :cond_0
    sget-object p1, Le5/D6;->i:Le5/D6;

    goto :goto_0

    :cond_1
    sget-object p1, Le5/D6;->h:Le5/D6;

    goto :goto_0

    :cond_2
    sget-object p1, Le5/D6;->j:Le5/D6;

    goto :goto_0

    :cond_3
    sget-object p1, Le5/D6;->k:Le5/D6;

    goto :goto_0

    :cond_4
    sget-object p1, Le5/D6;->m:Le5/D6;

    :goto_0
    invoke-virtual {p3, p1}, Le5/C6;->a(Le5/D6;)Le5/C6;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p3, p1}, Le5/C6;->b(Ljava/lang/Integer;)Le5/C6;

    invoke-virtual {p3}, Le5/C6;->d()Le5/F6;

    move-result-object p1

    invoke-virtual {v0, p1}, Le5/l7;->g(Le5/F6;)Le5/l7;

    new-instance p1, Le5/Z6;

    invoke-direct {p1}, Le5/Z6;-><init>()V

    iget-boolean p0, p0, LE6/k;->i:Z

    if-eqz p0, :cond_5

    sget-object p0, Le5/W6;->i:Le5/W6;

    goto :goto_1

    :cond_5
    sget-object p0, Le5/W6;->h:Le5/W6;

    :goto_1
    invoke-virtual {p1, p0}, Le5/Z6;->e(Le5/W6;)Le5/Z6;

    invoke-virtual {v0}, Le5/l7;->j()Le5/n7;

    move-result-object p0

    invoke-virtual {p1, p0}, Le5/Z6;->g(Le5/n7;)Le5/Z6;

    invoke-static {p1}, Le5/P9;->e(Le5/Z6;)Le5/B9;

    move-result-object p0

    return-object p0
.end method

.method final synthetic k(Le5/e1;ILe5/y6;)Le5/B9;
    .locals 1

    new-instance v0, Le5/Z6;

    invoke-direct {v0}, Le5/Z6;-><init>()V

    iget-boolean p0, p0, LE6/k;->i:Z

    if-eqz p0, :cond_0

    sget-object p0, Le5/W6;->i:Le5/W6;

    goto :goto_0

    :cond_0
    sget-object p0, Le5/W6;->h:Le5/W6;

    :goto_0
    invoke-virtual {v0, p0}, Le5/Z6;->e(Le5/W6;)Le5/Z6;

    new-instance p0, Le5/b1;

    invoke-direct {p0}, Le5/b1;-><init>()V

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-virtual {p0, p2}, Le5/b1;->a(Ljava/lang/Integer;)Le5/b1;

    invoke-virtual {p0, p1}, Le5/b1;->c(Le5/e1;)Le5/b1;

    invoke-virtual {p0, p3}, Le5/b1;->b(Le5/y6;)Le5/b1;

    invoke-virtual {p0}, Le5/b1;->e()Le5/g1;

    move-result-object p0

    invoke-virtual {v0, p0}, Le5/Z6;->d(Le5/g1;)Le5/Z6;

    invoke-static {v0}, Le5/P9;->e(Le5/Z6;)Le5/B9;

    move-result-object p0

    return-object p0
.end method

.method public final declared-synchronized l(LH6/a;)Ljava/util/List;
    .locals 7

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, LE6/k;->h:LI6/a;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v0, p1}, LI6/a;->a(LH6/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v0, p0, LE6/k;->e:LE6/l;

    invoke-interface {v0, p1}, LE6/l;->e(LH6/a;)Ljava/util/List;

    move-result-object v6

    sget-object v2, Le5/X6;->g:Le5/X6;
    :try_end_1
    .catch Lv6/a; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object v1, p0

    move-object v5, p1

    :try_start_2
    invoke-direct/range {v1 .. v6}, LE6/k;->m(Le5/X6;JLH6/a;Ljava/util/List;)V

    const/4 p0, 0x0

    sput-boolean p0, LE6/k;->k:Z
    :try_end_2
    .catch Lv6/a; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit v1

    return-object v6

    :catchall_0
    move-exception v0

    :goto_0
    move-object p0, v0

    goto :goto_5

    :catch_0
    move-exception v0

    :goto_1
    move-object p0, v0

    goto :goto_2

    :catchall_1
    move-exception v0

    move-object v1, p0

    goto :goto_0

    :catch_1
    move-exception v0

    move-object v1, p0

    move-object v5, p1

    goto :goto_1

    :goto_2
    :try_start_3
    invoke-virtual {p0}, Lv6/a;->a()I

    move-result p1

    const/16 v0, 0xe

    if-ne p1, v0, :cond_0

    sget-object p1, Le5/X6;->q:Le5/X6;

    :goto_3
    move-object v2, p1

    goto :goto_4

    :cond_0
    sget-object p1, Le5/X6;->h0:Le5/X6;

    goto :goto_3

    :goto_4
    const/4 v6, 0x0

    invoke-direct/range {v1 .. v6}, LE6/k;->m(Le5/X6;JLH6/a;Ljava/util/List;)V

    throw p0

    :goto_5
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p0
.end method
