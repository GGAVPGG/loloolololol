.class public final LE6/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD6/a;


# instance fields
.field private final a:Le5/ra;


# direct methods
.method public constructor <init>(Le5/ra;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/m;->a:Le5/ra;

    return-void
.end method

.method private static o(Le5/fa;)LC6/a$b;
    .locals 9

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, LC6/a$b;

    invoke-virtual {p0}, Le5/fa;->k()I

    move-result v1

    invoke-virtual {p0}, Le5/fa;->g()I

    move-result v2

    invoke-virtual {p0}, Le5/fa;->b()I

    move-result v3

    invoke-virtual {p0}, Le5/fa;->e()I

    move-result v4

    invoke-virtual {p0}, Le5/fa;->f()I

    move-result v5

    invoke-virtual {p0}, Le5/fa;->j()I

    move-result v6

    invoke-virtual {p0}, Le5/fa;->p()Z

    move-result v7

    invoke-virtual {p0}, Le5/fa;->n()Ljava/lang/String;

    move-result-object v8

    invoke-direct/range {v0 .. v8}, LC6/a$b;-><init>(IIIIIIZLjava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public final a()LC6/a$i;
    .locals 2

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->p()Le5/ma;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$i;

    invoke-virtual {p0}, Le5/ma;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Le5/ma;->b()I

    move-result p0

    invoke-direct {v0, v1, p0}, LC6/a$i;-><init>(Ljava/lang/String;I)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final b()LC6/a$e;
    .locals 15

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->j()Le5/ia;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$e;

    invoke-virtual {p0}, Le5/ia;->k()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Le5/ia;->p()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0}, Le5/ia;->G()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Le5/ia;->E()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Le5/ia;->z()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0}, Le5/ia;->f()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0}, Le5/ia;->b()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0}, Le5/ia;->e()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p0}, Le5/ia;->g()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {p0}, Le5/ia;->F()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {p0}, Le5/ia;->A()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {p0}, Le5/ia;->n()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {p0}, Le5/ia;->j()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {p0}, Le5/ia;->D()Ljava/lang/String;

    move-result-object v14

    invoke-direct/range {v0 .. v14}, LC6/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final c()Landroid/graphics/Rect;
    .locals 7

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->H()[Landroid/graphics/Point;

    move-result-object p0

    if-eqz p0, :cond_1

    const/4 v0, 0x0

    const/high16 v1, -0x80000000

    const v2, 0x7fffffff

    move v3, v2

    move v4, v3

    move v2, v1

    :goto_0
    array-length v5, p0

    if-ge v0, v5, :cond_0

    aget-object v5, p0, v0

    iget v6, v5, Landroid/graphics/Point;->x:I

    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    move-result v3

    iget v6, v5, Landroid/graphics/Point;->x:I

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget v6, v5, Landroid/graphics/Point;->y:I

    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    move-result v4

    iget v5, v5, Landroid/graphics/Point;->y:I

    invoke-static {v2, v5}, Ljava/lang/Math;->max(II)I

    move-result v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0, v3, v4, v1, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public final d()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->F()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final e()LC6/a$c;
    .locals 8

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->f()Le5/ga;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$c;

    invoke-virtual {p0}, Le5/ga;->n()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Le5/ga;->f()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0}, Le5/ga;->g()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Le5/ga;->j()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Le5/ga;->k()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0}, Le5/ga;->e()Le5/fa;

    move-result-object v6

    invoke-static {v6}, LE6/m;->o(Le5/fa;)LC6/a$b;

    move-result-object v6

    invoke-virtual {p0}, Le5/ga;->b()Le5/fa;

    move-result-object p0

    invoke-static {p0}, LE6/m;->o(Le5/fa;)LC6/a$b;

    move-result-object v7

    invoke-direct/range {v0 .. v7}, LC6/a$c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LC6/a$b;LC6/a$b;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final f()I
    .locals 0

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->e()I

    move-result p0

    return p0
.end method

.method public final g()LC6/a$j;
    .locals 2

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->z()Le5/na;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$j;

    invoke-virtual {p0}, Le5/na;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Le5/na;->e()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, LC6/a$j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getFormat()I
    .locals 0

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->b()I

    move-result p0

    return p0
.end method

.method public final getUrl()LC6/a$k;
    .locals 2

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->A()Le5/oa;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$k;

    invoke-virtual {p0}, Le5/oa;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Le5/oa;->e()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, LC6/a$k;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final h()LC6/a$d;
    .locals 14

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->g()Le5/ha;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_8

    new-instance v1, LC6/a$d;

    invoke-virtual {p0}, Le5/ha;->b()Le5/la;

    move-result-object v2

    if-nez v2, :cond_0

    move-object v2, v0

    goto :goto_0

    :cond_0
    new-instance v3, LC6/a$h;

    invoke-virtual {v2}, Le5/la;->e()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2}, Le5/la;->k()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2}, Le5/la;->j()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2}, Le5/la;->b()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2}, Le5/la;->g()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2}, Le5/la;->f()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2}, Le5/la;->n()Ljava/lang/String;

    move-result-object v10

    invoke-direct/range {v3 .. v10}, LC6/a$h;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v2, v3

    :goto_0
    invoke-virtual {p0}, Le5/ha;->e()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Le5/ha;->f()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0}, Le5/ha;->k()[Le5/ma;

    move-result-object v0

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    move v7, v6

    :goto_1
    array-length v8, v0

    if-ge v7, v8, :cond_2

    aget-object v8, v0, v7

    if-eqz v8, :cond_1

    new-instance v9, LC6/a$i;

    invoke-virtual {v8}, Le5/ma;->e()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8}, Le5/ma;->b()I

    move-result v8

    invoke-direct {v9, v10, v8}, LC6/a$i;-><init>(Ljava/lang/String;I)V

    invoke-interface {v5, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Le5/ha;->j()[Le5/ja;

    move-result-object v0

    move v7, v6

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    if-eqz v0, :cond_4

    move v8, v7

    :goto_2
    array-length v9, v0

    if-ge v8, v9, :cond_4

    aget-object v9, v0, v8

    if-eqz v9, :cond_3

    new-instance v10, LC6/a$f;

    invoke-virtual {v9}, Le5/ja;->b()I

    move-result v11

    invoke-virtual {v9}, Le5/ja;->e()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9}, Le5/ja;->g()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v9}, Le5/ja;->f()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v10, v11, v12, v13, v9}, LC6/a$f;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v6, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    :cond_4
    invoke-virtual {p0}, Le5/ha;->n()[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_5

    invoke-virtual {p0}, Le5/ha;->n()[Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, LP4/p;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_3

    :cond_5
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_3
    invoke-virtual {p0}, Le5/ha;->g()[Le5/ea;

    move-result-object p0

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_7

    :goto_4
    array-length v9, p0

    if-ge v7, v9, :cond_7

    aget-object v9, p0, v7

    if-eqz v9, :cond_6

    new-instance v10, LC6/a$a;

    invoke-virtual {v9}, Le5/ea;->b()I

    move-result v11

    invoke-virtual {v9}, Le5/ea;->e()[Ljava/lang/String;

    move-result-object v9

    invoke-direct {v10, v11, v9}, LC6/a$a;-><init>(I[Ljava/lang/String;)V

    invoke-interface {v8, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_7
    move-object v7, v0

    invoke-direct/range {v1 .. v8}, LC6/a$d;-><init>(LC6/a$h;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    return-object v1

    :cond_8
    return-object v0
.end method

.method public final i()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->E()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final j()[B
    .locals 0

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->G()[B

    move-result-object p0

    return-object p0
.end method

.method public final k()[Landroid/graphics/Point;
    .locals 0

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->H()[Landroid/graphics/Point;

    move-result-object p0

    return-object p0
.end method

.method public final l()LC6/a$f;
    .locals 4

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->k()Le5/ja;

    move-result-object p0

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, LC6/a$f;

    invoke-virtual {p0}, Le5/ja;->b()I

    move-result v1

    invoke-virtual {p0}, Le5/ja;->e()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0}, Le5/ja;->g()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Le5/ja;->f()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, v2, v3, p0}, LC6/a$f;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public final m()LC6/a$g;
    .locals 5

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->n()Le5/ka;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$g;

    invoke-virtual {p0}, Le5/ka;->b()D

    move-result-wide v1

    invoke-virtual {p0}, Le5/ka;->e()D

    move-result-wide v3

    invoke-direct {v0, v1, v2, v3, v4}, LC6/a$g;-><init>(DD)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final n()LC6/a$l;
    .locals 3

    iget-object p0, p0, LE6/m;->a:Le5/ra;

    invoke-virtual {p0}, Le5/ra;->D()Le5/qa;

    move-result-object p0

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$l;

    invoke-virtual {p0}, Le5/qa;->f()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Le5/qa;->e()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0}, Le5/qa;->b()I

    move-result p0

    invoke-direct {v0, v1, v2, p0}, LC6/a$l;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method
