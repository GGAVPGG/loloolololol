.class public final LE6/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD6/a;


# instance fields
.field private final a:Le5/y8;


# direct methods
.method public constructor <init>(Le5/y8;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/o;->a:Le5/y8;

    return-void
.end method

.method private static o(Le5/N2;)LC6/a$b;
    .locals 9

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, LC6/a$b;

    iget v1, p0, Le5/N2;->f:I

    iget v2, p0, Le5/N2;->g:I

    iget v3, p0, Le5/N2;->h:I

    iget v4, p0, Le5/N2;->i:I

    iget v5, p0, Le5/N2;->j:I

    iget v6, p0, Le5/N2;->k:I

    iget-boolean v7, p0, Le5/N2;->l:Z

    iget-object v8, p0, Le5/N2;->m:Ljava/lang/String;

    invoke-direct/range {v0 .. v8}, LC6/a$b;-><init>(IIIIIIZLjava/lang/String;)V

    return-object v0
.end method


# virtual methods
.method public final a()LC6/a$i;
    .locals 2

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->l:Le5/u6;

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$i;

    iget-object v1, p0, Le5/u6;->g:Ljava/lang/String;

    iget p0, p0, Le5/u6;->f:I

    invoke-direct {v0, v1, p0}, LC6/a$i;-><init>(Ljava/lang/String;I)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final b()LC6/a$e;
    .locals 15

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->s:Le5/q4;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, LC6/a$e;

    iget-object v1, p0, Le5/q4;->f:Ljava/lang/String;

    iget-object v2, p0, Le5/q4;->g:Ljava/lang/String;

    iget-object v3, p0, Le5/q4;->h:Ljava/lang/String;

    iget-object v4, p0, Le5/q4;->i:Ljava/lang/String;

    iget-object v5, p0, Le5/q4;->j:Ljava/lang/String;

    iget-object v6, p0, Le5/q4;->k:Ljava/lang/String;

    iget-object v7, p0, Le5/q4;->l:Ljava/lang/String;

    iget-object v8, p0, Le5/q4;->m:Ljava/lang/String;

    iget-object v9, p0, Le5/q4;->n:Ljava/lang/String;

    iget-object v10, p0, Le5/q4;->o:Ljava/lang/String;

    iget-object v11, p0, Le5/q4;->p:Ljava/lang/String;

    iget-object v12, p0, Le5/q4;->q:Ljava/lang/String;

    iget-object v13, p0, Le5/q4;->r:Ljava/lang/String;

    iget-object v14, p0, Le5/q4;->s:Ljava/lang/String;

    invoke-direct/range {v0 .. v14}, LC6/a$e;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v0
.end method

.method public final c()Landroid/graphics/Rect;
    .locals 7

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object v0, p0, Le5/y8;->j:[Landroid/graphics/Point;

    if-eqz v0, :cond_1

    const/4 v0, 0x0

    const/high16 v1, -0x80000000

    const v2, 0x7fffffff

    move v3, v2

    move v4, v3

    move v2, v1

    :goto_0
    iget-object v5, p0, Le5/y8;->j:[Landroid/graphics/Point;

    array-length v6, v5

    if-ge v0, v6, :cond_0

    aget-object v5, v5, v0

    iget v6, v5, Landroid/graphics/Point;->x:I

    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    move-result v3

    iget v6, v5, Landroid/graphics/Point;->x:I

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget v6, v5, Landroid/graphics/Point;->y:I

    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    move-result v4

    iget v5, v5, Landroid/graphics/Point;->y:I

    invoke-static {v2, v5}, Ljava/lang/Math;->max(II)I

    move-result v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0, v3, v4, v1, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public final d()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->g:Ljava/lang/String;

    return-object p0
.end method

.method public final e()LC6/a$c;
    .locals 8

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->q:Le5/o3;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, LC6/a$c;

    iget-object v1, p0, Le5/o3;->f:Ljava/lang/String;

    iget-object v2, p0, Le5/o3;->g:Ljava/lang/String;

    iget-object v3, p0, Le5/o3;->h:Ljava/lang/String;

    iget-object v4, p0, Le5/o3;->i:Ljava/lang/String;

    iget-object v5, p0, Le5/o3;->j:Ljava/lang/String;

    iget-object v6, p0, Le5/o3;->k:Le5/N2;

    invoke-static {v6}, LE6/o;->o(Le5/N2;)LC6/a$b;

    move-result-object v6

    iget-object p0, p0, Le5/o3;->l:Le5/N2;

    invoke-static {p0}, LE6/o;->o(Le5/N2;)LC6/a$b;

    move-result-object v7

    invoke-direct/range {v0 .. v7}, LC6/a$c;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LC6/a$b;LC6/a$b;)V

    return-object v0
.end method

.method public final f()I
    .locals 0

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget p0, p0, Le5/y8;->i:I

    return p0
.end method

.method public final g()LC6/a$j;
    .locals 2

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->m:Le5/V6;

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$j;

    iget-object v1, p0, Le5/V6;->f:Ljava/lang/String;

    iget-object p0, p0, Le5/V6;->g:Ljava/lang/String;

    invoke-direct {v0, v1, p0}, LC6/a$j;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getFormat()I
    .locals 0

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget p0, p0, Le5/y8;->f:I

    return p0
.end method

.method public final getUrl()LC6/a$k;
    .locals 2

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->o:Le5/w7;

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$k;

    iget-object v1, p0, Le5/w7;->f:Ljava/lang/String;

    iget-object p0, p0, Le5/w7;->g:Ljava/lang/String;

    invoke-direct {v0, v1, p0}, LC6/a$k;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final h()LC6/a$d;
    .locals 14

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->r:Le5/P3;

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    new-instance v1, LC6/a$d;

    iget-object v2, p0, Le5/P3;->f:Le5/T5;

    if-nez v2, :cond_1

    move-object v2, v0

    goto :goto_0

    :cond_1
    new-instance v3, LC6/a$h;

    iget-object v4, v2, Le5/T5;->f:Ljava/lang/String;

    iget-object v5, v2, Le5/T5;->g:Ljava/lang/String;

    iget-object v6, v2, Le5/T5;->h:Ljava/lang/String;

    iget-object v7, v2, Le5/T5;->i:Ljava/lang/String;

    iget-object v8, v2, Le5/T5;->j:Ljava/lang/String;

    iget-object v9, v2, Le5/T5;->k:Ljava/lang/String;

    iget-object v10, v2, Le5/T5;->l:Ljava/lang/String;

    invoke-direct/range {v3 .. v10}, LC6/a$h;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v2, v3

    :goto_0
    iget-object v3, p0, Le5/P3;->g:Ljava/lang/String;

    iget-object v4, p0, Le5/P3;->h:Ljava/lang/String;

    iget-object v0, p0, Le5/P3;->i:[Le5/u6;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    if-eqz v0, :cond_3

    move v7, v6

    :goto_1
    array-length v8, v0

    if-ge v7, v8, :cond_3

    aget-object v8, v0, v7

    if-eqz v8, :cond_2

    new-instance v9, LC6/a$i;

    iget-object v10, v8, Le5/u6;->g:Ljava/lang/String;

    iget v8, v8, Le5/u6;->f:I

    invoke-direct {v9, v10, v8}, LC6/a$i;-><init>(Ljava/lang/String;I)V

    invoke-interface {v5, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_3
    iget-object v0, p0, Le5/P3;->j:[Le5/R4;

    move v7, v6

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    if-eqz v0, :cond_5

    move v8, v7

    :goto_2
    array-length v9, v0

    if-ge v8, v9, :cond_5

    aget-object v9, v0, v8

    if-eqz v9, :cond_4

    new-instance v10, LC6/a$f;

    iget v11, v9, Le5/R4;->f:I

    iget-object v12, v9, Le5/R4;->g:Ljava/lang/String;

    iget-object v13, v9, Le5/R4;->h:Ljava/lang/String;

    iget-object v9, v9, Le5/R4;->i:Ljava/lang/String;

    invoke-direct {v10, v11, v12, v13, v9}, LC6/a$f;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v6, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    :cond_5
    iget-object v0, p0, Le5/P3;->k:[Ljava/lang/String;

    if-eqz v0, :cond_6

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_3

    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_3
    iget-object p0, p0, Le5/P3;->l:[Le5/m2;

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_8

    :goto_4
    array-length v9, p0

    if-ge v7, v9, :cond_8

    aget-object v9, p0, v7

    if-eqz v9, :cond_7

    new-instance v10, LC6/a$a;

    iget v11, v9, Le5/m2;->f:I

    iget-object v9, v9, Le5/m2;->g:[Ljava/lang/String;

    invoke-direct {v10, v11, v9}, LC6/a$a;-><init>(I[Ljava/lang/String;)V

    invoke-interface {v8, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_7
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_8
    move-object v7, v0

    invoke-direct/range {v1 .. v8}, LC6/a$d;-><init>(LC6/a$h;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V

    return-object v1
.end method

.method public final i()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->h:Ljava/lang/String;

    return-object p0
.end method

.method public final j()[B
    .locals 0

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->t:[B

    return-object p0
.end method

.method public final k()[Landroid/graphics/Point;
    .locals 0

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->j:[Landroid/graphics/Point;

    return-object p0
.end method

.method public final l()LC6/a$f;
    .locals 4

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->k:Le5/R4;

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$f;

    iget v1, p0, Le5/R4;->f:I

    iget-object v2, p0, Le5/R4;->g:Ljava/lang/String;

    iget-object v3, p0, Le5/R4;->h:Ljava/lang/String;

    iget-object p0, p0, Le5/R4;->i:Ljava/lang/String;

    invoke-direct {v0, v1, v2, v3, p0}, LC6/a$f;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final m()LC6/a$g;
    .locals 5

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->p:Le5/s5;

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$g;

    iget-wide v1, p0, Le5/s5;->f:D

    iget-wide v3, p0, Le5/s5;->g:D

    invoke-direct {v0, v1, v2, v3, v4}, LC6/a$g;-><init>(DD)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final n()LC6/a$l;
    .locals 3

    iget-object p0, p0, LE6/o;->a:Le5/y8;

    iget-object p0, p0, Le5/y8;->n:Le5/X7;

    if-eqz p0, :cond_0

    new-instance v0, LC6/a$l;

    iget-object v1, p0, Le5/X7;->f:Ljava/lang/String;

    iget-object v2, p0, Le5/X7;->g:Ljava/lang/String;

    iget p0, p0, Le5/X7;->h:I

    invoke-direct {v0, v1, v2, p0}, LC6/a$l;-><init>(Ljava/lang/String;Ljava/lang/String;I)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method
