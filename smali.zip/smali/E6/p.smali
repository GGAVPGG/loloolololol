.class final LE6/p;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE6/l;


# instance fields
.field private a:Z

.field private final b:Landroid/content/Context;

.field private final c:Le5/i;

.field private final d:Le5/M9;

.field private e:Le5/k;


# direct methods
.method constructor <init>(Landroid/content/Context;LB6/b;Le5/M9;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Le5/i;

    invoke-direct {v0}, Le5/i;-><init>()V

    iput-object v0, p0, LE6/p;->c:Le5/i;

    iput-object p1, p0, LE6/p;->b:Landroid/content/Context;

    invoke-virtual {p2}, LB6/b;->a()I

    move-result p1

    iput p1, v0, Le5/i;->f:I

    iput-object p3, p0, LE6/p;->d:Le5/M9;

    return-void
.end method


# virtual methods
.method public final d()Z
    .locals 4

    iget-object v0, p0, LE6/p;->e:Le5/k;

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    const/16 v0, 0xd

    :try_start_0
    iget-object v1, p0, LE6/p;->b:Landroid/content/Context;

    sget-object v2, Lcom/google/android/gms/dynamite/DynamiteModule;->b:Lcom/google/android/gms/dynamite/DynamiteModule$b;

    const-string v3, "com.google.android.gms.vision.dynamite"

    invoke-static {v1, v2, v3}, Lcom/google/android/gms/dynamite/DynamiteModule;->d(Landroid/content/Context;Lcom/google/android/gms/dynamite/DynamiteModule$b;Ljava/lang/String;)Lcom/google/android/gms/dynamite/DynamiteModule;

    move-result-object v1

    const-string v2, "com.google.android.gms.vision.barcode.ChimeraNativeBarcodeDetectorCreator"

    invoke-virtual {v1, v2}, Lcom/google/android/gms/dynamite/DynamiteModule;->c(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Le5/m;->b(Landroid/os/IBinder;)Le5/n;

    move-result-object v1

    iget-object v2, p0, LE6/p;->b:Landroid/content/Context;

    invoke-static {v2}, LX4/b;->p1(Ljava/lang/Object;)LX4/a;

    move-result-object v2

    iget-object v3, p0, LE6/p;->c:Le5/i;

    invoke-interface {v1, v2, v3}, Le5/n;->b1(LX4/a;Le5/i;)Le5/k;

    move-result-object v1

    iput-object v1, p0, LE6/p;->e:Le5/k;

    if-nez v1, :cond_2

    iget-boolean v1, p0, LE6/p;->a:Z

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    const-string v1, "LegacyBarcodeScanner"

    const-string v2, "Request optional module download."

    invoke-static {v1, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v1, p0, LE6/p;->b:Landroid/content/Context;

    const-string v2, "barcode"

    invoke-static {v1, v2}, Lz6/l;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x1

    iput-boolean v1, p0, LE6/p;->a:Z

    iget-object p0, p0, LE6/p;->d:Le5/M9;

    sget-object v1, Le5/X6;->H:Le5/X6;

    invoke-static {p0, v1}, LE6/b;->e(Le5/M9;Le5/X6;)V

    new-instance p0, Lv6/a;

    const-string v1, "Waiting for the barcode module to be downloaded. Please wait."

    const/16 v2, 0xe

    invoke-direct {p0, v1, v2}, Lv6/a;-><init>(Ljava/lang/String;I)V

    throw p0

    :catch_0
    move-exception p0

    goto :goto_2

    :catch_1
    move-exception p0

    goto :goto_3

    :cond_2
    :goto_0
    iget-object p0, p0, LE6/p;->d:Le5/M9;

    sget-object v1, Le5/X6;->g:Le5/X6;

    invoke-static {p0, v1}, LE6/b;->e(Le5/M9;Le5/X6;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    const/4 p0, 0x0

    return p0

    :goto_2
    new-instance v1, Lv6/a;

    const-string v2, "Failed to load deprecated vision dynamite module."

    invoke-direct {v1, v2, v0, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw v1

    :goto_3
    new-instance v1, Lv6/a;

    const-string v2, "Failed to create legacy barcode detector."

    invoke-direct {v1, v2, v0, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw v1
.end method

.method public final e(LH6/a;)Ljava/util/List;
    .locals 7

    iget-object v0, p0, LE6/p;->e:Le5/k;

    if-nez v0, :cond_0

    invoke-virtual {p0}, LE6/p;->d()Z

    :cond_0
    iget-object p0, p0, LE6/p;->e:Le5/k;

    if-eqz p0, :cond_6

    invoke-static {p0}, LP4/p;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Le5/k;

    new-instance v0, Le5/o;

    invoke-virtual {p1}, LH6/a;->j()I

    move-result v1

    invoke-virtual {p1}, LH6/a;->f()I

    move-result v2

    invoke-virtual {p1}, LH6/a;->i()I

    move-result v3

    invoke-static {v3}, LI6/b;->a(I)I

    move-result v6

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    invoke-direct/range {v0 .. v6}, Le5/o;-><init>(IIIJI)V

    :try_start_0
    invoke-virtual {p1}, LH6/a;->e()I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    if-eq v1, v2, :cond_4

    const/16 v2, 0x11

    if-eq v1, v2, :cond_3

    const/16 v2, 0x23

    if-eq v1, v2, :cond_2

    const v2, 0x32315659

    if-ne v1, v2, :cond_1

    invoke-static {}, LI6/c;->d()LI6/c;

    move-result-object v1

    invoke-virtual {v1, p1, v3}, LI6/c;->c(LH6/a;Z)Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-static {v1}, LX4/b;->p1(Ljava/lang/Object;)LX4/a;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Le5/k;->p1(LX4/a;Le5/o;)[Le5/y8;

    move-result-object p0

    goto :goto_0

    :cond_1
    new-instance p0, Lv6/a;

    invoke-virtual {p1}, LH6/a;->e()I

    move-result p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unsupported image format: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x3

    invoke-direct {p0, p1, v0}, Lv6/a;-><init>(Ljava/lang/String;I)V

    throw p0

    :cond_2
    invoke-virtual {p1}, LH6/a;->h()[Landroid/media/Image$Plane;

    move-result-object v1

    invoke-static {v1}, LP4/p;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Landroid/media/Image$Plane;

    aget-object v2, v1, v3

    invoke-virtual {v2}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v2

    iput v2, v0, Le5/o;->f:I

    aget-object v1, v1, v3

    invoke-virtual {v1}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-static {v1}, LX4/b;->p1(Ljava/lang/Object;)LX4/a;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Le5/k;->p1(LX4/a;Le5/o;)[Le5/y8;

    move-result-object p0

    goto :goto_0

    :cond_3
    invoke-virtual {p1}, LH6/a;->c()Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-static {v1}, LX4/b;->p1(Ljava/lang/Object;)LX4/a;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Le5/k;->p1(LX4/a;Le5/o;)[Le5/y8;

    move-result-object p0

    goto :goto_0

    :cond_4
    invoke-virtual {p1}, LH6/a;->b()Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-static {v1}, LX4/b;->p1(Ljava/lang/Object;)LX4/a;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Le5/k;->q1(LX4/a;Le5/o;)[Le5/y8;

    move-result-object p0

    :goto_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    array-length v1, p0

    :goto_1
    if-ge v3, v1, :cond_5

    aget-object v2, p0, v3

    new-instance v4, LC6/a;

    new-instance v5, LE6/o;

    invoke-direct {v5, v2}, LE6/o;-><init>(Le5/y8;)V

    invoke-virtual {p1}, LH6/a;->d()Landroid/graphics/Matrix;

    move-result-object v2

    invoke-direct {v4, v5, v2}, LC6/a;-><init>(LD6/a;Landroid/graphics/Matrix;)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_5
    return-object v0

    :catch_0
    move-exception v0

    move-object p0, v0

    new-instance p1, Lv6/a;

    const-string v0, "Failed to detect with legacy barcode detector"

    const/16 v1, 0xd

    invoke-direct {p1, v0, v1, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw p1

    :cond_6
    new-instance p0, Lv6/a;

    const-string p1, "Error initializing the legacy barcode scanner."

    const/16 v0, 0xe

    invoke-direct {p0, p1, v0}, Lv6/a;-><init>(Ljava/lang/String;I)V

    throw p0
.end method

.method public final zzb()V
    .locals 3

    iget-object v0, p0, LE6/p;->e:Le5/k;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-virtual {v0}, Le5/k;->a()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    const-string v1, "LegacyBarcodeScanner"

    const-string v2, "Failed to release legacy barcode detector."

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v0, 0x0

    iput-object v0, p0, LE6/p;->e:Le5/k;

    :cond_0
    return-void
.end method
