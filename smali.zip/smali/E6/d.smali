.class public final synthetic LE6/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La6/g;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(La6/d;)Ljava/lang/Object;
    .locals 3

    new-instance p0, LE6/f;

    const-class v0, LE6/h;

    invoke-interface {p1, v0}, La6/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LE6/h;

    const-class v1, Lz6/d;

    invoke-interface {p1, v1}, La6/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lz6/d;

    const-class v2, Lz6/i;

    invoke-interface {p1, v2}, La6/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lz6/i;

    invoke-direct {p0, v0, v1, p1}, LE6/f;-><init>(LE6/h;Lz6/d;Lz6/i;)V

    return-object p0
.end method
