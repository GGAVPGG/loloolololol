.class public final synthetic LE6/j;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:LE6/k;


# direct methods
.method public synthetic constructor <init>(LE6/k;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/j;->a:LE6/k;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;ILe5/y6;)Le5/B9;
    .locals 0

    iget-object p0, p0, LE6/j;->a:LE6/k;

    check-cast p1, Le5/e1;

    invoke-virtual {p0, p1, p2, p3}, LE6/k;->k(Le5/e1;ILe5/y6;)Le5/B9;

    move-result-object p0

    return-object p0
.end method
