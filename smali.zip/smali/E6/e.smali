.class public final synthetic LE6/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv5/k;


# instance fields
.field public final synthetic a:LE6/g;

.field public final synthetic b:I

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(LE6/g;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/e;->a:LE6/g;

    iput p2, p0, LE6/e;->b:I

    iput p3, p0, LE6/e;->c:I

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Lv5/l;
    .locals 2

    iget-object v0, p0, LE6/e;->a:LE6/g;

    iget v1, p0, LE6/e;->b:I

    iget p0, p0, LE6/e;->c:I

    check-cast p1, Ljava/util/List;

    invoke-virtual {v0, v1, p0, p1}, LE6/g;->F(IILjava/util/List;)Lv5/l;

    move-result-object p0

    return-object p0
.end method
