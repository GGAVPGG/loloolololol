.class final LE6/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LE6/l;


# static fields
.field private static final h:Le5/j0;


# instance fields
.field private a:Z

.field private b:Z

.field private c:Z

.field private final d:Landroid/content/Context;

.field private final e:LB6/b;

.field private final f:Le5/M9;

.field private g:Le5/Ba;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "com.google.android.gms.vision.barcode"

    const-string v1, "com.google.android.gms.tflite_dynamite"

    invoke-static {v0, v1}, Le5/j0;->h(Ljava/lang/Object;Ljava/lang/Object;)Le5/j0;

    move-result-object v0

    sput-object v0, LE6/n;->h:Le5/j0;

    return-void
.end method

.method constructor <init>(Landroid/content/Context;LB6/b;Le5/M9;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/n;->d:Landroid/content/Context;

    iput-object p2, p0, LE6/n;->e:LB6/b;

    iput-object p3, p0, LE6/n;->f:Le5/M9;

    return-void
.end method

.method static a(Landroid/content/Context;)Z
    .locals 1

    const-string v0, "com.google.mlkit.dynamite.barcode"

    invoke-static {p0, v0}, Lcom/google/android/gms/dynamite/DynamiteModule;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    if-lez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method final b(Lcom/google/android/gms/dynamite/DynamiteModule$b;Ljava/lang/String;Ljava/lang/String;)Le5/Ba;
    .locals 2

    iget-object v0, p0, LE6/n;->d:Landroid/content/Context;

    invoke-static {v0, p1, p2}, Lcom/google/android/gms/dynamite/DynamiteModule;->d(Landroid/content/Context;Lcom/google/android/gms/dynamite/DynamiteModule$b;Ljava/lang/String;)Lcom/google/android/gms/dynamite/DynamiteModule;

    move-result-object p1

    invoke-virtual {p1, p3}, Lcom/google/android/gms/dynamite/DynamiteModule;->c(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object p1

    invoke-static {p1}, Le5/Da;->b(Landroid/os/IBinder;)Le5/Ea;

    move-result-object p1

    iget-object p2, p0, LE6/n;->e:LB6/b;

    iget-object p3, p0, LE6/n;->d:Landroid/content/Context;

    invoke-static {p3}, LX4/b;->p1(Ljava/lang/Object;)LX4/a;

    move-result-object p3

    new-instance v0, Le5/ta;

    invoke-virtual {p2}, LB6/b;->a()I

    move-result v1

    invoke-virtual {p2}, LB6/b;->d()Z

    move-result p2

    if-nez p2, :cond_0

    iget-object p0, p0, LE6/n;->e:LB6/b;

    invoke-virtual {p0}, LB6/b;->b()LB6/d;

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    const/4 p0, 0x1

    :goto_0
    invoke-direct {v0, v1, p0}, Le5/ta;-><init>(IZ)V

    invoke-interface {p1, p3, v0}, Le5/Ea;->r0(LX4/a;Le5/ta;)Le5/Ba;

    move-result-object p0

    return-object p0
.end method

.method public final d()Z
    .locals 4

    iget-object v0, p0, LE6/n;->g:Le5/Ba;

    if-eqz v0, :cond_0

    iget-boolean p0, p0, LE6/n;->b:Z

    return p0

    :cond_0
    iget-object v0, p0, LE6/n;->d:Landroid/content/Context;

    invoke-static {v0}, LE6/n;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v1, 0x1

    const/16 v2, 0xd

    if-eqz v0, :cond_1

    iput-boolean v1, p0, LE6/n;->b:Z

    :try_start_0
    sget-object v0, Lcom/google/android/gms/dynamite/DynamiteModule;->c:Lcom/google/android/gms/dynamite/DynamiteModule$b;

    const-string v1, "com.google.mlkit.dynamite.barcode"

    const-string v3, "com.google.mlkit.vision.barcode.bundled.internal.ThickBarcodeScannerCreator"

    invoke-virtual {p0, v0, v1, v3}, LE6/n;->b(Lcom/google/android/gms/dynamite/DynamiteModule$b;Ljava/lang/String;Ljava/lang/String;)Le5/Ba;

    move-result-object v0

    iput-object v0, p0, LE6/n;->g:Le5/Ba;
    :try_end_0
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception p0

    goto :goto_0

    :catch_1
    move-exception p0

    goto :goto_1

    :goto_0
    new-instance v0, Lv6/a;

    const-string v1, "Failed to create thick barcode scanner."

    invoke-direct {v0, v1, v2, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw v0

    :goto_1
    new-instance v0, Lv6/a;

    const-string v1, "Failed to load the bundled barcode module."

    invoke-direct {v0, v1, v2, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw v0

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, LE6/n;->b:Z

    iget-object v0, p0, LE6/n;->d:Landroid/content/Context;

    sget-object v3, LE6/n;->h:Le5/j0;

    invoke-static {v0, v3}, Lz6/l;->a(Landroid/content/Context;Ljava/util/List;)Z

    move-result v0

    if-nez v0, :cond_3

    iget-boolean v0, p0, LE6/n;->c:Z

    if-nez v0, :cond_2

    iget-object v0, p0, LE6/n;->d:Landroid/content/Context;

    const-string v2, "barcode"

    const-string v3, "tflite_dynamite"

    invoke-static {v2, v3}, Le5/j0;->h(Ljava/lang/Object;Ljava/lang/Object;)Le5/j0;

    move-result-object v2

    invoke-static {v0, v2}, Lz6/l;->d(Landroid/content/Context;Ljava/util/List;)V

    iput-boolean v1, p0, LE6/n;->c:Z

    :cond_2
    iget-object p0, p0, LE6/n;->f:Le5/M9;

    sget-object v0, Le5/X6;->H:Le5/X6;

    invoke-static {p0, v0}, LE6/b;->e(Le5/M9;Le5/X6;)V

    new-instance p0, Lv6/a;

    const-string v0, "Waiting for the barcode module to be downloaded. Please wait."

    const/16 v1, 0xe

    invoke-direct {p0, v0, v1}, Lv6/a;-><init>(Ljava/lang/String;I)V

    throw p0

    :cond_3
    :try_start_1
    sget-object v0, Lcom/google/android/gms/dynamite/DynamiteModule;->b:Lcom/google/android/gms/dynamite/DynamiteModule$b;

    const-string v1, "com.google.android.gms.vision.barcode"

    const-string v3, "com.google.android.gms.vision.barcode.mlkit.BarcodeScannerCreator"

    invoke-virtual {p0, v0, v1, v3}, LE6/n;->b(Lcom/google/android/gms/dynamite/DynamiteModule$b;Ljava/lang/String;Ljava/lang/String;)Le5/Ba;

    move-result-object v0

    iput-object v0, p0, LE6/n;->g:Le5/Ba;
    :try_end_1
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_1 .. :try_end_1} :catch_2
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_2

    :goto_2
    iget-object v0, p0, LE6/n;->f:Le5/M9;

    sget-object v1, Le5/X6;->g:Le5/X6;

    invoke-static {v0, v1}, LE6/b;->e(Le5/M9;Le5/X6;)V

    iget-boolean p0, p0, LE6/n;->b:Z

    return p0

    :catch_2
    move-exception v0

    iget-object p0, p0, LE6/n;->f:Le5/M9;

    sget-object v1, Le5/X6;->I:Le5/X6;

    invoke-static {p0, v1}, LE6/b;->e(Le5/M9;Le5/X6;)V

    new-instance p0, Lv6/a;

    const-string v1, "Failed to create thin barcode scanner."

    invoke-direct {p0, v1, v2, v0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw p0
.end method

.method public final e(LH6/a;)Ljava/util/List;
    .locals 10

    iget-object v0, p0, LE6/n;->g:Le5/Ba;

    if-nez v0, :cond_0

    invoke-virtual {p0}, LE6/n;->d()Z

    :cond_0
    iget-object v0, p0, LE6/n;->g:Le5/Ba;

    invoke-static {v0}, LP4/p;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Le5/Ba;

    iget-boolean v1, p0, LE6/n;->a:Z

    const/16 v2, 0xd

    if-nez v1, :cond_1

    :try_start_0
    invoke-virtual {v0}, Le5/Ba;->q1()V

    const/4 v1, 0x1

    iput-boolean v1, p0, LE6/n;->a:Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    move-object p0, v0

    new-instance p1, Lv6/a;

    const-string v0, "Failed to init barcode scanner."

    invoke-direct {p1, v0, v2, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw p1

    :cond_1
    :goto_0
    invoke-virtual {p1}, LH6/a;->j()I

    move-result p0

    invoke-virtual {p1}, LH6/a;->e()I

    move-result v1

    const/16 v3, 0x23

    if-ne v1, v3, :cond_2

    invoke-virtual {p1}, LH6/a;->h()[Landroid/media/Image$Plane;

    move-result-object p0

    invoke-static {p0}, LP4/p;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroid/media/Image$Plane;

    const/4 v1, 0x0

    aget-object p0, p0, v1

    invoke-virtual {p0}, Landroid/media/Image$Plane;->getRowStride()I

    move-result p0

    :cond_2
    move v5, p0

    new-instance v3, Le5/Ka;

    invoke-virtual {p1}, LH6/a;->e()I

    move-result v4

    invoke-virtual {p1}, LH6/a;->f()I

    move-result v6

    invoke-virtual {p1}, LH6/a;->i()I

    move-result p0

    invoke-static {p0}, LI6/b;->a(I)I

    move-result v7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    invoke-direct/range {v3 .. v9}, Le5/Ka;-><init>(IIIIJ)V

    invoke-static {}, LI6/d;->b()LI6/d;

    move-result-object p0

    invoke-virtual {p0, p1}, LI6/d;->a(LH6/a;)LX4/a;

    move-result-object p0

    :try_start_1
    invoke-virtual {v0, p0, v3}, Le5/Ba;->p1(LX4/a;Le5/Ka;)Ljava/util/List;

    move-result-object p0
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Le5/ra;

    new-instance v2, LC6/a;

    new-instance v3, LE6/m;

    invoke-direct {v3, v1}, LE6/m;-><init>(Le5/ra;)V

    invoke-virtual {p1}, LH6/a;->d()Landroid/graphics/Matrix;

    move-result-object v1

    invoke-direct {v2, v3, v1}, LC6/a;-><init>(LD6/a;Landroid/graphics/Matrix;)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    return-object v0

    :catch_1
    move-exception v0

    move-object p0, v0

    new-instance p1, Lv6/a;

    const-string v0, "Failed to run barcode scanner."

    invoke-direct {p1, v0, v2, p0}, Lv6/a;-><init>(Ljava/lang/String;ILjava/lang/Throwable;)V

    throw p1
.end method

.method public final zzb()V
    .locals 3

    iget-object v0, p0, LE6/n;->g:Le5/Ba;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-virtual {v0}, Le5/Ba;->e()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    const-string v1, "DecoupledBarcodeScanner"

    const-string v2, "Failed to release barcode scanner."

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v0, 0x0

    iput-object v0, p0, LE6/n;->g:Le5/Ba;

    const/4 v0, 0x0

    iput-boolean v0, p0, LE6/n;->a:Z

    :cond_0
    return-void
.end method
