.class public final LE6/g;
.super LI6/e;
.source "SourceFile"

# interfaces
.implements LB6/a;


# static fields
.field private static final r:LB6/b;


# instance fields
.field private final m:Z

.field private final n:LB6/b;

.field final o:Le5/ba;

.field private p:I

.field private q:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LB6/b$a;

    invoke-direct {v0}, LB6/b$a;-><init>()V

    invoke-virtual {v0}, LB6/b$a;->a()LB6/b;

    move-result-object v0

    sput-object v0, LE6/g;->r:LB6/b;

    return-void
.end method

.method constructor <init>(LB6/b;LE6/k;Ljava/util/concurrent/Executor;Le5/M9;Lz6/i;)V
    .locals 0

    invoke-virtual {p1}, LB6/b;->b()LB6/d;

    invoke-direct {p0, p2, p3}, LI6/e;-><init>(Lz6/f;Ljava/util/concurrent/Executor;)V

    iput-object p1, p0, LE6/g;->n:LB6/b;

    invoke-static {}, LE6/b;->f()Z

    move-result p2

    iput-boolean p2, p0, LE6/g;->m:Z

    new-instance p3, Le5/l7;

    invoke-direct {p3}, Le5/l7;-><init>()V

    invoke-static {p1}, LE6/b;->c(LB6/b;)Le5/v9;

    move-result-object p1

    invoke-virtual {p3, p1}, Le5/l7;->i(Le5/v9;)Le5/l7;

    invoke-virtual {p3}, Le5/l7;->j()Le5/n7;

    move-result-object p1

    new-instance p3, Le5/Z6;

    invoke-direct {p3}, Le5/Z6;-><init>()V

    if-eqz p2, :cond_0

    sget-object p2, Le5/W6;->i:Le5/W6;

    goto :goto_0

    :cond_0
    sget-object p2, Le5/W6;->h:Le5/W6;

    :goto_0
    invoke-virtual {p3, p2}, Le5/Z6;->e(Le5/W6;)Le5/Z6;

    invoke-virtual {p3, p1}, Le5/Z6;->g(Le5/n7;)Le5/Z6;

    const/4 p1, 0x1

    invoke-static {p3, p1}, Le5/P9;->f(Le5/Z6;I)Le5/B9;

    move-result-object p1

    sget-object p2, Le5/Y6;->q:Le5/Y6;

    invoke-virtual {p4, p1, p2}, Le5/M9;->d(Le5/B9;Le5/Y6;)V

    const/4 p1, 0x0

    iput-object p1, p0, LE6/g;->o:Le5/ba;

    return-void
.end method

.method private final a0(Lv5/l;II)Lv5/l;
    .locals 1

    new-instance v0, LE6/e;

    invoke-direct {v0, p0, p2, p3}, LE6/e;-><init>(LE6/g;II)V

    invoke-virtual {p1, v0}, Lv5/l;->r(Lv5/k;)Lv5/l;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method final synthetic F(IILjava/util/List;)Lv5/l;
    .locals 0

    invoke-static {p3}, Lv5/o;->f(Ljava/lang/Object;)Lv5/l;

    move-result-object p0

    return-object p0
.end method

.method public final declared-synchronized close()V
    .locals 1

    monitor-enter p0

    :try_start_0
    invoke-super {p0}, LI6/e;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final d()[LM4/c;
    .locals 2

    iget-boolean p0, p0, LE6/g;->m:Z

    if-eqz p0, :cond_0

    sget-object p0, Lz6/l;->a:[LM4/c;

    return-object p0

    :cond_0
    const/4 p0, 0x1

    new-array p0, p0, [LM4/c;

    const/4 v0, 0x0

    sget-object v1, Lz6/l;->b:LM4/c;

    aput-object v1, p0, v0

    return-object p0
.end method

.method public final t1(LH6/a;)Lv5/l;
    .locals 2

    invoke-super {p0, p1}, LI6/e;->t(LH6/a;)Lv5/l;

    move-result-object v0

    invoke-virtual {p1}, LH6/a;->j()I

    move-result v1

    invoke-virtual {p1}, LH6/a;->f()I

    move-result p1

    invoke-direct {p0, v0, v1, p1}, LE6/g;->a0(Lv5/l;II)Lv5/l;

    move-result-object p0

    return-object p0
.end method
