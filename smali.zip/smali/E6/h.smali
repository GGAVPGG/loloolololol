.class public final LE6/h;
.super Lz6/e;
.source "SourceFile"


# instance fields
.field private final b:Lz6/i;


# direct methods
.method public constructor <init>(Lz6/i;)V
    .locals 0

    invoke-direct {p0}, Lz6/e;-><init>()V

    iput-object p1, p0, LE6/h;->b:Lz6/i;

    return-void
.end method


# virtual methods
.method protected final bridge synthetic a(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, LE6/h;->b:Lz6/i;

    check-cast p1, LB6/b;

    invoke-virtual {v0}, Lz6/i;->b()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, LE6/b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Le5/Y9;->b(Ljava/lang/String;)Le5/M9;

    move-result-object v1

    invoke-static {v0}, LE6/n;->a(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-static {}, LM4/e;->f()LM4/e;

    move-result-object v2

    invoke-virtual {v2, v0}, LM4/e;->a(Landroid/content/Context;)I

    move-result v2

    const v3, 0xc306c20

    if-lt v2, v3, :cond_0

    goto :goto_0

    :cond_0
    new-instance v2, LE6/p;

    invoke-direct {v2, v0, p1, v1}, LE6/p;-><init>(Landroid/content/Context;LB6/b;Le5/M9;)V

    goto :goto_1

    :cond_1
    :goto_0
    new-instance v2, LE6/n;

    invoke-direct {v2, v0, p1, v1}, LE6/n;-><init>(Landroid/content/Context;LB6/b;Le5/M9;)V

    :goto_1
    iget-object p0, p0, LE6/h;->b:Lz6/i;

    new-instance v0, LE6/k;

    invoke-direct {v0, p0, p1, v2, v1}, LE6/k;-><init>(Lz6/i;LB6/b;LE6/l;Le5/M9;)V

    return-object v0
.end method
