.class public final synthetic LE6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le5/L9;


# instance fields
.field public final synthetic a:Le5/X6;


# direct methods
.method public synthetic constructor <init>(Le5/X6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/a;->a:Le5/X6;

    return-void
.end method


# virtual methods
.method public final zza()Le5/B9;
    .locals 2

    new-instance v0, Le5/Z6;

    invoke-direct {v0}, Le5/Z6;-><init>()V

    invoke-static {}, LE6/b;->f()Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Le5/W6;->i:Le5/W6;

    goto :goto_0

    :cond_0
    sget-object v1, Le5/W6;->h:Le5/W6;

    :goto_0
    iget-object p0, p0, LE6/a;->a:Le5/X6;

    invoke-virtual {v0, v1}, Le5/Z6;->e(Le5/W6;)Le5/Z6;

    new-instance v1, Le5/o7;

    invoke-direct {v1}, Le5/o7;-><init>()V

    invoke-virtual {v1, p0}, Le5/o7;->b(Le5/X6;)Le5/o7;

    invoke-virtual {v1}, Le5/o7;->c()Le5/q7;

    move-result-object p0

    invoke-virtual {v0, p0}, Le5/Z6;->h(Le5/q7;)Le5/Z6;

    invoke-static {v0}, Le5/P9;->e(Le5/Z6;)Le5/B9;

    move-result-object p0

    return-object p0
.end method
