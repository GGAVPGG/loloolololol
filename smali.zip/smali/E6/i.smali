.class public final synthetic LE6/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le5/L9;


# instance fields
.field public final synthetic a:LE6/k;

.field public final synthetic b:J

.field public final synthetic c:Le5/X6;

.field public final synthetic d:Le5/g0;

.field public final synthetic e:Le5/g0;

.field public final synthetic f:LH6/a;


# direct methods
.method public synthetic constructor <init>(LE6/k;JLe5/X6;Le5/g0;Le5/g0;LH6/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LE6/i;->a:LE6/k;

    iput-wide p2, p0, LE6/i;->b:J

    iput-object p4, p0, LE6/i;->c:Le5/X6;

    iput-object p5, p0, LE6/i;->d:Le5/g0;

    iput-object p6, p0, LE6/i;->e:Le5/g0;

    iput-object p7, p0, LE6/i;->f:LH6/a;

    return-void
.end method


# virtual methods
.method public final zza()Le5/B9;
    .locals 7

    iget-object v0, p0, LE6/i;->a:LE6/k;

    iget-wide v1, p0, LE6/i;->b:J

    iget-object v3, p0, LE6/i;->c:Le5/X6;

    iget-object v4, p0, LE6/i;->d:Le5/g0;

    iget-object v5, p0, LE6/i;->e:Le5/g0;

    iget-object v6, p0, LE6/i;->f:LH6/a;

    invoke-virtual/range {v0 .. v6}, LE6/k;->j(JLe5/X6;Le5/g0;Le5/g0;LH6/a;)Le5/B9;

    move-result-object p0

    return-object p0
.end method
