.class public final synthetic LE6/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La6/g;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(La6/d;)Ljava/lang/Object;
    .locals 1

    new-instance p0, LE6/h;

    const-class v0, Lz6/i;

    invoke-interface {p1, v0}, La6/d;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lz6/i;

    invoke-direct {p0, p1}, LE6/h;-><init>(Lz6/i;)V

    return-object p0
.end method
