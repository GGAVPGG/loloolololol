.class LB5/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LB5/a;->X(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic f:Landroid/view/View;

.field final synthetic g:Landroid/widget/FrameLayout;

.field final synthetic h:LB5/a;


# direct methods
.method constructor <init>(LB5/a;Landroid/view/View;Landroid/widget/FrameLayout;)V
    .locals 0

    iput-object p1, p0, LB5/a$a;->h:LB5/a;

    iput-object p2, p0, LB5/a$a;->f:Landroid/view/View;

    iput-object p3, p0, LB5/a$a;->g:Landroid/widget/FrameLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    iget-object v0, p0, LB5/a$a;->h:LB5/a;

    iget-object v1, p0, LB5/a$a;->f:Landroid/view/View;

    iget-object p0, p0, LB5/a$a;->g:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v1, p0}, LB5/a;->Z(Landroid/view/View;Landroid/widget/FrameLayout;)V

    return-void
.end method
