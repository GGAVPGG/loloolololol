.class public final LB5/b$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LB5/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "LB5/b$a;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private A:Ljava/lang/Integer;

.field private B:Ljava/lang/Integer;

.field private C:Ljava/lang/Integer;

.field private D:Ljava/lang/Integer;

.field private E:Ljava/lang/Integer;

.field private F:Ljava/lang/Integer;

.field private G:Ljava/lang/Integer;

.field private H:Ljava/lang/Integer;

.field private I:Ljava/lang/Boolean;

.field private f:I

.field private g:Ljava/lang/Integer;

.field private h:Ljava/lang/Integer;

.field private i:Ljava/lang/Integer;

.field private j:Ljava/lang/Integer;

.field private k:Ljava/lang/Integer;

.field private l:Ljava/lang/Integer;

.field private m:Ljava/lang/Integer;

.field private n:I

.field private o:Ljava/lang/String;

.field private p:I

.field private q:I

.field private r:I

.field private s:Ljava/util/Locale;

.field private t:Ljava/lang/CharSequence;

.field private u:Ljava/lang/CharSequence;

.field private v:I

.field private w:I

.field private x:Ljava/lang/Integer;

.field private y:Ljava/lang/Boolean;

.field private z:Ljava/lang/Integer;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LB5/b$a$a;

    invoke-direct {v0}, LB5/b$a$a;-><init>()V

    sput-object v0, LB5/b$a;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xff

    .line 2
    iput v0, p0, LB5/b$a;->n:I

    const/4 v0, -0x2

    .line 3
    iput v0, p0, LB5/b$a;->p:I

    .line 4
    iput v0, p0, LB5/b$a;->q:I

    .line 5
    iput v0, p0, LB5/b$a;->r:I

    .line 6
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object v0, p0, LB5/b$a;->y:Ljava/lang/Boolean;

    return-void
.end method

.method constructor <init>(Landroid/os/Parcel;)V
    .locals 1

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xff

    .line 8
    iput v0, p0, LB5/b$a;->n:I

    const/4 v0, -0x2

    .line 9
    iput v0, p0, LB5/b$a;->p:I

    .line 10
    iput v0, p0, LB5/b$a;->q:I

    .line 11
    iput v0, p0, LB5/b$a;->r:I

    .line 12
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iput-object v0, p0, LB5/b$a;->y:Ljava/lang/Boolean;

    .line 13
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, LB5/b$a;->f:I

    .line 14
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->g:Ljava/lang/Integer;

    .line 15
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->h:Ljava/lang/Integer;

    .line 16
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->i:Ljava/lang/Integer;

    .line 17
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->j:Ljava/lang/Integer;

    .line 18
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->k:Ljava/lang/Integer;

    .line 19
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->l:Ljava/lang/Integer;

    .line 20
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->m:Ljava/lang/Integer;

    .line 21
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, LB5/b$a;->n:I

    .line 22
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LB5/b$a;->o:Ljava/lang/String;

    .line 23
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, LB5/b$a;->p:I

    .line 24
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, LB5/b$a;->q:I

    .line 25
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, LB5/b$a;->r:I

    .line 26
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LB5/b$a;->t:Ljava/lang/CharSequence;

    .line 27
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, LB5/b$a;->u:Ljava/lang/CharSequence;

    .line 28
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, LB5/b$a;->v:I

    .line 29
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->x:Ljava/lang/Integer;

    .line 30
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->z:Ljava/lang/Integer;

    .line 31
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->A:Ljava/lang/Integer;

    .line 32
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->B:Ljava/lang/Integer;

    .line 33
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->C:Ljava/lang/Integer;

    .line 34
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->D:Ljava/lang/Integer;

    .line 35
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->E:Ljava/lang/Integer;

    .line 36
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->H:Ljava/lang/Integer;

    .line 37
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->F:Ljava/lang/Integer;

    .line 38
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p0, LB5/b$a;->G:Ljava/lang/Integer;

    .line 39
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    iput-object v0, p0, LB5/b$a;->y:Ljava/lang/Boolean;

    .line 40
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Ljava/util/Locale;

    iput-object v0, p0, LB5/b$a;->s:Ljava/util/Locale;

    .line 41
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    iput-object p1, p0, LB5/b$a;->I:Ljava/lang/Boolean;

    return-void
.end method

.method static synthetic A(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->l:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic D(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->l:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic E(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->m:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic F(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->m:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic G(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->g:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic H(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->g:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic I(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->i:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic J(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->i:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic K(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->h:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic L(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->h:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic M(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->x:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic N(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->x:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic O(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->z:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic P(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->z:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic Q(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->p:I

    return p0
.end method

.method static synthetic R(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->A:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic S(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->A:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic T(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->p:I

    return p1
.end method

.method static synthetic U(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->B:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic V(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->B:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic W(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->C:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic X(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->C:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic Y(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->D:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic Z(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->D:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic a(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->f:I

    return p0
.end method

.method static synthetic a0(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->E:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic b(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->f:I

    return p1
.end method

.method static synthetic b0(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->E:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic c0(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->H:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic d0(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->H:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic e(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->n:I

    return p0
.end method

.method static synthetic e0(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->F:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic f(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->r:I

    return p0
.end method

.method static synthetic f0(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->F:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic g(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->r:I

    return p1
.end method

.method static synthetic g0(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->G:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic h0(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->G:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic i0(LB5/b$a;)Ljava/lang/Boolean;
    .locals 0

    iget-object p0, p0, LB5/b$a;->I:Ljava/lang/Boolean;

    return-object p0
.end method

.method static synthetic j(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->n:I

    return p1
.end method

.method static synthetic j0(LB5/b$a;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    .locals 0

    iput-object p1, p0, LB5/b$a;->I:Ljava/lang/Boolean;

    return-object p1
.end method

.method static synthetic k(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->j:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic k0(LB5/b$a;)Ljava/util/Locale;
    .locals 0

    iget-object p0, p0, LB5/b$a;->s:Ljava/util/Locale;

    return-object p0
.end method

.method static synthetic l0(LB5/b$a;Ljava/util/Locale;)Ljava/util/Locale;
    .locals 0

    iput-object p1, p0, LB5/b$a;->s:Ljava/util/Locale;

    return-object p1
.end method

.method static synthetic m0(LB5/b$a;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LB5/b$a;->o:Ljava/lang/String;

    return-object p0
.end method

.method static synthetic n(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->j:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic n0(LB5/b$a;Ljava/lang/String;)Ljava/lang/String;
    .locals 0

    iput-object p1, p0, LB5/b$a;->o:Ljava/lang/String;

    return-object p1
.end method

.method static synthetic o0(LB5/b$a;)Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, LB5/b$a;->t:Ljava/lang/CharSequence;

    return-object p0
.end method

.method static synthetic p(LB5/b$a;)Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, LB5/b$a;->k:Ljava/lang/Integer;

    return-object p0
.end method

.method static synthetic p0(LB5/b$a;Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .locals 0

    iput-object p1, p0, LB5/b$a;->t:Ljava/lang/CharSequence;

    return-object p1
.end method

.method static synthetic q0(LB5/b$a;)Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, LB5/b$a;->u:Ljava/lang/CharSequence;

    return-object p0
.end method

.method static synthetic r0(LB5/b$a;Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .locals 0

    iput-object p1, p0, LB5/b$a;->u:Ljava/lang/CharSequence;

    return-object p1
.end method

.method static synthetic s0(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->v:I

    return p0
.end method

.method static synthetic t0(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->v:I

    return p1
.end method

.method static synthetic u0(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->w:I

    return p0
.end method

.method static synthetic v0(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->w:I

    return p1
.end method

.method static synthetic w0(LB5/b$a;)Ljava/lang/Boolean;
    .locals 0

    iget-object p0, p0, LB5/b$a;->y:Ljava/lang/Boolean;

    return-object p0
.end method

.method static synthetic x0(LB5/b$a;Ljava/lang/Boolean;)Ljava/lang/Boolean;
    .locals 0

    iput-object p1, p0, LB5/b$a;->y:Ljava/lang/Boolean;

    return-object p1
.end method

.method static synthetic y0(LB5/b$a;)I
    .locals 0

    iget p0, p0, LB5/b$a;->q:I

    return p0
.end method

.method static synthetic z(LB5/b$a;Ljava/lang/Integer;)Ljava/lang/Integer;
    .locals 0

    iput-object p1, p0, LB5/b$a;->k:Ljava/lang/Integer;

    return-object p1
.end method

.method static synthetic z0(LB5/b$a;I)I
    .locals 0

    iput p1, p0, LB5/b$a;->q:I

    return p1
.end method


# virtual methods
.method public describeContents()I
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 1

    iget p2, p0, LB5/b$a;->f:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, LB5/b$a;->g:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->h:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->i:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->j:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->k:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->l:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->m:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget p2, p0, LB5/b$a;->n:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, LB5/b$a;->o:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget p2, p0, LB5/b$a;->p:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, LB5/b$a;->q:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, LB5/b$a;->r:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, LB5/b$a;->t:Ljava/lang/CharSequence;

    const/4 v0, 0x0

    if-eqz p2, :cond_0

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    goto :goto_0

    :cond_0
    move-object p2, v0

    :goto_0
    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-object p2, p0, LB5/b$a;->u:Ljava/lang/CharSequence;

    if-eqz p2, :cond_1

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget p2, p0, LB5/b$a;->v:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, LB5/b$a;->x:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->z:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->A:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->B:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->C:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->D:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->E:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->H:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->F:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->G:Ljava/lang/Integer;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->y:Ljava/lang/Boolean;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p2, p0, LB5/b$a;->s:Ljava/util/Locale;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    iget-object p0, p0, LB5/b$a;->I:Ljava/lang/Boolean;

    invoke-virtual {p1, p0}, Landroid/os/Parcel;->writeSerializable(Ljava/io/Serializable;)V

    return-void
.end method
