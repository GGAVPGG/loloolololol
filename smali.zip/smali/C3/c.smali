.class public interface abstract LC3/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract c()V
.end method

.method public abstract d(Ljava/lang/String;)V
.end method

.method public abstract e(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;)V
.end method
