.class public interface abstract LC3/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e(Ljava/lang/String;LC3/e$a;)V
.end method

.method public abstract h()V
.end method
