.class public interface abstract LC3/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Z)V
.end method
