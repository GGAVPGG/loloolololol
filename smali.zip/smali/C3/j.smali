.class public interface abstract LC3/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b()Z
.end method

.method public abstract getColumn()I
.end method

.method public abstract getFile()Ljava/lang/String;
.end method

.method public abstract getFileName()Ljava/lang/String;
.end method

.method public abstract getMethod()Ljava/lang/String;
.end method
