.class public final enum LC3/f;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum g:LC3/f;

.field public static final enum h:LC3/f;

.field private static final synthetic i:[LC3/f;

.field private static final synthetic j:Lkotlin/enums/EnumEntries;


# instance fields
.field private final f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    new-instance v0, LC3/f;

    const-string v1, "JS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v1}, LC3/f;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, LC3/f;->g:LC3/f;

    new-instance v0, LC3/f;

    const/4 v1, 0x1

    const-string v2, "Native"

    const-string v3, "NATIVE"

    invoke-direct {v0, v3, v1, v2}, LC3/f;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, LC3/f;->h:LC3/f;

    invoke-static {}, LC3/f;->c()[LC3/f;

    move-result-object v0

    sput-object v0, LC3/f;->i:[LC3/f;

    invoke-static {v0}, LG9/a;->a([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, LC3/f;->j:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, LC3/f;->f:Ljava/lang/String;

    return-void
.end method

.method private static final synthetic c()[LC3/f;
    .locals 2

    sget-object v0, LC3/f;->g:LC3/f;

    sget-object v1, LC3/f;->h:LC3/f;

    filled-new-array {v0, v1}, [LC3/f;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LC3/f;
    .locals 1

    const-class v0, LC3/f;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LC3/f;

    return-object p0
.end method

.method public static values()[LC3/f;
    .locals 1

    sget-object v0, LC3/f;->i:[LC3/f;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LC3/f;

    return-object v0
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LC3/f;->f:Ljava/lang/String;

    return-object p0
.end method
