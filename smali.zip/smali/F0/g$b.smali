.class LF0/g$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI0/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF0/g;->d(Landroid/content/Context;Ljava/util/List;ILjava/util/concurrent/Executor;LF0/a;)Landroid/graphics/Typeface;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LF0/a;


# direct methods
.method constructor <init>(LF0/a;)V
    .locals 0

    iput-object p1, p0, LF0/g$b;->a:LF0/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LF0/g$e;)V
    .locals 1

    if-nez p1, :cond_0

    new-instance p1, LF0/g$e;

    const/4 v0, -0x3

    invoke-direct {p1, v0}, LF0/g$e;-><init>(I)V

    :cond_0
    iget-object p0, p0, LF0/g$b;->a:LF0/a;

    invoke-virtual {p0, p1}, LF0/a;->b(LF0/g$e;)V

    return-void
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, LF0/g$e;

    invoke-virtual {p0, p1}, LF0/g$b;->a(LF0/g$e;)V

    return-void
.end method
