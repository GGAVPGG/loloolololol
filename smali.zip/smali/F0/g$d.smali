.class LF0/g$d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI0/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF0/g;->d(Landroid/content/Context;Ljava/util/List;ILjava/util/concurrent/Executor;LF0/a;)Landroid/graphics/Typeface;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, LF0/g$d;->a:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LF0/g$e;)V
    .locals 3

    sget-object v0, LF0/g;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-object v1, LF0/g;->d:Ln0/i;

    iget-object v2, p0, LF0/g$d;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ln0/i;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/ArrayList;

    if-nez v2, :cond_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    iget-object p0, p0, LF0/g$d;->a:Ljava/lang/String;

    invoke-virtual {v1, p0}, Ln0/i;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 p0, 0x0

    :goto_0
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p0, v0, :cond_1

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LI0/a;

    invoke-interface {v0, p1}, LI0/a;->accept(Ljava/lang/Object;)V

    add-int/lit8 p0, p0, 0x1

    goto :goto_0

    :cond_1
    return-void

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, LF0/g$e;

    invoke-virtual {p0, p1}, LF0/g$d;->a(LF0/g$e;)V

    return-void
.end method
