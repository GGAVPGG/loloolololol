.class LF0/a$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF0/a;->a(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic f:LF0/h$c;

.field final synthetic g:I

.field final synthetic h:LF0/a;


# direct methods
.method constructor <init>(LF0/a;LF0/h$c;I)V
    .locals 0

    iput-object p1, p0, LF0/a$b;->h:LF0/a;

    iput-object p2, p0, LF0/a$b;->f:LF0/h$c;

    iput p3, p0, LF0/a$b;->g:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, LF0/a$b;->f:LF0/h$c;

    iget p0, p0, LF0/a$b;->g:I

    invoke-virtual {v0, p0}, LF0/h$c;->a(I)V

    return-void
.end method
