.class LF0/i$c$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF0/i$c;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic f:LI0/a;

.field final synthetic g:Ljava/lang/Object;

.field final synthetic h:LF0/i$c;


# direct methods
.method constructor <init>(LF0/i$c;LI0/a;Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, LF0/i$c$a;->h:LF0/i$c;

    iput-object p2, p0, LF0/i$c$a;->f:LI0/a;

    iput-object p3, p0, LF0/i$c$a;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, LF0/i$c$a;->f:LI0/a;

    iget-object p0, p0, LF0/i$c$a;->g:Ljava/lang/Object;

    invoke-interface {v0, p0}, LI0/a;->accept(Ljava/lang/Object;)V

    return-void
.end method
