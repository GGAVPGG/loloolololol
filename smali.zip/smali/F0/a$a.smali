.class LF0/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF0/a;->c(Landroid/graphics/Typeface;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic f:LF0/h$c;

.field final synthetic g:Landroid/graphics/Typeface;

.field final synthetic h:LF0/a;


# direct methods
.method constructor <init>(LF0/a;LF0/h$c;Landroid/graphics/Typeface;)V
    .locals 0

    iput-object p1, p0, LF0/a$a;->h:LF0/a;

    iput-object p2, p0, LF0/a$a;->f:LF0/h$c;

    iput-object p3, p0, LF0/a$a;->g:Landroid/graphics/Typeface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    iget-object v0, p0, LF0/a$a;->f:LF0/h$c;

    iget-object p0, p0, LF0/a$a;->g:Landroid/graphics/Typeface;

    invoke-virtual {v0, p0}, LF0/h$c;->b(Landroid/graphics/Typeface;)V

    return-void
.end method
