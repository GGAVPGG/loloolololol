.class public interface abstract LB1/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/lang/Object;LH1/n;)Ljava/lang/Object;
.end method
