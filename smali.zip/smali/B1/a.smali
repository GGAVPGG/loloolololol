.class public final LB1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB1/c;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;LH1/n;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Landroid/net/Uri;

    invoke-virtual {p0, p1, p2}, LB1/a;->b(Landroid/net/Uri;LH1/n;)Lv1/C;

    move-result-object p0

    return-object p0
.end method

.method public b(Landroid/net/Uri;LH1/n;)Lv1/C;
    .locals 0

    invoke-static {p1}, Lv1/E;->b(Landroid/net/Uri;)Lv1/C;

    move-result-object p0

    return-object p0
.end method
