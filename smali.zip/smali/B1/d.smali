.class public final LB1/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB1/c;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;LH1/n;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LNb/F;

    invoke-virtual {p0, p1, p2}, LB1/d;->b(LNb/F;LH1/n;)Lv1/C;

    move-result-object p0

    return-object p0
.end method

.method public b(LNb/F;LH1/n;)Lv1/C;
    .locals 8

    invoke-virtual {p1}, LNb/F;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v6, 0x3a

    const/4 v7, 0x0

    const-string v0, "file"

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v7}, Lv1/D;->b(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lv1/C;

    move-result-object p0

    return-object p0
.end method
