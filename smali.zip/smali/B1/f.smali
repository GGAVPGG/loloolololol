.class public final LB1/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB1/c;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;LH1/n;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1, p2}, LB1/f;->b(Ljava/lang/String;LH1/n;)Lv1/C;

    move-result-object p0

    return-object p0
.end method

.method public b(Ljava/lang/String;LH1/n;)Lv1/C;
    .locals 0

    const/4 p0, 0x0

    const/4 p2, 0x1

    invoke-static {p1, p0, p2, p0}, Lv1/D;->j(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Lv1/C;

    move-result-object p0

    return-object p0
.end method
