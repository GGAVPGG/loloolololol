.class abstract LF/u$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "c"
.end annotation


# instance fields
.field private a:LG/r;

.field private b:LG/r;

.field private c:LG/q0;

.field private d:LG/q0;

.field private e:LG/q0;


# direct methods
.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LF/u$c$a;

    invoke-direct {v0, p0}, LF/u$c$a;-><init>(LF/u$c;)V

    iput-object v0, p0, LF/u$c;->a:LG/r;

    const/4 v0, 0x0

    iput-object v0, p0, LF/u$c;->e:LG/q0;

    return-void
.end method

.method static n(Landroid/util/Size;ILjava/util/List;ZLz/d0;LF/G;)LF/u$c;
    .locals 9

    new-instance v0, LF/b;

    new-instance v7, LQ/u;

    invoke-direct {v7}, LQ/u;-><init>()V

    new-instance v8, LQ/u;

    invoke-direct {v8}, LQ/u;-><init>()V

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p4

    move-object v6, p5

    invoke-direct/range {v0 .. v8}, LF/b;-><init>(Landroid/util/Size;ILjava/util/List;ZLz/d0;LF/G;LQ/u;LQ/u;)V

    return-object v0
.end method


# virtual methods
.method a()LG/r;
    .locals 0

    iget-object p0, p0, LF/u$c;->a:LG/r;

    return-object p0
.end method

.method abstract b()LQ/u;
.end method

.method abstract c()Lz/d0;
.end method

.method abstract d()I
.end method

.method abstract e()Ljava/util/List;
.end method

.method abstract f()LF/G;
.end method

.method g()LG/q0;
    .locals 0

    iget-object p0, p0, LF/u$c;->e:LG/q0;

    return-object p0
.end method

.method abstract h()LQ/u;
.end method

.method i()LG/r;
    .locals 0

    iget-object p0, p0, LF/u$c;->b:LG/r;

    return-object p0
.end method

.method j()LG/q0;
    .locals 0

    iget-object p0, p0, LF/u$c;->d:LG/q0;

    return-object p0
.end method

.method abstract k()Landroid/util/Size;
.end method

.method l()LG/q0;
    .locals 0

    iget-object p0, p0, LF/u$c;->c:LG/q0;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p0
.end method

.method abstract m()Z
.end method

.method o(LG/r;)V
    .locals 0

    iput-object p1, p0, LF/u$c;->a:LG/r;

    return-void
.end method

.method p(Landroid/view/Surface;Landroid/util/Size;I)V
    .locals 1

    new-instance v0, LG/G0;

    invoke-direct {v0, p1, p2, p3}, LG/G0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object v0, p0, LF/u$c;->e:LG/q0;

    return-void
.end method

.method q(LG/r;)V
    .locals 0

    iput-object p1, p0, LF/u$c;->b:LG/r;

    return-void
.end method

.method r(Landroid/view/Surface;)V
    .locals 3

    iget-object v0, p0, LF/u$c;->d:LG/q0;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "The secondary surface is already set."

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    new-instance v0, LG/G0;

    invoke-virtual {p0}, LF/u$c;->k()Landroid/util/Size;

    move-result-object v1

    invoke-virtual {p0}, LF/u$c;->d()I

    move-result v2

    invoke-direct {v0, p1, v1, v2}, LG/G0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object v0, p0, LF/u$c;->d:LG/q0;

    return-void
.end method

.method s(Landroid/view/Surface;)V
    .locals 3

    iget-object v0, p0, LF/u$c;->c:LG/q0;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "The surface is already set."

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    new-instance v0, LG/G0;

    invoke-virtual {p0}, LF/u$c;->k()Landroid/util/Size;

    move-result-object v1

    invoke-virtual {p0}, LF/u$c;->d()I

    move-result v2

    invoke-direct {v0, p1, v1, v2}, LG/G0;-><init>(Landroid/view/Surface;Landroid/util/Size;I)V

    iput-object v0, p0, LF/u$c;->c:LG/q0;

    return-void
.end method
