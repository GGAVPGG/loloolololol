.class public final synthetic LF/t;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/u$a;


# direct methods
.method public synthetic constructor <init>(LF/u$a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/t;->f:LF/u$a;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    iget-object p0, p0, LF/t;->f:LF/u$a;

    invoke-static {p0}, LF/u$a;->e(LF/u$a;)V

    return-void
.end method
