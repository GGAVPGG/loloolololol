.class public final synthetic LF/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:Landroidx/camera/core/r;


# direct methods
.method public synthetic constructor <init>(Landroidx/camera/core/r;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/q;->f:Landroidx/camera/core/r;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    iget-object p0, p0, LF/q;->f:Landroidx/camera/core/r;

    invoke-static {p0}, LF/u;->f(Landroidx/camera/core/r;)V

    return-void
.end method
