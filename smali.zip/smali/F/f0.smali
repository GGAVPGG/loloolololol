.class public final synthetic LF/f0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/i0;

.field public final synthetic g:Landroidx/camera/core/o;


# direct methods
.method public synthetic constructor <init>(LF/i0;Landroidx/camera/core/o;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/f0;->f:LF/i0;

    iput-object p2, p0, LF/f0;->g:Landroidx/camera/core/o;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/f0;->f:LF/i0;

    iget-object p0, p0, LF/f0;->g:Landroidx/camera/core/o;

    invoke-static {v0, p0}, LF/i0;->c(LF/i0;Landroidx/camera/core/o;)V

    return-void
.end method
