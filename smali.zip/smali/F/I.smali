.class public final synthetic LF/I;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI0/a;


# instance fields
.field public final synthetic a:LF/Q;


# direct methods
.method public synthetic constructor <init>(LF/Q;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/I;->a:LF/Q;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    iget-object p0, p0, LF/I;->a:LF/Q;

    check-cast p1, LF/Q$b;

    invoke-static {p0, p1}, LF/Q;->b(LF/Q;LF/Q$b;)V

    return-void
.end method
