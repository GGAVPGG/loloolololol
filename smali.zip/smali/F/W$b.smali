.class LF/W$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz/Y;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF/W;->l(JILandroid/graphics/Matrix;)Lz/Y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:I

.field final synthetic c:Landroid/graphics/Matrix;


# direct methods
.method constructor <init>(JILandroid/graphics/Matrix;)V
    .locals 0

    iput-wide p1, p0, LF/W$b;->a:J

    iput p3, p0, LF/W$b;->b:I

    iput-object p4, p0, LF/W$b;->c:Landroid/graphics/Matrix;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()J
    .locals 2

    iget-wide v0, p0, LF/W$b;->a:J

    return-wide v0
.end method

.method public b()LG/r1;
    .locals 1

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Custom ImageProxy does not contain TagBundle"

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public d(LI/i$b;)V
    .locals 0

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "Custom ImageProxy does not contain Exif data."

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public e()I
    .locals 0

    iget p0, p0, LF/W$b;->b:I

    return p0
.end method
