.class final LF/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private b([BLandroid/graphics/Rect;)Landroid/graphics/Bitmap;
    .locals 1

    :try_start_0
    array-length p0, p1

    const/4 v0, 0x0

    invoke-static {p1, v0, p0, v0}, Landroid/graphics/BitmapRegionDecoder;->newInstance([BIIZ)Landroid/graphics/BitmapRegionDecoder;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    new-instance p1, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {p1}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    invoke-virtual {p0, p2, p1}, Landroid/graphics/BitmapRegionDecoder;->decodeRegion(Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0

    :catch_0
    move-exception p0

    new-instance p1, Lz/X;

    const/4 p2, 0x1

    const-string v0, "Failed to decode JPEG."

    invoke-direct {p1, p2, v0, p0}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method


# virtual methods
.method public a(LQ/z;)LQ/z;
    .locals 8

    invoke-virtual {p1}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    invoke-direct {p0, v1, v0}, LF/A;->b([BLandroid/graphics/Rect;)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {p1}, LQ/z;->d()LI/g;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result p0

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    const/4 v5, 0x0

    invoke-direct {v4, v5, v5, p0, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v5

    invoke-virtual {p1}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object p0

    invoke-static {p0, v0}, LI/z;->u(Landroid/graphics/Matrix;Landroid/graphics/Rect;)Landroid/graphics/Matrix;

    move-result-object v6

    invoke-virtual {p1}, LQ/z;->a()LG/B;

    move-result-object v7

    invoke-static/range {v2 .. v7}, LQ/z;->i(Landroid/graphics/Bitmap;LI/g;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LQ/z;

    invoke-virtual {p0, p1}, LF/A;->a(LQ/z;)LQ/z;

    move-result-object p0

    return-object p0
.end method
