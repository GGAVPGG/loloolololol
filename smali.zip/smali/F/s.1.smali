.class public final synthetic LF/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/F0$a;


# instance fields
.field public final synthetic a:LF/u;


# direct methods
.method public synthetic constructor <init>(LF/u;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/s;->a:LF/u;

    return-void
.end method


# virtual methods
.method public final a(LG/F0;)V
    .locals 0

    iget-object p0, p0, LF/s;->a:LF/u;

    invoke-static {p0, p1}, LF/u;->a(LF/u;LG/F0;)V

    return-void
.end method
