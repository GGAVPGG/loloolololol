.class final LF/f;
.super LF/Y$a;
.source "SourceFile"


# instance fields
.field private final a:I

.field private final b:Lz/X;


# direct methods
.method constructor <init>(ILz/X;)V
    .locals 0

    invoke-direct {p0}, LF/Y$a;-><init>()V

    iput p1, p0, LF/f;->a:I

    if-eqz p2, :cond_0

    iput-object p2, p0, LF/f;->b:Lz/X;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null imageCaptureException"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method a()Lz/X;
    .locals 0

    iget-object p0, p0, LF/f;->b:Lz/X;

    return-object p0
.end method

.method b()I
    .locals 0

    iget p0, p0, LF/f;->a:I

    return p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LF/Y$a;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    check-cast p1, LF/Y$a;

    iget v1, p0, LF/f;->a:I

    invoke-virtual {p1}, LF/Y$a;->b()I

    move-result v3

    if-ne v1, v3, :cond_1

    iget-object p0, p0, LF/f;->b:Lz/X;

    invoke-virtual {p1}, LF/Y$a;->a()Lz/X;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    return v0

    :cond_1
    return v2
.end method

.method public hashCode()I
    .locals 2

    iget v0, p0, LF/f;->a:I

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget-object p0, p0, LF/f;->b:Lz/X;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "CaptureError{requestId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LF/f;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", imageCaptureException="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, LF/f;->b:Lz/X;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
