.class interface abstract LF/X;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b()V
.end method

.method public abstract c(Lz/X;)V
.end method

.method public abstract d(Landroid/graphics/Bitmap;)V
.end method

.method public abstract e(Lz/X;)V
.end method

.method public abstract f(Lz/V$h;)V
.end method

.method public abstract g()V
.end method

.method public abstract h(Landroidx/camera/core/o;)V
.end method

.method public abstract onCaptureProcessProgressed(I)V
.end method
