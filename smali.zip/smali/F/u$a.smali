.class LF/u$a;
.super LG/r;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF/u;->s(LF/u$c;)LF/Q$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LF/u;


# direct methods
.method constructor <init>(LF/u;)V
    .locals 0

    iput-object p1, p0, LF/u$a;->a:LF/u;

    invoke-direct {p0}, LG/r;-><init>()V

    return-void
.end method

.method public static synthetic e(LF/u$a;)V
    .locals 0

    iget-object p0, p0, LF/u$a;->a:LF/u;

    iget-object p0, p0, LF/u;->a:LF/S;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, LF/S;->p()V

    :cond_0
    return-void
.end method


# virtual methods
.method public d(I)V
    .locals 1

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p1

    new-instance v0, LF/t;

    invoke-direct {v0, p0}, LF/t;-><init>(LF/u$a;)V

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
