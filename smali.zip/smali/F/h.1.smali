.class public LF/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/h$b;,
        LF/h$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static b(Landroid/graphics/Bitmap;)I
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_0

    invoke-static {p0}, LF/h$a;->a(Landroid/graphics/Bitmap;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/16 p0, 0x1005

    return p0

    :cond_0
    const/16 p0, 0x100

    return p0
.end method


# virtual methods
.method public a(LF/h$b;)LQ/z;
    .locals 11

    invoke-virtual {p1}, LF/h$b;->b()LQ/z;

    move-result-object p0

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-virtual {p0}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Bitmap;

    sget-object v2, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    invoke-virtual {p1}, LF/h$b;->a()I

    move-result p1

    invoke-virtual {v1, v2, p1, v0}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v3

    invoke-virtual {p0}, LQ/z;->d()LI/g;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, LQ/z;->c()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    invoke-static {p1}, LF/h;->b(Landroid/graphics/Bitmap;)I

    move-result v5

    invoke-virtual {p0}, LQ/z;->h()Landroid/util/Size;

    move-result-object v6

    invoke-virtual {p0}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object v7

    invoke-virtual {p0}, LQ/z;->f()I

    move-result v8

    invoke-virtual {p0}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object v9

    invoke-virtual {p0}, LQ/z;->a()LG/B;

    move-result-object v10

    invoke-static/range {v3 .. v10}, LQ/z;->l([BLI/g;ILandroid/util/Size;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LF/h$b;

    invoke-virtual {p0, p1}, LF/h;->a(LF/h$b;)LQ/z;

    move-result-object p0

    return-object p0
.end method
