.class public final synthetic LF/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/S;

.field public final synthetic g:Lz/X;


# direct methods
.method public synthetic constructor <init>(LF/S;Lz/X;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/P;->f:LF/S;

    iput-object p2, p0, LF/P;->g:Lz/X;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/P;->f:LF/S;

    iget-object p0, p0, LF/P;->g:Lz/X;

    invoke-static {v0, p0}, LF/Q;->g(LF/S;Lz/X;)V

    return-void
.end method
