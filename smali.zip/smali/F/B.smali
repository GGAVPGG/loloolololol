.class public LF/B;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/B$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static b(Ljava/io/File;[B)V
    .locals 2

    :try_start_0
    new-instance v0, Ljava/io/FileOutputStream;

    invoke-direct {v0, p0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    new-instance p0, LO/c;

    invoke-direct {p0}, LO/c;-><init>()V

    invoke-virtual {p0, p1}, LO/c;->b([B)I

    move-result p0

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1, p0}, Ljava/io/FileOutputStream;->write([BII)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    return-void

    :catchall_0
    move-exception p0

    :try_start_3
    invoke-virtual {v0}, Ljava/io/FileOutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_0

    :catchall_1
    move-exception p1

    :try_start_4
    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw p0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    move-exception p0

    new-instance p1, Lz/X;

    const/4 v0, 0x1

    const-string v1, "Failed to write to temp file"

    invoke-direct {p1, v0, v1, p0}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method


# virtual methods
.method public a(LF/B$a;)Lz/V$h;
    .locals 2

    invoke-virtual {p1}, LF/B$a;->b()LQ/z;

    move-result-object p0

    invoke-virtual {p1}, LF/B$a;->a()Lz/V$g;

    const/4 p1, 0x0

    invoke-static {p1}, LF/v;->b(Lz/V$g;)Ljava/io/File;

    move-result-object v0

    invoke-virtual {p0}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    invoke-static {v0, v1}, LF/B;->b(Ljava/io/File;[B)V

    invoke-virtual {p0}, LQ/z;->d()LI/g;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, LQ/z;->f()I

    move-result p0

    invoke-static {v0, v1, p1, p0}, LF/v;->g(Ljava/io/File;LI/g;Lz/V$g;I)V

    invoke-static {v0, p1}, LF/v;->f(Ljava/io/File;Lz/V$g;)Landroid/net/Uri;

    move-result-object p0

    new-instance p1, Lz/V$h;

    const/16 v0, 0x100

    invoke-direct {p1, p0, v0}, Lz/V$h;-><init>(Landroid/net/Uri;I)V

    return-object p1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LF/B$a;

    invoke-virtual {p0, p1}, LF/B;->a(LF/B$a;)Lz/V$h;

    move-result-object p0

    return-object p0
.end method
