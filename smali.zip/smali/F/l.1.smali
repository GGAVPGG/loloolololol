.class public final synthetic LF/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LI0/a;


# instance fields
.field public final synthetic a:LF/u;


# direct methods
.method public synthetic constructor <init>(LF/u;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/l;->a:LF/u;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    iget-object p0, p0, LF/l;->a:LF/u;

    check-cast p1, LF/S;

    invoke-virtual {p0, p1}, LF/u;->l(LF/S;)V

    return-void
.end method
