.class public final synthetic LF/b0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/c0;

.field public final synthetic g:LF/V;


# direct methods
.method public synthetic constructor <init>(LF/c0;LF/V;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/b0;->f:LF/c0;

    iput-object p2, p0, LF/b0;->g:LF/V;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/b0;->f:LF/c0;

    iget-object p0, p0, LF/b0;->g:LF/V;

    invoke-static {v0, p0}, LF/c0;->b(LF/c0;LF/V;)V

    return-void
.end method
