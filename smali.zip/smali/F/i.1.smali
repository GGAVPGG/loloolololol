.class public LF/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# instance fields
.field private final a:LQ/w;


# direct methods
.method constructor <init>(LQ/w;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/i;->a:LQ/w;

    return-void
.end method


# virtual methods
.method public a(LQ/z;)LQ/z;
    .locals 2

    iget-object p0, p0, LF/i;->a:LQ/w;

    new-instance v0, LQ/v;

    new-instance v1, LF/W;

    invoke-direct {v1, p1}, LF/W;-><init>(LQ/z;)V

    const/4 p1, 0x1

    invoke-direct {v0, v1, p1}, LQ/v;-><init>(Landroidx/camera/core/o;I)V

    invoke-virtual {p0, v0}, LQ/w;->a(Lz/b0;)Lz/c0;

    const/4 p0, 0x0

    throw p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LQ/z;

    invoke-virtual {p0, p1}, LF/i;->a(LQ/z;)LQ/z;

    move-result-object p0

    return-object p0
.end method
