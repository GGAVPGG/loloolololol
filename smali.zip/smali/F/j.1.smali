.class public interface abstract LF/j;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()LW5/a;
.end method

.method public abstract b()LW5/a;
.end method
