.class public interface abstract LF/y;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Ljava/util/List;)LW5/a;
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method
