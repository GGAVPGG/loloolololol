.class public LF/V;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF/X;


# instance fields
.field private final a:LF/i0;

.field private final b:LF/i0$a;

.field private final c:LW5/a;

.field private final d:LW5/a;

.field private e:Landroidx/concurrent/futures/c$a;

.field private f:Landroidx/concurrent/futures/c$a;

.field private g:Z

.field private h:Z

.field private i:LW5/a;


# direct methods
.method constructor <init>(LF/i0;LF/i0$a;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, LF/V;->g:Z

    iput-boolean v0, p0, LF/V;->h:Z

    iput-object p1, p0, LF/V;->a:LF/i0;

    iput-object p2, p0, LF/V;->b:LF/i0$a;

    new-instance p1, LF/T;

    invoke-direct {p1, p0}, LF/T;-><init>(LF/V;)V

    invoke-static {p1}, Landroidx/concurrent/futures/c;->a(Landroidx/concurrent/futures/c$c;)LW5/a;

    move-result-object p1

    iput-object p1, p0, LF/V;->c:LW5/a;

    new-instance p1, LF/U;

    invoke-direct {p1, p0}, LF/U;-><init>(LF/V;)V

    invoke-static {p1}, Landroidx/concurrent/futures/c;->a(Landroidx/concurrent/futures/c$c;)LW5/a;

    move-result-object p1

    iput-object p1, p0, LF/V;->d:LW5/a;

    return-void
.end method

.method public static synthetic i(LF/V;Landroidx/concurrent/futures/c$a;)Ljava/lang/Object;
    .locals 0

    iput-object p1, p0, LF/V;->e:Landroidx/concurrent/futures/c$a;

    const-string p0, "CaptureCompleteFuture"

    return-object p0
.end method

.method public static synthetic j(LF/V;Landroidx/concurrent/futures/c$a;)Ljava/lang/Object;
    .locals 0

    iput-object p1, p0, LF/V;->f:Landroidx/concurrent/futures/c$a;

    const-string p0, "RequestCompleteFuture"

    return-object p0
.end method

.method private k(Lz/X;)V
    .locals 2

    invoke-static {}, LI/y;->b()V

    const/4 v0, 0x1

    iput-boolean v0, p0, LF/V;->g:Z

    iget-object v1, p0, LF/V;->i:LW5/a;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v1, LW5/a;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Future;->cancel(Z)Z

    iget-object v0, p0, LF/V;->e:Landroidx/concurrent/futures/c$a;

    invoke-virtual {v0, p1}, Landroidx/concurrent/futures/c$a;->f(Ljava/lang/Throwable;)Z

    iget-object p0, p0, LF/V;->f:Landroidx/concurrent/futures/c$a;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/concurrent/futures/c$a;->c(Ljava/lang/Object;)Z

    return-void
.end method

.method private n()V
    .locals 1

    iget-object p0, p0, LF/V;->c:LW5/a;

    invoke-interface {p0}, Ljava/util/concurrent/Future;->isDone()Z

    move-result p0

    const-string v0, "onImageCaptured() must be called before onFinalResult()"

    invoke-static {p0, v0}, LI0/g;->j(ZLjava/lang/String;)V

    return-void
.end method

.method private q()V
    .locals 2

    iget-object v0, p0, LF/V;->a:LF/i0;

    invoke-virtual {v0}, LF/i0;->t()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, LF/V;->a:LF/i0;

    invoke-virtual {v0}, LF/i0;->s()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, LF/V;->a:LF/i0;

    invoke-virtual {v0}, LF/i0;->t()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, LF/V;->d:LW5/a;

    invoke-interface {v0}, Ljava/util/concurrent/Future;->isDone()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    const-string v1, "The callback can only complete once."

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    :cond_1
    iget-object p0, p0, LF/V;->f:Landroidx/concurrent/futures/c$a;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/concurrent/futures/c$a;->c(Ljava/lang/Object;)Z

    return-void
.end method

.method private r(Lz/X;)V
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-virtual {p0, p1}, LF/i0;->x(Lz/X;)V

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 0

    iget-boolean p0, p0, LF/V;->g:Z

    return p0
.end method

.method public b()V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-boolean v0, p0, LF/V;->h:Z

    if-nez v0, :cond_1

    invoke-virtual {p0}, LF/V;->g()V

    :cond_1
    iget-object p0, p0, LF/V;->e:Landroidx/concurrent/futures/c$a;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/concurrent/futures/c$a;->c(Ljava/lang/Object;)Z

    return-void
.end method

.method public c(Lz/X;)V
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, LF/V;->a:LF/i0;

    invoke-virtual {v0}, LF/i0;->f()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-direct {p0, p1}, LF/V;->r(Lz/X;)V

    :cond_1
    invoke-direct {p0}, LF/V;->q()V

    iget-object v1, p0, LF/V;->e:Landroidx/concurrent/futures/c$a;

    invoke-virtual {v1, p1}, Landroidx/concurrent/futures/c$a;->f(Ljava/lang/Throwable;)Z

    if-eqz v0, :cond_2

    iget-object p1, p0, LF/V;->b:LF/i0$a;

    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-interface {p1, p0}, LF/i0$a;->a(LF/i0;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public d(Landroid/graphics/Bitmap;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-virtual {p0, p1}, LF/i0;->y(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method public e(Lz/X;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, LF/V;->n()V

    invoke-direct {p0}, LF/V;->q()V

    invoke-direct {p0, p1}, LF/V;->r(Lz/X;)V

    return-void
.end method

.method public f(Lz/V$h;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0}, LF/V;->n()V

    invoke-direct {p0}, LF/V;->q()V

    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-virtual {p0, p1}, LF/i0;->A(Lz/V$h;)V

    return-void
.end method

.method public g()V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, LF/V;->h:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, LF/V;->h:Z

    iget-object v0, p0, LF/V;->a:LF/i0;

    invoke-virtual {v0}, LF/i0;->j()Lz/V$e;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lz/V$e;->b()V

    :cond_1
    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-virtual {p0}, LF/i0;->l()Lz/V$f;

    :cond_2
    :goto_0
    return-void
.end method

.method public h(Landroidx/camera/core/o;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    return-void

    :cond_0
    invoke-direct {p0}, LF/V;->n()V

    invoke-direct {p0}, LF/V;->q()V

    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-virtual {p0, p1}, LF/i0;->z(Landroidx/camera/core/o;)V

    return-void
.end method

.method l(Lz/X;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/V;->d:LW5/a;

    invoke-interface {v0}, Ljava/util/concurrent/Future;->isDone()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-direct {p0, p1}, LF/V;->k(Lz/X;)V

    invoke-direct {p0, p1}, LF/V;->r(Lz/X;)V

    return-void
.end method

.method m()V
    .locals 4

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/V;->d:LW5/a;

    invoke-interface {v0}, Ljava/util/concurrent/Future;->isDone()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Lz/X;

    const-string v1, "The request is aborted silently and retried."

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v3, v1, v2}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-direct {p0, v0}, LF/V;->k(Lz/X;)V

    iget-object v0, p0, LF/V;->b:LF/i0$a;

    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-interface {v0, p0}, LF/i0$a;->a(LF/i0;)V

    return-void
.end method

.method o()LW5/a;
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/V;->c:LW5/a;

    return-object p0
.end method

.method public onCaptureProcessProgressed(I)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-boolean v0, p0, LF/V;->g:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, LF/V;->a:LF/i0;

    invoke-virtual {p0, p1}, LF/i0;->w(I)V

    return-void
.end method

.method p()LW5/a;
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/V;->d:LW5/a;

    return-object p0
.end method

.method public s(LW5/a;)V
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/V;->i:LW5/a;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "CaptureRequestFuture can only be set once."

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    iput-object p1, p0, LF/V;->i:LW5/a;

    return-void
.end method
