.class LF/c0$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LK/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF/c0;->l(LF/k;)LW5/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LF/k;

.field final synthetic b:LF/c0;


# direct methods
.method constructor <init>(LF/c0;LF/k;)V
    .locals 0

    iput-object p1, p0, LF/c0$a;->b:LF/c0;

    iput-object p2, p0, LF/c0$a;->a:LF/k;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Throwable;)V
    .locals 5

    iget-object v0, p0, LF/c0$a;->a:LF/k;

    invoke-virtual {v0}, LF/k;->b()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, LF/c0$a;->a:LF/k;

    invoke-virtual {v0}, LF/k;->a()Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LG/h0;

    invoke-virtual {v0}, LG/h0;->f()I

    move-result v0

    instance-of v1, p1, Lz/X;

    if-eqz v1, :cond_1

    iget-object v1, p0, LF/c0$a;->b:LF/c0;

    iget-object v1, v1, LF/c0;->c:LF/z;

    check-cast p1, Lz/X;

    invoke-static {v0, p1}, LF/Y$a;->c(ILz/X;)LF/Y$a;

    move-result-object p1

    invoke-virtual {v1, p1}, LF/z;->j(LF/Y$a;)V

    goto :goto_0

    :cond_1
    iget-object v1, p0, LF/c0$a;->b:LF/c0;

    iget-object v1, v1, LF/c0;->c:LF/z;

    new-instance v2, Lz/X;

    const/4 v3, 0x2

    const-string v4, "Failed to submit capture request"

    invoke-direct {v2, v3, v4, p1}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {v0, v2}, LF/Y$a;->c(ILz/X;)LF/Y$a;

    move-result-object p1

    invoke-virtual {v1, p1}, LF/z;->j(LF/Y$a;)V

    :goto_0
    iget-object p0, p0, LF/c0$a;->b:LF/c0;

    iget-object p0, p0, LF/c0;->b:LF/y;

    invoke-interface {p0}, LF/y;->c()V

    return-void
.end method

.method public bridge synthetic b(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, LF/c0$a;->c(Ljava/lang/Void;)V

    return-void
.end method

.method public c(Ljava/lang/Void;)V
    .locals 0

    iget-object p0, p0, LF/c0$a;->b:LF/c0;

    iget-object p0, p0, LF/c0;->b:LF/y;

    invoke-interface {p0}, LF/y;->c()V

    return-void
.end method
