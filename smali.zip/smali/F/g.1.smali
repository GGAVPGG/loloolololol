.class final LF/g;
.super LF/i0;
.source "SourceFile"


# instance fields
.field private final c:Ljava/util/concurrent/Executor;

.field private final d:Lz/V$e;

.field private final e:Landroid/graphics/Rect;

.field private final f:Landroid/graphics/Matrix;

.field private final g:I

.field private final h:I

.field private final i:I

.field private final j:Z

.field private final k:Ljava/util/List;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;Lz/V$e;Lz/V$f;Lz/V$g;Lz/V$g;Landroid/graphics/Rect;Landroid/graphics/Matrix;IIIZLjava/util/List;)V
    .locals 0

    invoke-direct {p0}, LF/i0;-><init>()V

    if-eqz p1, :cond_3

    iput-object p1, p0, LF/g;->c:Ljava/util/concurrent/Executor;

    iput-object p2, p0, LF/g;->d:Lz/V$e;

    if-eqz p6, :cond_2

    iput-object p6, p0, LF/g;->e:Landroid/graphics/Rect;

    if-eqz p7, :cond_1

    iput-object p7, p0, LF/g;->f:Landroid/graphics/Matrix;

    iput p8, p0, LF/g;->g:I

    iput p9, p0, LF/g;->h:I

    iput p10, p0, LF/g;->i:I

    iput-boolean p11, p0, LF/g;->j:Z

    if-eqz p12, :cond_0

    iput-object p12, p0, LF/g;->k:Ljava/util/List;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null sessionConfigCameraCaptureCallbacks"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null sensorToBufferTransform"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null cropRect"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null appExecutor"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LF/i0;

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    check-cast p1, LF/i0;

    iget-object v1, p0, LF/g;->c:Ljava/util/concurrent/Executor;

    invoke-virtual {p1}, LF/i0;->g()Ljava/util/concurrent/Executor;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, LF/g;->d:Lz/V$e;

    if-nez v1, :cond_1

    invoke-virtual {p1}, LF/i0;->j()Lz/V$e;

    move-result-object v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, LF/i0;->j()Lz/V$e;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    :goto_0
    invoke-virtual {p1}, LF/i0;->l()Lz/V$f;

    invoke-virtual {p1}, LF/i0;->m()Lz/V$g;

    invoke-virtual {p1}, LF/i0;->o()Lz/V$g;

    iget-object v1, p0, LF/g;->e:Landroid/graphics/Rect;

    invoke-virtual {p1}, LF/i0;->i()Landroid/graphics/Rect;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/graphics/Rect;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, LF/g;->f:Landroid/graphics/Matrix;

    invoke-virtual {p1}, LF/i0;->p()Landroid/graphics/Matrix;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/graphics/Matrix;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    iget v1, p0, LF/g;->g:I

    invoke-virtual {p1}, LF/i0;->n()I

    move-result v3

    if-ne v1, v3, :cond_2

    iget v1, p0, LF/g;->h:I

    invoke-virtual {p1}, LF/i0;->k()I

    move-result v3

    if-ne v1, v3, :cond_2

    iget v1, p0, LF/g;->i:I

    invoke-virtual {p1}, LF/i0;->h()I

    move-result v3

    if-ne v1, v3, :cond_2

    iget-boolean v1, p0, LF/g;->j:Z

    invoke-virtual {p1}, LF/i0;->t()Z

    move-result v3

    if-ne v1, v3, :cond_2

    iget-object p0, p0, LF/g;->k:Ljava/util/List;

    invoke-virtual {p1}, LF/i0;->q()Ljava/util/List;

    move-result-object p1

    invoke-interface {p0, p1}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    return v0

    :cond_2
    return v2
.end method

.method g()Ljava/util/concurrent/Executor;
    .locals 0

    iget-object p0, p0, LF/g;->c:Ljava/util/concurrent/Executor;

    return-object p0
.end method

.method h()I
    .locals 0

    iget p0, p0, LF/g;->i:I

    return p0
.end method

.method public hashCode()I
    .locals 3

    iget-object v0, p0, LF/g;->c:Ljava/util/concurrent/Executor;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget-object v2, p0, LF/g;->d:Lz/V$e;

    if-nez v2, :cond_0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_0
    xor-int/2addr v0, v2

    const v2, 0x5af15351

    mul-int/2addr v0, v2

    iget-object v2, p0, LF/g;->e:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->hashCode()I

    move-result v2

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, LF/g;->f:Landroid/graphics/Matrix;

    invoke-virtual {v2}, Landroid/graphics/Matrix;->hashCode()I

    move-result v2

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v2, p0, LF/g;->g:I

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v2, p0, LF/g;->h:I

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget v2, p0, LF/g;->i:I

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-boolean v2, p0, LF/g;->j:Z

    if-eqz v2, :cond_1

    const/16 v2, 0x4cf

    goto :goto_1

    :cond_1
    const/16 v2, 0x4d5

    :goto_1
    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object p0, p0, LF/g;->k:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->hashCode()I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public i()Landroid/graphics/Rect;
    .locals 0

    iget-object p0, p0, LF/g;->e:Landroid/graphics/Rect;

    return-object p0
.end method

.method public j()Lz/V$e;
    .locals 0

    iget-object p0, p0, LF/g;->d:Lz/V$e;

    return-object p0
.end method

.method public k()I
    .locals 0

    iget p0, p0, LF/g;->h:I

    return p0
.end method

.method public l()Lz/V$f;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public m()Lz/V$g;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public n()I
    .locals 0

    iget p0, p0, LF/g;->g:I

    return p0
.end method

.method public o()Lz/V$g;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method p()Landroid/graphics/Matrix;
    .locals 0

    iget-object p0, p0, LF/g;->f:Landroid/graphics/Matrix;

    return-object p0
.end method

.method q()Ljava/util/List;
    .locals 0

    iget-object p0, p0, LF/g;->k:Ljava/util/List;

    return-object p0
.end method

.method t()Z
    .locals 0

    iget-boolean p0, p0, LF/g;->j:Z

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "TakePictureRequest{appExecutor="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/g;->c:Ljava/util/concurrent/Executor;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", inMemoryCallback="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/g;->d:Lz/V$e;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", onDiskCallback="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", outputFileOptions="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, ", secondaryOutputFileOptions="

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", cropRect="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/g;->e:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", sensorToBufferTransform="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/g;->f:Landroid/graphics/Matrix;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", rotationDegrees="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LF/g;->g:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", jpegQuality="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LF/g;->h:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", captureMode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LF/g;->i:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", simultaneousCapture="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, LF/g;->j:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", sessionConfigCameraCaptureCallbacks="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, LF/g;->k:Ljava/util/List;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
