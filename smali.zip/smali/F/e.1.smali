.class final LF/e;
.super LF/Q$b;
.source "SourceFile"


# instance fields
.field private final a:LF/S;

.field private final b:Landroidx/camera/core/o;


# direct methods
.method constructor <init>(LF/S;Landroidx/camera/core/o;)V
    .locals 0

    invoke-direct {p0}, LF/Q$b;-><init>()V

    if-eqz p1, :cond_1

    iput-object p1, p0, LF/e;->a:LF/S;

    if-eqz p2, :cond_0

    iput-object p2, p0, LF/e;->b:Landroidx/camera/core/o;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null imageProxy"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null processingRequest"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method a()Landroidx/camera/core/o;
    .locals 0

    iget-object p0, p0, LF/e;->b:Landroidx/camera/core/o;

    return-object p0
.end method

.method b()LF/S;
    .locals 0

    iget-object p0, p0, LF/e;->a:LF/S;

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LF/Q$b;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    check-cast p1, LF/Q$b;

    iget-object v1, p0, LF/e;->a:LF/S;

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object p0, p0, LF/e;->b:Landroidx/camera/core/o;

    invoke-virtual {p1}, LF/Q$b;->a()Landroidx/camera/core/o;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    return v0

    :cond_1
    return v2
.end method

.method public hashCode()I
    .locals 2

    iget-object v0, p0, LF/e;->a:LF/S;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget-object p0, p0, LF/e;->b:Landroidx/camera/core/o;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "InputPacket{processingRequest="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/e;->a:LF/S;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", imageProxy="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, LF/e;->b:Landroidx/camera/core/o;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
