.class public LF/c0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF/Y;
.implements Landroidx/camera/core/e$a;
.implements LF/i0$a;


# instance fields
.field final a:Ljava/util/Deque;

.field final b:LF/y;

.field c:LF/z;

.field private d:LF/V;

.field private final e:Ljava/util/List;

.field f:Z


# direct methods
.method public constructor <init>(LF/y;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, LF/c0;->a:Ljava/util/Deque;

    const/4 v0, 0x0

    iput-boolean v0, p0, LF/c0;->f:Z

    invoke-static {}, LI/y;->b()V

    iput-object p1, p0, LF/c0;->b:LF/y;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LF/c0;->e:Ljava/util/List;

    return-void
.end method

.method public static synthetic b(LF/c0;LF/V;)V
    .locals 0

    iget-object p0, p0, LF/c0;->e:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public static synthetic d(LF/c0;)V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, LF/c0;->d:LF/V;

    invoke-virtual {p0}, LF/c0;->k()V

    return-void
.end method

.method private l(LF/k;)LW5/a;
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/c0;->b:LF/y;

    invoke-interface {v0}, LF/y;->b()V

    iget-object v0, p0, LF/c0;->b:LF/y;

    invoke-virtual {p1}, LF/k;->a()Ljava/util/List;

    move-result-object v1

    invoke-interface {v0, v1}, LF/y;->a(Ljava/util/List;)LW5/a;

    move-result-object v0

    new-instance v1, LF/c0$a;

    invoke-direct {v1, p0, p1}, LF/c0$a;-><init>(LF/c0;LF/k;)V

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p0

    invoke-static {v0, v1, p0}, LK/n;->j(LW5/a;LK/c;Ljava/util/concurrent/Executor;)V

    return-object v0
.end method

.method private m(LF/V;)V
    .locals 3

    invoke-virtual {p0}, LF/c0;->e()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-static {v0}, LI0/g;->i(Z)V

    iput-object p1, p0, LF/c0;->d:LF/V;

    invoke-virtual {p1}, LF/V;->o()LW5/a;

    move-result-object v0

    new-instance v1, LF/a0;

    invoke-direct {v1, p0}, LF/a0;-><init>(LF/c0;)V

    invoke-static {}, LJ/c;->b()Ljava/util/concurrent/Executor;

    move-result-object v2

    invoke-interface {v0, v1, v2}, LW5/a;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    iget-object v0, p0, LF/c0;->e:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1}, LF/V;->p()LW5/a;

    move-result-object v0

    new-instance v1, LF/b0;

    invoke-direct {v1, p0, p1}, LF/b0;-><init>(LF/c0;LF/V;)V

    invoke-static {}, LJ/c;->b()Ljava/util/concurrent/Executor;

    move-result-object p0

    invoke-interface {v0, v1, p0}, LW5/a;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    return-void
.end method


# virtual methods
.method public a(LF/i0;)V
    .locals 2

    invoke-static {}, LI/y;->b()V

    const-string v0, "TakePictureManagerImpl"

    const-string v1, "Add a new request for retrying."

    invoke-static {v0, v1}, Lz/h0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, LF/c0;->a:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->addFirst(Ljava/lang/Object;)V

    invoke-virtual {p0}, LF/c0;->k()V

    return-void
.end method

.method public c(Landroidx/camera/core/o;)V
    .locals 1

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p1

    new-instance v0, LF/Z;

    invoke-direct {v0, p0}, LF/Z;-><init>(LF/c0;)V

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public e()Z
    .locals 0

    iget-object p0, p0, LF/c0;->d:LF/V;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public f()V
    .locals 1

    invoke-static {}, LI/y;->b()V

    const/4 v0, 0x1

    iput-boolean v0, p0, LF/c0;->f:Z

    iget-object p0, p0, LF/c0;->d:LF/V;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, LF/V;->m()V

    :cond_0
    return-void
.end method

.method public g()V
    .locals 1

    invoke-static {}, LI/y;->b()V

    const/4 v0, 0x0

    iput-boolean v0, p0, LF/c0;->f:Z

    invoke-virtual {p0}, LF/c0;->k()V

    return-void
.end method

.method public h()V
    .locals 4

    invoke-static {}, LI/y;->b()V

    new-instance v0, Lz/X;

    const-string v1, "Camera is closed."

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v3, v1, v2}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    iget-object v1, p0, LF/c0;->a:Ljava/util/Deque;

    invoke-interface {v1}, Ljava/util/Deque;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LF/i0;

    invoke-virtual {v2, v0}, LF/i0;->x(Lz/X;)V

    goto :goto_0

    :cond_0
    iget-object v1, p0, LF/c0;->a:Ljava/util/Deque;

    invoke-interface {v1}, Ljava/util/Collection;->clear()V

    new-instance v1, Ljava/util/ArrayList;

    iget-object p0, p0, LF/c0;->e:Ljava/util/List;

    invoke-direct {v1, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LF/V;

    invoke-virtual {v1, v0}, LF/V;->l(Lz/X;)V

    goto :goto_1

    :cond_1
    return-void
.end method

.method public i(LF/i0;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/c0;->a:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->offer(Ljava/lang/Object;)Z

    invoke-virtual {p0}, LF/c0;->k()V

    return-void
.end method

.method public j(LF/z;)V
    .locals 0

    invoke-static {}, LI/y;->b()V

    iput-object p1, p0, LF/c0;->c:LF/z;

    invoke-virtual {p1, p0}, LF/z;->k(Landroidx/camera/core/e$a;)V

    return-void
.end method

.method k()V
    .locals 4

    invoke-static {}, LI/y;->b()V

    const-string v0, "Issue the next TakePictureRequest."

    const-string v1, "TakePictureManagerImpl"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {p0}, LF/c0;->e()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "There is already a request in-flight."

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-boolean v0, p0, LF/c0;->f:Z

    if-eqz v0, :cond_1

    const-string p0, "The class is paused."

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_1
    iget-object v0, p0, LF/c0;->c:LF/z;

    invoke-virtual {v0}, LF/z;->h()I

    move-result v0

    if-nez v0, :cond_2

    const-string p0, "Too many acquire images. Close image to be able to process next."

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_2
    iget-object v0, p0, LF/c0;->a:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LF/i0;

    if-nez v0, :cond_3

    const-string p0, "No new request."

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_3
    new-instance v1, LF/V;

    invoke-direct {v1, v0, p0}, LF/V;-><init>(LF/i0;LF/i0$a;)V

    invoke-direct {p0, v1}, LF/c0;->m(LF/V;)V

    iget-object v2, p0, LF/c0;->c:LF/z;

    invoke-virtual {v1}, LF/V;->o()LW5/a;

    move-result-object v3

    invoke-virtual {v2, v0, v1, v3}, LF/z;->e(LF/i0;LF/X;LW5/a;)LI0/d;

    move-result-object v0

    iget-object v2, v0, LI0/d;->a:Ljava/lang/Object;

    check-cast v2, LF/k;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v0, LI0/d;->b:Ljava/lang/Object;

    check-cast v0, LF/S;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, p0, LF/c0;->c:LF/z;

    invoke-virtual {v3, v0}, LF/z;->m(LF/S;)V

    invoke-direct {p0, v2}, LF/c0;->l(LF/k;)LW5/a;

    move-result-object p0

    invoke-virtual {v1, p0}, LF/V;->s(LW5/a;)V

    return-void
.end method
