.class public final synthetic LF/M;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/S;

.field public final synthetic g:Landroidx/camera/core/o;


# direct methods
.method public synthetic constructor <init>(LF/S;Landroidx/camera/core/o;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/M;->f:LF/S;

    iput-object p2, p0, LF/M;->g:Landroidx/camera/core/o;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/M;->f:LF/S;

    iget-object p0, p0, LF/M;->g:Landroidx/camera/core/o;

    invoke-static {v0, p0}, LF/Q;->c(LF/S;Landroidx/camera/core/o;)V

    return-void
.end method
