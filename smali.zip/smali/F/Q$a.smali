.class abstract LF/Q$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF/Q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "a"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static e(ILjava/util/List;)LF/Q$a;
    .locals 3

    new-instance v0, LF/d;

    new-instance v1, LQ/u;

    invoke-direct {v1}, LQ/u;-><init>()V

    new-instance v2, LQ/u;

    invoke-direct {v2}, LQ/u;-><init>()V

    invoke-direct {v0, v1, v2, p0, p1}, LF/d;-><init>(LQ/u;LQ/u;ILjava/util/List;)V

    return-object v0
.end method


# virtual methods
.method abstract a()LQ/u;
.end method

.method abstract b()I
.end method

.method abstract c()Ljava/util/List;
.end method

.method abstract d()LQ/u;
.end method
