.class public final synthetic LF/g0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/i0;

.field public final synthetic g:Landroid/graphics/Bitmap;


# direct methods
.method public synthetic constructor <init>(LF/i0;Landroid/graphics/Bitmap;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/g0;->f:LF/i0;

    iput-object p2, p0, LF/g0;->g:Landroid/graphics/Bitmap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/g0;->f:LF/i0;

    iget-object p0, p0, LF/g0;->g:Landroid/graphics/Bitmap;

    invoke-static {v0, p0}, LF/i0;->d(LF/i0;Landroid/graphics/Bitmap;)V

    return-void
.end method
