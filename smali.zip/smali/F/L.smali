.class public final synthetic LF/L;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/Q;

.field public final synthetic g:LF/Q$b;


# direct methods
.method public synthetic constructor <init>(LF/Q;LF/Q$b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/L;->f:LF/Q;

    iput-object p2, p0, LF/L;->g:LF/Q$b;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/L;->f:LF/Q;

    iget-object p0, p0, LF/L;->g:LF/Q$b;

    invoke-static {v0, p0}, LF/Q;->h(LF/Q;LF/Q$b;)V

    return-void
.end method
