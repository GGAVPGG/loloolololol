.class final LF/H;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static b(LF/S;LI/g;Landroidx/camera/core/o;)LQ/z;
    .locals 6

    invoke-virtual {p0}, LF/S;->b()Landroid/graphics/Rect;

    move-result-object v2

    invoke-virtual {p0}, LF/S;->f()I

    move-result v3

    invoke-virtual {p0}, LF/S;->h()Landroid/graphics/Matrix;

    move-result-object v4

    invoke-static {p2}, LF/H;->d(Landroidx/camera/core/o;)LG/B;

    move-result-object v5

    move-object v1, p1

    move-object v0, p2

    invoke-static/range {v0 .. v5}, LQ/z;->j(Landroidx/camera/core/o;LI/g;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method private static c(LF/S;LI/g;Landroidx/camera/core/o;)LQ/z;
    .locals 9

    new-instance v0, Landroid/util/Size;

    invoke-interface {p2}, Landroidx/camera/core/o;->b()I

    move-result v1

    invoke-interface {p2}, Landroidx/camera/core/o;->a()I

    move-result v2

    invoke-direct {v0, v1, v2}, Landroid/util/Size;-><init>(II)V

    invoke-virtual {p0}, LF/S;->f()I

    move-result v1

    invoke-virtual {p1}, LI/g;->n()I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v1, v0}, LF/H;->e(ILandroid/util/Size;)Landroid/util/Size;

    move-result-object v4

    new-instance v2, Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    int-to-float v0, v0

    const/4 v5, 0x0

    invoke-direct {v2, v5, v5, v3, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    new-instance v0, Landroid/graphics/RectF;

    invoke-virtual {v4}, Landroid/util/Size;->getWidth()I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v4}, Landroid/util/Size;->getHeight()I

    move-result v6

    int-to-float v6, v6

    invoke-direct {v0, v5, v5, v3, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-static {v2, v0, v1}, LI/z;->d(Landroid/graphics/RectF;Landroid/graphics/RectF;I)Landroid/graphics/Matrix;

    move-result-object v0

    invoke-virtual {p0}, LF/S;->b()Landroid/graphics/Rect;

    move-result-object v1

    invoke-static {v1, v0}, LF/H;->f(Landroid/graphics/Rect;Landroid/graphics/Matrix;)Landroid/graphics/Rect;

    move-result-object v5

    invoke-virtual {p1}, LI/g;->n()I

    move-result v6

    invoke-virtual {p0}, LF/S;->h()Landroid/graphics/Matrix;

    move-result-object p0

    invoke-static {p0, v0}, LF/H;->g(Landroid/graphics/Matrix;Landroid/graphics/Matrix;)Landroid/graphics/Matrix;

    move-result-object v7

    invoke-static {p2}, LF/H;->d(Landroidx/camera/core/o;)LG/B;

    move-result-object v8

    move-object v3, p1

    move-object v2, p2

    invoke-static/range {v2 .. v8}, LQ/z;->k(Landroidx/camera/core/o;LI/g;Landroid/util/Size;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method private static d(Landroidx/camera/core/o;)LG/B;
    .locals 1

    invoke-interface {p0}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object v0

    instance-of v0, v0, LL/c;

    if-eqz v0, :cond_0

    invoke-interface {p0}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object p0

    check-cast p0, LL/c;

    invoke-virtual {p0}, LL/c;->f()LG/B;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-static {}, LG/B$a;->l()LG/B;

    move-result-object p0

    return-object p0
.end method

.method private static e(ILandroid/util/Size;)Landroid/util/Size;
    .locals 1

    invoke-static {p0}, LI/z;->v(I)I

    move-result p0

    invoke-static {p0}, LI/z;->i(I)Z

    move-result p0

    if-eqz p0, :cond_0

    new-instance p0, Landroid/util/Size;

    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    move-result v0

    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    move-result p1

    invoke-direct {p0, v0, p1}, Landroid/util/Size;-><init>(II)V

    return-object p0

    :cond_0
    return-object p1
.end method

.method private static f(Landroid/graphics/Rect;Landroid/graphics/Matrix;)Landroid/graphics/Rect;
    .locals 1

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0, p0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    invoke-virtual {p1, v0}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    invoke-virtual {v0}, Landroid/graphics/RectF;->sort()V

    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v0, p0}, Landroid/graphics/RectF;->round(Landroid/graphics/Rect;)V

    return-object p0
.end method

.method private static g(Landroid/graphics/Matrix;Landroid/graphics/Matrix;)Landroid/graphics/Matrix;
    .locals 1

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0, p0}, Landroid/graphics/Matrix;-><init>(Landroid/graphics/Matrix;)V

    invoke-virtual {v0, p1}, Landroid/graphics/Matrix;->postConcat(Landroid/graphics/Matrix;)Z

    return-object v0
.end method


# virtual methods
.method public a(LF/Q$b;)LQ/z;
    .locals 3

    invoke-virtual {p1}, LF/Q$b;->a()Landroidx/camera/core/o;

    move-result-object p0

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object p1

    invoke-interface {p0}, Landroidx/camera/core/o;->getFormat()I

    move-result v0

    invoke-static {v0}, LP/b;->i(I)Z

    move-result v0

    if-eqz v0, :cond_0

    :try_start_0
    invoke-static {p0}, LI/g;->g(Landroidx/camera/core/o;)LI/g;

    move-result-object v0

    invoke-interface {p0}, Landroidx/camera/core/o;->G()[Landroidx/camera/core/o$a;

    move-result-object v1

    const/4 v2, 0x0

    aget-object v1, v1, v2

    invoke-interface {v1}, Landroidx/camera/core/o$a;->j()Ljava/nio/ByteBuffer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    new-instance p1, Lz/X;

    const/4 v0, 0x1

    const-string v1, "Failed to extract EXIF data."

    invoke-direct {p1, v0, v1, p0}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_0
    const/4 v0, 0x0

    :goto_0
    sget-object v1, LF/z;->g:LO/b;

    invoke-virtual {v1, p0}, LO/b;->b(Landroidx/camera/core/o;)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v1, "JPEG image must have exif."

    invoke-static {v0, v1}, LI0/g;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p1, v0, p0}, LF/H;->c(LF/S;LI/g;Landroidx/camera/core/o;)LQ/z;

    move-result-object p0

    return-object p0

    :cond_1
    invoke-static {p1, v0, p0}, LF/H;->b(LF/S;LI/g;Landroidx/camera/core/o;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LF/Q$b;

    invoke-virtual {p0, p1}, LF/H;->a(LF/Q$b;)LQ/z;

    move-result-object p0

    return-object p0
.end method
