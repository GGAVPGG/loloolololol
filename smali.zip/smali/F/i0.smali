.class public abstract LF/i0;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/i0$a;
    }
.end annotation


# instance fields
.field private a:I

.field private final b:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LO/a;

    invoke-direct {v0}, LO/a;-><init>()V

    invoke-virtual {v0}, LO/a;->a()I

    move-result v0

    iput v0, p0, LF/i0;->a:I

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, LF/i0;->b:Ljava/util/Map;

    return-void
.end method

.method public static synthetic a(LF/i0;Lz/X;)V
    .locals 1

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, LF/i0;->l()Lz/V$f;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0, p1}, Lz/V$e;->d(Lz/X;)V

    return-void

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "One and only one callback is allowed."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static synthetic b(LF/i0;Lz/V$h;)V
    .locals 0

    invoke-virtual {p0}, LF/i0;->l()Lz/V$f;

    const/4 p0, 0x0

    throw p0
.end method

.method public static synthetic c(LF/i0;Landroidx/camera/core/o;)V
    .locals 0

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0, p1}, Lz/V$e;->c(Landroidx/camera/core/o;)V

    return-void
.end method

.method public static synthetic d(LF/i0;Landroid/graphics/Bitmap;)V
    .locals 1

    invoke-virtual {p0}, LF/i0;->l()Lz/V$f;

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object p0

    invoke-virtual {p0, p1}, Lz/V$e;->e(Landroid/graphics/Bitmap;)V

    :cond_0
    return-void
.end method

.method public static synthetic e(LF/i0;I)V
    .locals 1

    invoke-virtual {p0}, LF/i0;->l()Lz/V$f;

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, LF/i0;->j()Lz/V$e;

    move-result-object p0

    invoke-virtual {p0, p1}, Lz/V$e;->a(I)V

    :cond_0
    return-void
.end method

.method public static v(Ljava/util/concurrent/Executor;Lz/V$e;Lz/V$f;Lz/V$g;Lz/V$g;Landroid/graphics/Rect;Landroid/graphics/Matrix;IIIZLjava/util/List;)LF/i0;
    .locals 15

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p2, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    move v2, v0

    :goto_0
    const-string v3, "onDiskCallback and outputFileOptions should be both null or both non-null."

    invoke-static {v2, v3}, LI0/g;->b(ZLjava/lang/Object;)V

    if-nez p2, :cond_1

    move v2, v1

    goto :goto_1

    :cond_1
    move v2, v0

    :goto_1
    if-nez p1, :cond_2

    move v0, v1

    :cond_2
    xor-int/2addr v0, v2

    const-string v1, "One and only one on-disk or in-memory callback should be present."

    invoke-static {v0, v1}, LI0/g;->b(ZLjava/lang/Object;)V

    new-instance v2, LF/g;

    move-object v3, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    move-object/from16 v6, p3

    move-object/from16 v7, p4

    move-object/from16 v8, p5

    move-object/from16 v9, p6

    move/from16 v10, p7

    move/from16 v11, p8

    move/from16 v12, p9

    move/from16 v13, p10

    move-object/from16 v14, p11

    invoke-direct/range {v2 .. v14}, LF/g;-><init>(Ljava/util/concurrent/Executor;Lz/V$e;Lz/V$f;Lz/V$g;Lz/V$g;Landroid/graphics/Rect;Landroid/graphics/Matrix;IIIZLjava/util/List;)V

    if-eqz p10, :cond_3

    invoke-virtual {v2}, LF/i0;->r()V

    :cond_3
    return-object v2
.end method


# virtual methods
.method A(Lz/V$h;)V
    .locals 2

    invoke-virtual {p0}, LF/i0;->g()Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v1, LF/h0;

    invoke-direct {v1, p0, p1}, LF/h0;-><init>(LF/i0;Lz/V$h;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method f()Z
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget v0, p0, LF/i0;->a:I

    if-lez v0, :cond_0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    iput v0, p0, LF/i0;->a:I

    return v1

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method abstract g()Ljava/util/concurrent/Executor;
.end method

.method abstract h()I
.end method

.method public abstract i()Landroid/graphics/Rect;
.end method

.method public abstract j()Lz/V$e;
.end method

.method public abstract k()I
.end method

.method public abstract l()Lz/V$f;
.end method

.method public abstract m()Lz/V$g;
.end method

.method public abstract n()I
.end method

.method public abstract o()Lz/V$g;
.end method

.method abstract p()Landroid/graphics/Matrix;
.end method

.method abstract q()Ljava/util/List;
.end method

.method r()V
    .locals 3

    iget-object v0, p0, LF/i0;->b:Ljava/util/Map;

    const/16 v1, 0x20

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, p0, LF/i0;->b:Ljava/util/Map;

    const/16 v0, 0x100

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p0, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method s()Z
    .locals 1

    iget-object p0, p0, LF/i0;->b:Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method abstract t()Z
.end method

.method u(IZ)V
    .locals 2

    iget-object v0, p0, LF/i0;->b:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string p0, "TakePictureRequest"

    const-string p1, "The format is not supported in simultaneous capture"

    invoke-static {p0, p1}, Lz/h0;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    iget-object p0, p0, LF/i0;->b:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method w(I)V
    .locals 2

    invoke-virtual {p0}, LF/i0;->g()Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v1, LF/e0;

    invoke-direct {v1, p0, p1}, LF/e0;-><init>(LF/i0;I)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method x(Lz/X;)V
    .locals 2

    invoke-virtual {p0}, LF/i0;->g()Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v1, LF/d0;

    invoke-direct {v1, p0, p1}, LF/d0;-><init>(LF/i0;Lz/X;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method y(Landroid/graphics/Bitmap;)V
    .locals 2

    invoke-virtual {p0}, LF/i0;->g()Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v1, LF/g0;

    invoke-direct {v1, p0, p1}, LF/g0;-><init>(LF/i0;Landroid/graphics/Bitmap;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method z(Landroidx/camera/core/o;)V
    .locals 2

    invoke-virtual {p0}, LF/i0;->g()Ljava/util/concurrent/Executor;

    move-result-object v0

    new-instance v1, LF/f0;

    invoke-direct {v1, p0, p1}, LF/f0;-><init>(LF/i0;Landroidx/camera/core/o;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
