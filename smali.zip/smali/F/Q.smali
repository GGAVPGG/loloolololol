.class public LF/Q;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/Q$a;,
        LF/Q$b;
    }
.end annotation


# instance fields
.field final a:Ljava/util/concurrent/Executor;

.field final b:LQ/w;

.field private final c:Landroid/hardware/camera2/CameraCharacteristics;

.field private d:LF/Q$a;

.field private e:LQ/y;

.field private f:LQ/y;

.field private g:LQ/y;

.field private h:LQ/y;

.field private i:LQ/y;

.field private j:LQ/y;

.field private k:LQ/y;

.field private l:LQ/y;

.field private m:LQ/y;

.field private final n:LG/d1;

.field private final o:Z


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCharacteristics;LQ/w;)V
    .locals 1

    .line 1
    invoke-static {}, Landroidx/camera/core/internal/compat/quirk/a;->c()LG/d1;

    move-result-object v0

    invoke-direct {p0, p1, p2, p3, v0}, LF/Q;-><init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCharacteristics;LQ/w;LG/d1;)V

    return-void
.end method

.method constructor <init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCharacteristics;LQ/w;LG/d1;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    const-class v0, Landroidx/camera/core/internal/compat/quirk/LowMemoryQuirk;

    invoke-static {v0}, Landroidx/camera/core/internal/compat/quirk/a;->b(Ljava/lang/Class;)LG/Z0;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 4
    invoke-static {p1}, LJ/c;->g(Ljava/util/concurrent/Executor;)Ljava/util/concurrent/Executor;

    move-result-object p1

    iput-object p1, p0, LF/Q;->a:Ljava/util/concurrent/Executor;

    goto :goto_0

    .line 5
    :cond_0
    iput-object p1, p0, LF/Q;->a:Ljava/util/concurrent/Executor;

    .line 6
    :goto_0
    iput-object p3, p0, LF/Q;->b:LQ/w;

    .line 7
    iput-object p2, p0, LF/Q;->c:Landroid/hardware/camera2/CameraCharacteristics;

    .line 8
    iput-object p4, p0, LF/Q;->n:LG/d1;

    .line 9
    const-class p1, Landroidx/camera/core/internal/compat/quirk/IncorrectJpegMetadataQuirk;

    invoke-virtual {p4, p1}, LG/d1;->a(Ljava/lang/Class;)Z

    move-result p1

    iput-boolean p1, p0, LF/Q;->o:Z

    return-void
.end method

.method public static synthetic a(LF/S;Lz/V$h;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/S;->r(Lz/V$h;)V

    return-void
.end method

.method public static synthetic b(LF/Q;LF/Q$b;)V
    .locals 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v0

    invoke-virtual {v0}, LF/S;->l()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, LF/Q$b;->a()Landroidx/camera/core/o;

    move-result-object p0

    invoke-interface {p0}, Landroidx/camera/core/o;->close()V

    return-void

    :cond_0
    iget-object v0, p0, LF/Q;->a:Ljava/util/concurrent/Executor;

    new-instance v1, LF/L;

    invoke-direct {v1, p0, p1}, LF/L;-><init>(LF/Q;LF/Q$b;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static synthetic c(LF/S;Landroidx/camera/core/o;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/S;->q(Landroidx/camera/core/o;)V

    return-void
.end method

.method public static synthetic d(LF/Q;LF/Q$b;)V
    .locals 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v0

    invoke-virtual {v0}, LF/S;->l()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "ProcessingNode"

    const-string v0, "The postview image is closed due to request aborted"

    invoke-static {p0, v0}, Lz/h0;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p1}, LF/Q$b;->a()Landroidx/camera/core/o;

    move-result-object p0

    invoke-interface {p0}, Landroidx/camera/core/o;->close()V

    return-void

    :cond_0
    iget-object v0, p0, LF/Q;->a:Ljava/util/concurrent/Executor;

    new-instance v1, LF/K;

    invoke-direct {v1, p0, p1}, LF/K;-><init>(LF/Q;LF/Q$b;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static synthetic e(LF/Q;LF/Q$b;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/Q;->m(LF/Q$b;)V

    return-void
.end method

.method public static synthetic f(LF/S;Landroid/graphics/Bitmap;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/S;->t(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method public static synthetic g(LF/S;Lz/X;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/S;->u(Lz/X;)V

    return-void
.end method

.method public static synthetic h(LF/Q;LF/Q$b;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/Q;->k(LF/Q$b;)V

    return-void
.end method

.method private i(LQ/z;I)LQ/z;
    .locals 1

    invoke-virtual {p1}, LQ/z;->e()I

    move-result v0

    invoke-static {v0}, LP/b;->i(I)Z

    move-result v0

    invoke-static {v0}, LI0/g;->i(Z)V

    iget-object v0, p0, LF/Q;->i:LQ/y;

    invoke-interface {v0, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LQ/z;

    iget-object v0, p0, LF/Q;->m:LQ/y;

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LQ/z;

    :cond_0
    iget-object p0, p0, LF/Q;->g:LQ/y;

    invoke-static {p1, p2}, LF/h$b;->c(LQ/z;I)LF/h$b;

    move-result-object p1

    invoke-interface {p0, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LQ/z;

    return-object p0
.end method

.method private o(LF/S;Lz/X;)V
    .locals 1

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p0

    new-instance v0, LF/P;

    invoke-direct {v0, p1, p2}, LF/P;-><init>(LF/S;Lz/X;)V

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method


# virtual methods
.method j(LF/Q$b;)Landroidx/camera/core/o;
    .locals 6

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v0

    iget-object v1, p0, LF/Q;->e:LQ/y;

    invoke-interface {v1, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LQ/z;

    iget-object v1, p0, LF/Q;->d:LF/Q$a;

    invoke-virtual {v1}, LF/Q$a;->c()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v3, 0x1

    xor-int/2addr v2, v3

    invoke-static {v2}, LI0/g;->a(Z)V

    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {p1}, LQ/z;->e()I

    move-result v4

    const/16 v5, 0x23

    if-eq v4, v5, :cond_0

    iget-object v4, p0, LF/Q;->m:LQ/y;

    if-nez v4, :cond_0

    iget-boolean v4, p0, LF/Q;->o:Z

    if-eqz v4, :cond_2

    :cond_0
    const/16 v4, 0x100

    if-ne v2, v4, :cond_2

    iget-object v2, p0, LF/Q;->f:LQ/y;

    invoke-virtual {v0}, LF/S;->c()I

    move-result v4

    invoke-static {p1, v4}, LF/x$a;->c(LQ/z;I)LF/x$a;

    move-result-object p1

    invoke-interface {v2, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LQ/z;

    iget-object v2, p0, LF/Q;->m:LQ/y;

    if-eqz v2, :cond_1

    invoke-virtual {v0}, LF/S;->c()I

    move-result v2

    invoke-direct {p0, p1, v2}, LF/Q;->i(LQ/z;I)LQ/z;

    move-result-object p1

    :cond_1
    iget-object v2, p0, LF/Q;->k:LQ/y;

    invoke-interface {v2, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LQ/z;

    :cond_2
    iget-object p0, p0, LF/Q;->j:LQ/y;

    invoke-interface {p0, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/o;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result p1

    if-le p1, v3, :cond_3

    invoke-virtual {v0}, LF/S;->k()LF/i0;

    move-result-object p1

    invoke-interface {p0}, Landroidx/camera/core/o;->getFormat()I

    move-result v0

    invoke-virtual {p1, v0, v3}, LF/i0;->u(IZ)V

    :cond_3
    return-object p0
.end method

.method k(LF/Q$b;)V
    .locals 4

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v0

    const/4 v1, 0x0

    :try_start_0
    iget-object v2, p0, LF/Q;->d:LF/Q$a;

    invoke-virtual {v2}, LF/Q$a;->c()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_0

    goto :goto_0

    :cond_0
    move v3, v1

    :goto_0
    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v2

    invoke-virtual {v2}, LF/S;->m()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0, p1}, LF/Q;->j(LF/Q$b;)Landroidx/camera/core/o;

    move-result-object p1

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    new-instance v3, LF/M;

    invoke-direct {v3, v0, p1}, LF/M;-><init>(LF/S;Landroidx/camera/core/o;)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :catch_0
    move-exception p1

    goto :goto_2

    :catch_1
    move-exception p1

    goto :goto_3

    :catch_2
    move-exception p1

    goto :goto_4

    :cond_1
    invoke-virtual {p0, p1}, LF/Q;->l(LF/Q$b;)Lz/V$h;

    move-result-object p1

    if-eqz v3, :cond_3

    invoke-virtual {v0}, LF/S;->k()LF/i0;

    move-result-object v2

    invoke-virtual {v2}, LF/i0;->s()Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_1

    :cond_2
    return-void

    :cond_3
    :goto_1
    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    new-instance v3, LF/N;

    invoke-direct {v3, v0, p1}, LF/N;-><init>(LF/S;Lz/V$h;)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Lz/X; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_2
    new-instance v2, Lz/X;

    const-string v3, "Processing failed."

    invoke-direct {v2, v1, v3, p1}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-direct {p0, v0, v2}, LF/Q;->o(LF/S;Lz/X;)V

    goto :goto_5

    :goto_3
    new-instance v2, Lz/X;

    const-string v3, "Processing failed due to low memory."

    invoke-direct {v2, v1, v3, p1}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-direct {p0, v0, v2}, LF/Q;->o(LF/S;Lz/X;)V

    goto :goto_5

    :goto_4
    invoke-direct {p0, v0, p1}, LF/Q;->o(LF/S;Lz/X;)V

    :goto_5
    return-void
.end method

.method l(LF/Q$b;)Lz/V$h;
    .locals 7

    iget-object v0, p0, LF/Q;->d:LF/Q$a;

    invoke-virtual {v0}, LF/Q$a;->c()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v2, 0x1

    xor-int/2addr v1, v2

    invoke-static {v1}, LI0/g;->a(Z)V

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-static {v4}, LP/b;->i(I)Z

    move-result v5

    if-nez v5, :cond_1

    invoke-static {v4}, LP/b;->j(I)Z

    move-result v5

    if-eqz v5, :cond_0

    goto :goto_0

    :cond_0
    move v5, v1

    goto :goto_1

    :cond_1
    :goto_0
    move v5, v2

    :goto_1
    const-string v6, "On-disk capture only support JPEG and JPEG/R and RAW output formats. Output format: %s"

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v6, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, LI0/g;->b(ZLjava/lang/Object;)V

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v3

    invoke-virtual {v3}, LF/S;->d()Lz/V$g;

    const-string v5, "OutputFileOptions cannot be empty"

    invoke-static {v1, v5}, LI0/g;->b(ZLjava/lang/Object;)V

    iget-object p0, p0, LF/Q;->e:LQ/y;

    invoke-interface {p0, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LQ/z;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p1

    const/16 v0, 0x20

    const/4 v5, 0x0

    if-le p1, v2, :cond_3

    invoke-virtual {v3}, LF/S;->d()Lz/V$g;

    const-string p1, "The number of OutputFileOptions for simultaneous capture should be at least two"

    invoke-static {v1, p1}, LI0/g;->b(ZLjava/lang/Object;)V

    invoke-virtual {p0}, LQ/z;->e()I

    move-result p0

    if-eq p0, v0, :cond_2

    invoke-virtual {v3}, LF/S;->g()Lz/V$g;

    throw v5

    :cond_2
    invoke-virtual {v3}, LF/S;->d()Lz/V$g;

    throw v5

    :cond_3
    if-eq v4, v0, :cond_4

    invoke-virtual {v3}, LF/S;->d()Lz/V$g;

    throw v5

    :cond_4
    invoke-virtual {v3}, LF/S;->d()Lz/V$g;

    throw v5
.end method

.method m(LF/Q$b;)V
    .locals 5

    invoke-virtual {p1}, LF/Q$b;->b()LF/S;

    move-result-object v0

    :try_start_0
    iget-object v1, p0, LF/Q;->e:LQ/y;

    invoke-interface {v1, p1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LQ/z;

    invoke-virtual {v1}, LQ/z;->e()I

    move-result v2

    const/16 v3, 0x23

    if-eq v2, v3, :cond_1

    const/16 v3, 0x100

    if-eq v2, v3, :cond_1

    const/16 v3, 0x1005

    if-ne v2, v3, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x1

    :goto_1
    const-string v4, "Postview only supports to convert YUV, JPEG and JPEG_R format image to the postview output bitmap. Image format: %s"

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v4, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, LI0/g;->b(ZLjava/lang/Object;)V

    iget-object p0, p0, LF/Q;->l:LQ/y;

    invoke-interface {p0, v1}, LQ/y;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v1

    new-instance v2, LF/O;

    invoke-direct {v2, v0, p0}, LF/O;-><init>(LF/S;Landroid/graphics/Bitmap;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    invoke-virtual {p1}, LF/Q$b;->a()Landroidx/camera/core/o;

    move-result-object p1

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    const-string p1, "ProcessingNode"

    const-string v0, "process postview input packet failed."

    invoke-static {p1, v0, p0}, Lz/h0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public n()V
    .locals 0

    return-void
.end method

.method public p(LF/Q$a;)Ljava/lang/Void;
    .locals 2

    iput-object p1, p0, LF/Q;->d:LF/Q$a;

    invoke-virtual {p1}, LF/Q$a;->a()LQ/u;

    move-result-object v0

    new-instance v1, LF/I;

    invoke-direct {v1, p0}, LF/I;-><init>(LF/Q;)V

    invoke-virtual {v0, v1}, LQ/u;->a(LI0/a;)V

    invoke-virtual {p1}, LF/Q$a;->d()LQ/u;

    move-result-object v0

    new-instance v1, LF/J;

    invoke-direct {v1, p0}, LF/J;-><init>(LF/Q;)V

    invoke-virtual {v0, v1}, LQ/u;->a(LI0/a;)V

    new-instance v0, LF/H;

    invoke-direct {v0}, LF/H;-><init>()V

    iput-object v0, p0, LF/Q;->e:LQ/y;

    new-instance v0, LF/x;

    iget-object v1, p0, LF/Q;->n:LG/d1;

    invoke-direct {v0, v1}, LF/x;-><init>(LG/d1;)V

    iput-object v0, p0, LF/Q;->f:LQ/y;

    new-instance v0, LF/A;

    invoke-direct {v0}, LF/A;-><init>()V

    iput-object v0, p0, LF/Q;->i:LQ/y;

    new-instance v0, LF/h;

    invoke-direct {v0}, LF/h;-><init>()V

    iput-object v0, p0, LF/Q;->g:LQ/y;

    new-instance v0, LF/B;

    invoke-direct {v0}, LF/B;-><init>()V

    iput-object v0, p0, LF/Q;->h:LQ/y;

    new-instance v0, LF/D;

    invoke-direct {v0}, LF/D;-><init>()V

    iput-object v0, p0, LF/Q;->j:LQ/y;

    new-instance v0, LF/w;

    invoke-direct {v0}, LF/w;-><init>()V

    iput-object v0, p0, LF/Q;->l:LQ/y;

    invoke-virtual {p1}, LF/Q$a;->b()I

    move-result p1

    const/16 v0, 0x23

    if-eq p1, v0, :cond_0

    iget-boolean p1, p0, LF/Q;->o:Z

    if-eqz p1, :cond_1

    :cond_0
    new-instance p1, LF/C;

    invoke-direct {p1}, LF/C;-><init>()V

    iput-object p1, p0, LF/Q;->k:LQ/y;

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method
