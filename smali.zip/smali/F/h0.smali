.class public final synthetic LF/h0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/i0;

.field public final synthetic g:Lz/V$h;


# direct methods
.method public synthetic constructor <init>(LF/i0;Lz/V$h;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/h0;->f:LF/i0;

    iput-object p2, p0, LF/h0;->g:Lz/V$h;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/h0;->f:LF/i0;

    iget-object p0, p0, LF/h0;->g:Lz/V$h;

    invoke-static {v0, p0}, LF/i0;->b(LF/i0;Lz/V$h;)V

    return-void
.end method
