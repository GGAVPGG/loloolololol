.class public LF/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LQ/z;)Landroid/graphics/Bitmap;
    .locals 8

    const/16 p0, 0x23

    const/4 v0, 0x0

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p1}, LQ/z;->e()I

    move-result v2

    if-ne v2, p0, :cond_4

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/o;

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v3

    rem-int/lit16 v3, v3, 0xb4

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    move v3, v4

    goto :goto_0

    :cond_0
    move v3, v0

    :goto_0
    if-eqz v3, :cond_1

    invoke-interface {v2}, Landroidx/camera/core/o;->a()I

    move-result v5

    goto :goto_1

    :catchall_0
    move-exception p0

    goto/16 :goto_7

    :catch_0
    move-exception v2

    goto/16 :goto_5

    :cond_1
    invoke-interface {v2}, Landroidx/camera/core/o;->b()I

    move-result v5

    :goto_1
    if-eqz v3, :cond_2

    invoke-interface {v2}, Landroidx/camera/core/o;->b()I

    move-result v3

    goto :goto_2

    :cond_2
    invoke-interface {v2}, Landroidx/camera/core/o;->a()I

    move-result v3

    :goto_2
    new-instance v6, Landroidx/camera/core/r;

    const/4 v7, 0x2

    invoke-static {v5, v3, v4, v7}, Landroidx/camera/core/p;->a(IIII)LG/F0;

    move-result-object v3

    invoke-direct {v6, v3}, Landroidx/camera/core/r;-><init>(LG/F0;)V
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-interface {v2}, Landroidx/camera/core/o;->b()I

    move-result v3

    invoke-interface {v2}, Landroidx/camera/core/o;->a()I

    move-result v4

    mul-int/2addr v3, v4

    mul-int/lit8 v3, v3, 0x4

    invoke-static {v3}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v4

    invoke-static {v2, v6, v3, v4, v0}, Landroidx/camera/core/ImageProcessingUtil;->g(Landroidx/camera/core/o;LG/F0;Ljava/nio/ByteBuffer;IZ)Landroidx/camera/core/o;

    move-result-object v3

    invoke-interface {v2}, Landroidx/camera/core/o;->close()V

    if-eqz v3, :cond_3

    invoke-static {v3}, LP/b;->b(Landroidx/camera/core/o;)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-interface {v3}, Landroidx/camera/core/o;->close()V

    goto :goto_4

    :catchall_1
    move-exception p0

    move-object v1, v6

    goto/16 :goto_7

    :catch_1
    move-exception v2

    move-object v1, v6

    goto :goto_5

    :cond_3
    new-instance v2, Lz/X;

    const-string v3, "Can\'t covert YUV to RGB"

    invoke-direct {v2, v0, v3, v1}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw v2
    :try_end_1
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_4
    const/16 v3, 0x100

    if-eq v2, v3, :cond_6

    const/16 v3, 0x1005

    if-ne v2, v3, :cond_5

    goto :goto_3

    :cond_5
    :try_start_2
    new-instance v2, Ljava/lang/IllegalArgumentException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Invalid postview image format : "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, LQ/z;->e()I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_6
    :goto_3
    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/camera/core/o;

    invoke-static {v2}, LP/b;->b(Landroidx/camera/core/o;)Landroid/graphics/Bitmap;

    move-result-object v3

    invoke-interface {v2}, Landroidx/camera/core/o;->close()V

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v2

    invoke-static {v3, v2}, LP/b;->l(Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_2
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object v6, v1

    move-object v1, p0

    :goto_4
    if-eqz v6, :cond_7

    invoke-virtual {v6}, Landroidx/camera/core/r;->close()V

    :cond_7
    return-object v1

    :goto_5
    :try_start_3
    invoke-virtual {p1}, LQ/z;->e()I

    move-result p1

    if-ne p1, p0, :cond_8

    const-string p0, "YUV"

    goto :goto_6

    :cond_8
    const-string p0, "JPEG"

    :goto_6
    new-instance p1, Lz/X;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Can\'t convert "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " to bitmap"

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, v0, p0, v2}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_7
    if-eqz v1, :cond_9

    invoke-virtual {v1}, Landroidx/camera/core/r;->close()V

    :cond_9
    throw p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LQ/z;

    invoke-virtual {p0, p1}, LF/w;->a(LQ/z;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method
