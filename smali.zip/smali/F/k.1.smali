.class public final LF/k;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/util/List;

.field private final b:LF/X;


# direct methods
.method public constructor <init>(Ljava/util/List;LF/X;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/k;->a:Ljava/util/List;

    iput-object p2, p0, LF/k;->b:LF/X;

    return-void
.end method


# virtual methods
.method a()Ljava/util/List;
    .locals 0

    iget-object p0, p0, LF/k;->a:Ljava/util/List;

    return-object p0
.end method

.method b()Z
    .locals 0

    iget-object p0, p0, LF/k;->b:LF/X;

    invoke-interface {p0}, LF/X;->a()Z

    move-result p0

    return p0
.end method
