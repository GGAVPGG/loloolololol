.class LF/u$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LK/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF/u;->l(LF/S;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LF/S;

.field final synthetic b:LF/u;


# direct methods
.method constructor <init>(LF/u;LF/S;)V
    .locals 0

    iput-object p1, p0, LF/u$b;->b:LF/u;

    iput-object p2, p0, LF/u$b;->a:LF/S;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Throwable;)V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-object p1, p0, LF/u$b;->a:LF/S;

    iget-object v0, p0, LF/u$b;->b:LF/u;

    iget-object v0, v0, LF/u;->a:LF/S;

    if-ne p1, v0, :cond_1

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "request aborted, id="

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, LF/u$b;->b:LF/u;

    iget-object v0, v0, LF/u;->a:LF/S;

    invoke-virtual {v0}, LF/S;->e()I

    move-result v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v0, "CaptureNode"

    invoke-static {v0, p1}, Lz/h0;->l(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, LF/u$b;->b:LF/u;

    invoke-static {p1}, LF/u;->g(LF/u;)LF/F;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p0, LF/u$b;->b:LF/u;

    invoke-static {p1}, LF/u;->g(LF/u;)LF/F;

    move-result-object p1

    invoke-virtual {p1}, LF/F;->k()V

    :cond_0
    iget-object p0, p0, LF/u$b;->b:LF/u;

    const/4 p1, 0x0

    iput-object p1, p0, LF/u;->a:LF/S;

    :cond_1
    return-void
.end method

.method public bridge synthetic b(Ljava/lang/Object;)V
    .locals 0

    check-cast p1, Ljava/lang/Void;

    invoke-virtual {p0, p1}, LF/u$b;->c(Ljava/lang/Void;)V

    return-void
.end method

.method public c(Ljava/lang/Void;)V
    .locals 0

    return-void
.end method
