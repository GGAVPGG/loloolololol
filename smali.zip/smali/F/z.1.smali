.class public LF/z;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static f:I

.field static final g:LO/b;


# instance fields
.field private final a:LG/C0;

.field private final b:LG/h0;

.field private final c:LF/u;

.field private final d:LF/Q;

.field private final e:LF/u$c;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LO/b;

    invoke-direct {v0}, LO/b;-><init>()V

    sput-object v0, LF/z;->g:LO/b;

    return-void
.end method

.method public constructor <init>(LG/C0;Landroid/util/Size;Landroid/hardware/camera2/CameraCharacteristics;Lz/k;ZLF/G;)V
    .locals 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, LI/y;->b()V

    iput-object p1, p0, LF/z;->a:LG/C0;

    invoke-static {p1}, LG/h0$a;->j(LG/A1;)LG/h0$a;

    move-result-object p4

    invoke-virtual {p4}, LG/h0$a;->h()LG/h0;

    move-result-object p4

    iput-object p4, p0, LF/z;->b:LG/h0;

    new-instance p4, LF/u;

    invoke-direct {p4}, LF/u;-><init>()V

    iput-object p4, p0, LF/z;->c:LF/u;

    new-instance v0, LF/Q;

    invoke-static {}, LJ/c;->d()Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-virtual {p1, v1}, LG/C0;->k0(Ljava/util/concurrent/Executor;)Ljava/util/concurrent/Executor;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/Executor;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p3, v2}, LF/Q;-><init>(Ljava/util/concurrent/Executor;Landroid/hardware/camera2/CameraCharacteristics;LQ/w;)V

    iput-object v0, p0, LF/z;->d:LF/Q;

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, LG/D0;->L()I

    move-result p3

    if-eqz p3, :cond_0

    const/16 p3, 0x20

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-interface {v5, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 p3, 0x100

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-interface {v5, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    invoke-direct {p0}, LF/z;->i()I

    move-result p3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-interface {v5, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    invoke-virtual {p1}, LG/C0;->t()I

    move-result v4

    invoke-virtual {p1}, LG/C0;->j0()Lz/d0;

    const/4 v7, 0x0

    move-object v3, p2

    move v6, p5

    move-object v8, p6

    invoke-static/range {v3 .. v8}, LF/u$c;->n(Landroid/util/Size;ILjava/util/List;ZLz/d0;LF/G;)LF/u$c;

    move-result-object p1

    iput-object p1, p0, LF/z;->e:LF/u$c;

    invoke-virtual {p4, p1}, LF/u;->s(LF/u$c;)LF/Q$a;

    move-result-object p0

    invoke-virtual {v0, p0}, LF/Q;->p(LF/Q$a;)Ljava/lang/Void;

    return-void
.end method

.method private b(ILG/g0;LF/i0;LF/X;)LF/k;
    .locals 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2}, LG/g0;->a()Ljava/util/List;

    move-result-object p2

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p2, Ljava/util/List;

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LG/i0;

    new-instance v3, LG/h0$a;

    invoke-direct {v3}, LG/h0$a;-><init>()V

    iget-object v4, p0, LF/z;->b:LG/h0;

    invoke-virtual {v4}, LG/h0;->k()I

    move-result v4

    invoke-virtual {v3, v4}, LG/h0$a;->v(I)V

    iget-object v4, p0, LF/z;->b:LG/h0;

    invoke-virtual {v4}, LG/h0;->g()LG/j0;

    move-result-object v4

    invoke-virtual {v3, v4}, LG/h0$a;->e(LG/j0;)V

    invoke-virtual {p3}, LF/i0;->q()Ljava/util/List;

    move-result-object v4

    invoke-virtual {v3, v4}, LG/h0$a;->a(Ljava/util/Collection;)V

    iget-object v4, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v4}, LF/u$c;->l()LG/q0;

    move-result-object v4

    invoke-virtual {v3, v4}, LG/h0$a;->f(LG/q0;)V

    iget-object v4, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v4}, LF/u$c;->e()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v5, 0x1

    if-le v4, v5, :cond_0

    iget-object v4, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v4}, LF/u$c;->j()LG/q0;

    move-result-object v4

    if-eqz v4, :cond_0

    iget-object v4, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v4}, LF/u$c;->j()LG/q0;

    move-result-object v4

    invoke-virtual {v3, v4}, LG/h0$a;->f(LG/q0;)V

    :cond_0
    invoke-direct {p0}, LF/z;->l()Z

    move-result v4

    if-eqz v4, :cond_1

    iget-object v6, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v6}, LF/u$c;->g()LG/q0;

    move-result-object v6

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3, v6}, LG/h0$a;->f(LG/q0;)V

    :cond_1
    invoke-virtual {v3, v4}, LG/h0$a;->t(Z)V

    iget-object v4, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v4}, LF/u$c;->d()I

    move-result v4

    invoke-static {v4}, LP/b;->i(I)Z

    move-result v4

    if-nez v4, :cond_2

    iget-object v4, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v4}, LF/u$c;->d()I

    move-result v4

    invoke-static {v4}, LP/b;->j(I)Z

    move-result v4

    if-eqz v4, :cond_4

    :cond_2
    sget-object v4, LF/z;->g:LO/b;

    invoke-virtual {v4}, LO/b;->a()Z

    move-result v4

    if-eqz v4, :cond_3

    sget-object v4, LG/h0;->i:LG/j0$a;

    invoke-virtual {p3}, LF/i0;->n()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v3, v4, v6}, LG/h0$a;->d(LG/j0$a;Ljava/lang/Object;)V

    :cond_3
    sget-object v4, LG/h0;->j:LG/j0$a;

    invoke-virtual {p0, p3}, LF/z;->g(LF/i0;)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v3, v4, v6}, LG/h0$a;->d(LG/j0$a;Ljava/lang/Object;)V

    :cond_4
    invoke-interface {v2}, LG/i0;->a()LG/h0;

    move-result-object v4

    invoke-virtual {v4}, LG/h0;->g()LG/j0;

    move-result-object v4

    invoke-virtual {v3, v4}, LG/h0$a;->e(LG/j0;)V

    invoke-interface {v2}, LG/i0;->getId()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v3, v1, v2}, LG/h0$a;->g(Ljava/lang/String;Ljava/lang/Object;)V

    invoke-virtual {v3, p1}, LG/h0$a;->r(I)V

    iget-object v2, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v2}, LF/u$c;->a()LG/r;

    move-result-object v2

    invoke-virtual {v3, v2}, LG/h0$a;->c(LG/r;)V

    iget-object v2, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v2}, LF/u$c;->e()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-le v2, v5, :cond_5

    iget-object v2, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v2}, LF/u$c;->i()LG/r;

    move-result-object v2

    if-eqz v2, :cond_5

    iget-object v2, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v2}, LF/u$c;->i()LG/r;

    move-result-object v2

    invoke-virtual {v3, v2}, LG/h0$a;->c(LG/r;)V

    :cond_5
    invoke-virtual {v3}, LG/h0$a;->h()LG/h0;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_6
    new-instance p0, LF/k;

    invoke-direct {p0, v0, p4}, LF/k;-><init>(Ljava/util/List;LF/X;)V

    return-object p0
.end method

.method private c()LG/g0;
    .locals 1

    iget-object p0, p0, LF/z;->a:LG/C0;

    invoke-static {}, Lz/E;->b()LG/g0;

    move-result-object v0

    invoke-virtual {p0, v0}, LG/C0;->f0(LG/g0;)LG/g0;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p0, LG/g0;

    return-object p0
.end method

.method private d(ILG/g0;LF/i0;LF/X;LW5/a;)LF/S;
    .locals 1

    new-instance p0, LF/S;

    move-object v0, p5

    move p5, p1

    move-object p1, p2

    move-object p2, p3

    move-object p3, p4

    move-object p4, v0

    invoke-direct/range {p0 .. p5}, LF/S;-><init>(LG/g0;LF/i0;LF/X;LW5/a;I)V

    return-object p0
.end method

.method private i()I
    .locals 3

    iget-object v0, p0, LF/z;->a:LG/C0;

    sget-object v1, LG/C0;->T:LG/j0$a;

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    :cond_0
    iget-object p0, p0, LF/z;->a:LG/C0;

    sget-object v0, LG/D0;->j:LG/j0$a;

    invoke-interface {p0, v0, v2}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/16 v1, 0x1005

    if-ne v0, v1, :cond_1

    return v1

    :cond_1
    if-eqz p0, :cond_2

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/16 v0, 0x20

    if-ne p0, v0, :cond_2

    return v0

    :cond_2
    const/16 p0, 0x100

    return p0
.end method

.method private l()Z
    .locals 0

    iget-object p0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {p0}, LF/u$c;->g()LG/q0;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public a()V
    .locals 1

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/z;->c:LF/u;

    invoke-virtual {v0}, LF/u;->n()V

    iget-object p0, p0, LF/z;->d:LF/Q;

    invoke-virtual {p0}, LF/Q;->n()V

    return-void
.end method

.method e(LF/i0;LF/X;LW5/a;)LI0/d;
    .locals 8

    invoke-static {}, LI/y;->b()V

    invoke-direct {p0}, LF/z;->c()LG/g0;

    move-result-object v2

    sget v1, LF/z;->f:I

    add-int/lit8 v0, v1, 0x1

    sput v0, LF/z;->f:I

    new-instance v6, LI0/d;

    invoke-direct {p0, v1, v2, p1, p2}, LF/z;->b(ILG/g0;LF/i0;LF/X;)LF/k;

    move-result-object v7

    move-object v0, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    invoke-direct/range {v0 .. v5}, LF/z;->d(ILG/g0;LF/i0;LF/X;LW5/a;)LF/S;

    move-result-object p0

    invoke-direct {v6, v7, p0}, LI0/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v6
.end method

.method public f(Landroid/util/Size;)LG/h1$b;
    .locals 2

    iget-object v0, p0, LF/z;->a:LG/C0;

    invoke-static {v0, p1}, LG/h1$b;->r(LG/A1;Landroid/util/Size;)LG/h1$b;

    move-result-object p1

    iget-object v0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v0}, LF/u$c;->l()LG/q0;

    move-result-object v0

    invoke-virtual {p1, v0}, LG/h1$b;->h(LG/q0;)LG/h1$b;

    iget-object v0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v0}, LF/u$c;->e()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_0

    iget-object v0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v0}, LF/u$c;->j()LG/q0;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v0}, LF/u$c;->j()LG/q0;

    move-result-object v0

    invoke-virtual {p1, v0}, LG/h1$b;->h(LG/q0;)LG/h1$b;

    :cond_0
    iget-object v0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {v0}, LF/u$c;->g()LG/q0;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object p0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {p0}, LF/u$c;->g()LG/q0;

    move-result-object p0

    invoke-virtual {p1, p0}, LG/h1$b;->y(LG/q0;)LG/h1$b;

    :cond_1
    return-object p1
.end method

.method g(LF/i0;)I
    .locals 1

    invoke-virtual {p1}, LF/i0;->l()Lz/V$f;

    invoke-virtual {p1}, LF/i0;->i()Landroid/graphics/Rect;

    move-result-object v0

    iget-object p0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {p0}, LF/u$c;->k()Landroid/util/Size;

    move-result-object p0

    invoke-static {v0, p0}, LI/z;->h(Landroid/graphics/Rect;Landroid/util/Size;)Z

    invoke-virtual {p1}, LF/i0;->k()I

    move-result p0

    return p0
.end method

.method public h()I
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/z;->c:LF/u;

    invoke-virtual {p0}, LF/u;->i()I

    move-result p0

    return p0
.end method

.method j(LF/Y$a;)V
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {p0}, LF/u$c;->b()LQ/u;

    move-result-object p0

    invoke-virtual {p0, p1}, LQ/u;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public k(Landroidx/camera/core/e$a;)V
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/z;->c:LF/u;

    invoke-virtual {p0, p1}, LF/u;->r(Landroidx/camera/core/e$a;)V

    return-void
.end method

.method m(LF/S;)V
    .locals 0

    invoke-static {}, LI/y;->b()V

    iget-object p0, p0, LF/z;->e:LF/u$c;

    invoke-virtual {p0}, LF/u$c;->h()LQ/u;

    move-result-object p0

    invoke-virtual {p0, p1}, LQ/u;->accept(Ljava/lang/Object;)V

    return-void
.end method
