.class public abstract LF/h$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static c(LQ/z;I)LF/h$b;
    .locals 1

    new-instance v0, LF/a;

    invoke-direct {v0, p0, p1}, LF/a;-><init>(LQ/z;I)V

    return-object v0
.end method


# virtual methods
.method abstract a()I
.end method

.method abstract b()LQ/z;
.end method
