.class LF/u;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/u$c;
    }
.end annotation


# instance fields
.field a:LF/S;

.field b:Landroidx/camera/core/r;

.field c:Landroidx/camera/core/r;

.field d:Landroidx/camera/core/r;

.field private e:LF/Q$a;

.field private f:LF/u$c;

.field private g:LF/F;


# direct methods
.method constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, LF/u;->a:LF/S;

    iput-object v0, p0, LF/u;->g:LF/F;

    return-void
.end method

.method public static synthetic a(LF/u;LG/F0;)V
    .locals 4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "Failed to acquire latest image"

    const/4 v1, 0x2

    :try_start_0
    invoke-interface {p1}, LG/F0;->d()Landroidx/camera/core/o;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p0, p1}, LF/u;->k(Landroidx/camera/core/o;)V

    return-void

    :catch_0
    move-exception p1

    goto :goto_0

    :cond_0
    iget-object p1, p0, LF/u;->a:LF/S;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, LF/S;->e()I

    move-result p1

    new-instance v2, Lz/X;

    const/4 v3, 0x0

    invoke-direct {v2, v1, v0, v3}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {p1, v2}, LF/Y$a;->c(ILz/X;)LF/Y$a;

    move-result-object p1

    invoke-virtual {p0, p1}, LF/u;->p(LF/Y$a;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :goto_0
    iget-object v2, p0, LF/u;->a:LF/S;

    if-eqz v2, :cond_1

    invoke-virtual {v2}, LF/S;->e()I

    move-result v2

    new-instance v3, Lz/X;

    invoke-direct {v3, v1, v0, p1}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {v2, v3}, LF/Y$a;->c(ILz/X;)LF/Y$a;

    move-result-object p1

    invoke-virtual {p0, p1}, LF/u;->p(LF/Y$a;)V

    :cond_1
    return-void
.end method

.method public static synthetic b(LF/u;LF/S;)V
    .locals 0

    invoke-virtual {p0, p1}, LF/u;->l(LF/S;)V

    iget-object p0, p0, LF/u;->g:LF/F;

    invoke-virtual {p0, p1}, LF/F;->j(LF/S;)V

    return-void
.end method

.method public static synthetic c(Landroidx/camera/core/r;)V
    .locals 0

    invoke-virtual {p0}, Landroidx/camera/core/r;->l()V

    return-void
.end method

.method public static synthetic d(Landroidx/camera/core/r;)V
    .locals 0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/camera/core/r;->l()V

    :cond_0
    return-void
.end method

.method public static synthetic e(LF/u;LG/F0;)V
    .locals 1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    invoke-interface {p1}, LG/F0;->d()Landroidx/camera/core/o;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-direct {p0, p1}, LF/u;->m(Landroidx/camera/core/o;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    return-void

    :catch_0
    move-exception p0

    const-string p1, "CaptureNode"

    const-string v0, "Failed to acquire latest image of postview"

    invoke-static {p1, v0, p0}, Lz/h0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public static synthetic f(Landroidx/camera/core/r;)V
    .locals 0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroidx/camera/core/r;->l()V

    :cond_0
    return-void
.end method

.method static synthetic g(LF/u;)LF/F;
    .locals 0

    iget-object p0, p0, LF/u;->g:LF/F;

    return-object p0
.end method

.method private static h(Lz/d0;III)LG/F0;
    .locals 7

    if-eqz p0, :cond_0

    const/4 v4, 0x4

    const-wide/16 v5, 0x0

    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    invoke-interface/range {v0 .. v6}, Lz/d0;->a(IIIIJ)LG/F0;

    move-result-object p0

    return-object p0

    :cond_0
    move v1, p1

    move v2, p2

    move v3, p3

    const/4 p0, 0x4

    invoke-static {v1, v2, v3, p0}, Landroidx/camera/core/p;->a(IIII)LG/F0;

    move-result-object p0

    return-object p0
.end method

.method private j(Landroidx/camera/core/o;)V
    .locals 4

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/u;->e:LF/Q$a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, LF/Q$a;->a()LQ/u;

    move-result-object v0

    iget-object v1, p0, LF/u;->a:LF/S;

    invoke-static {v1, p1}, LF/Q$b;->c(LF/S;Landroidx/camera/core/o;)LF/Q$b;

    move-result-object v1

    invoke-virtual {v0, v1}, LQ/u;->accept(Ljava/lang/Object;)V

    iget-object v0, p0, LF/u;->a:LF/S;

    iget-object v1, p0, LF/u;->f:LF/u$c;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, LF/u$c;->e()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-le v1, v2, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    if-eqz v1, :cond_1

    iget-object v3, p0, LF/u;->a:LF/S;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, LF/S;->k()LF/i0;

    move-result-object v3

    invoke-interface {p1}, Landroidx/camera/core/o;->getFormat()I

    move-result p1

    invoke-virtual {v3, p1, v2}, LF/i0;->u(IZ)V

    :cond_1
    if-eqz v1, :cond_2

    iget-object p1, p0, LF/u;->a:LF/S;

    if-eqz p1, :cond_3

    invoke-virtual {p1}, LF/S;->k()LF/i0;

    move-result-object p1

    invoke-virtual {p1}, LF/i0;->s()Z

    move-result p1

    if-eqz p1, :cond_3

    :cond_2
    const/4 p1, 0x0

    iput-object p1, p0, LF/u;->a:LF/S;

    :cond_3
    invoke-virtual {v0}, LF/S;->s()V

    return-void
.end method

.method private m(Landroidx/camera/core/o;)V
    .locals 1

    iget-object v0, p0, LF/u;->a:LF/S;

    if-nez v0, :cond_0

    const-string p0, "CaptureNode"

    const-string v0, "Postview image is closed due to request completed or aborted"

    invoke-static {p0, v0}, Lz/h0;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    return-void

    :cond_0
    iget-object v0, p0, LF/u;->e:LF/Q$a;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, LF/Q$a;->d()LQ/u;

    move-result-object v0

    iget-object p0, p0, LF/u;->a:LF/S;

    invoke-static {p0, p1}, LF/Q$b;->c(LF/S;Landroidx/camera/core/o;)LF/Q$b;

    move-result-object p0

    invoke-virtual {v0, p0}, LQ/u;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method private o(LF/u$c;Landroidx/camera/core/r;Landroidx/camera/core/r;Landroidx/camera/core/r;)V
    .locals 1

    invoke-virtual {p1}, LF/u$c;->l()LG/q0;

    move-result-object p0

    invoke-virtual {p0}, LG/q0;->d()V

    invoke-virtual {p1}, LF/u$c;->l()LG/q0;

    move-result-object p0

    invoke-virtual {p0}, LG/q0;->k()LW5/a;

    move-result-object p0

    new-instance v0, LF/p;

    invoke-direct {v0, p2}, LF/p;-><init>(Landroidx/camera/core/r;)V

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p2

    invoke-interface {p0, v0, p2}, LW5/a;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    invoke-virtual {p1}, LF/u$c;->g()LG/q0;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p1}, LF/u$c;->g()LG/q0;

    move-result-object p0

    invoke-virtual {p0}, LG/q0;->d()V

    invoke-virtual {p1}, LF/u$c;->g()LG/q0;

    move-result-object p0

    invoke-virtual {p0}, LG/q0;->k()LW5/a;

    move-result-object p0

    new-instance p2, LF/q;

    invoke-direct {p2, p4}, LF/q;-><init>(Landroidx/camera/core/r;)V

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p4

    invoke-interface {p0, p2, p4}, LW5/a;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_0
    invoke-virtual {p1}, LF/u$c;->e()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    const/4 p2, 0x1

    if-le p0, p2, :cond_1

    invoke-virtual {p1}, LF/u$c;->j()LG/q0;

    move-result-object p0

    if-eqz p0, :cond_1

    invoke-virtual {p1}, LF/u$c;->j()LG/q0;

    move-result-object p0

    invoke-virtual {p0}, LG/q0;->d()V

    invoke-virtual {p1}, LF/u$c;->j()LG/q0;

    move-result-object p0

    invoke-virtual {p0}, LG/q0;->k()LW5/a;

    move-result-object p0

    new-instance p1, LF/r;

    invoke-direct {p1, p3}, LF/r;-><init>(Landroidx/camera/core/r;)V

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p2

    invoke-interface {p0, p1, p2}, LW5/a;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_1
    return-void
.end method

.method private q(LG/F0;)V
    .locals 1

    new-instance v0, LF/s;

    invoke-direct {v0, p0}, LF/s;-><init>(LF/u;)V

    invoke-static {}, LJ/c;->e()Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object p0

    invoke-interface {p1, v0, p0}, LG/F0;->g(LG/F0$a;Ljava/util/concurrent/Executor;)V

    return-void
.end method


# virtual methods
.method public i()I
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/u;->b:Landroidx/camera/core/r;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "The ImageReader is not initialized."

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    iget-object p0, p0, LF/u;->b:Landroidx/camera/core/r;

    invoke-virtual {p0}, Landroidx/camera/core/r;->k()I

    move-result p0

    return p0
.end method

.method k(Landroidx/camera/core/o;)V
    .locals 3

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/u;->a:LF/S;

    const-string v1, "CaptureNode"

    if-nez v0, :cond_0

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Discarding ImageProxy which was inadvertently acquired: "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Lz/h0;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    return-void

    :cond_0
    invoke-interface {p1}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object v0

    invoke-interface {v0}, Lz/Y;->b()LG/r1;

    move-result-object v0

    iget-object v2, p0, LF/u;->a:LF/S;

    invoke-virtual {v2}, LF/S;->j()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, LG/r1;->d(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_1

    const-string p0, "Discarding ImageProxy which was acquired for aborted request"

    invoke-static {v1, p0}, Lz/h0;->l(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    return-void

    :cond_1
    invoke-direct {p0, p1}, LF/u;->j(Landroidx/camera/core/o;)V

    return-void
.end method

.method l(LF/S;)V
    .locals 4

    invoke-static {}, LI/y;->b()V

    invoke-virtual {p1}, LF/S;->i()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    const-string v3, "only one capture stage is supported."

    invoke-static {v0, v3}, LI0/g;->j(ZLjava/lang/String;)V

    invoke-virtual {p0}, LF/u;->i()I

    move-result v0

    if-lez v0, :cond_1

    move v1, v2

    :cond_1
    const-string v0, "Too many acquire images. Close image to be able to process next."

    invoke-static {v1, v0}, LI0/g;->j(ZLjava/lang/String;)V

    iput-object p1, p0, LF/u;->a:LF/S;

    invoke-virtual {p1}, LF/S;->a()LW5/a;

    move-result-object v0

    new-instance v1, LF/u$b;

    invoke-direct {v1, p0, p1}, LF/u$b;-><init>(LF/u;LF/S;)V

    invoke-static {}, LJ/c;->b()Ljava/util/concurrent/Executor;

    move-result-object p0

    invoke-static {v0, v1, p0}, LK/n;->j(LW5/a;LK/c;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public n()V
    .locals 4

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/u;->f:LF/u$c;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, LF/u;->b:Landroidx/camera/core/r;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v2, p0, LF/u;->c:Landroidx/camera/core/r;

    iget-object v3, p0, LF/u;->d:Landroidx/camera/core/r;

    invoke-direct {p0, v0, v1, v2, v3}, LF/u;->o(LF/u$c;Landroidx/camera/core/r;Landroidx/camera/core/r;Landroidx/camera/core/r;)V

    return-void
.end method

.method p(LF/Y$a;)V
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/u;->a:LF/S;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LF/S;->e()I

    move-result v0

    invoke-virtual {p1}, LF/Y$a;->b()I

    move-result v1

    if-ne v0, v1, :cond_0

    iget-object p0, p0, LF/u;->a:LF/S;

    invoke-virtual {p1}, LF/Y$a;->a()Lz/X;

    move-result-object p1

    invoke-virtual {p0, p1}, LF/S;->n(Lz/X;)V

    :cond_0
    return-void
.end method

.method public r(Landroidx/camera/core/e$a;)V
    .locals 2

    invoke-static {}, LI/y;->b()V

    iget-object v0, p0, LF/u;->b:Landroidx/camera/core/r;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "The ImageReader is not initialized."

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    iget-object p0, p0, LF/u;->b:Landroidx/camera/core/r;

    invoke-virtual {p0, p1}, Landroidx/camera/core/r;->m(Landroidx/camera/core/e$a;)V

    return-void
.end method

.method public s(LF/u$c;)LF/Q$a;
    .locals 12

    iget-object v0, p0, LF/u;->f:LF/u$c;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, LF/u;->b:Landroidx/camera/core/r;

    if-nez v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    const-string v3, "CaptureNode does not support recreation yet."

    invoke-static {v0, v3}, LI0/g;->j(ZLjava/lang/String;)V

    iput-object p1, p0, LF/u;->f:LF/u$c;

    invoke-virtual {p1}, LF/u$c;->k()Landroid/util/Size;

    move-result-object v0

    invoke-virtual {p1}, LF/u$c;->d()I

    move-result v3

    invoke-virtual {p1}, LF/u$c;->m()Z

    move-result v4

    new-instance v5, LF/u$a;

    invoke-direct {v5, p0}, LF/u$a;-><init>(LF/u;)V

    invoke-virtual {p1}, LF/u$c;->e()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-le v6, v2, :cond_1

    move v6, v2

    goto :goto_1

    :cond_1
    move v6, v1

    :goto_1
    const/4 v7, 0x0

    if-nez v4, :cond_3

    invoke-virtual {p1}, LF/u$c;->c()Lz/d0;

    const/4 v4, 0x2

    const/4 v8, 0x4

    if-eqz v6, :cond_2

    new-instance v3, Landroidx/camera/core/q;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v7

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v9

    const/16 v10, 0x100

    invoke-direct {v3, v7, v9, v10, v8}, Landroidx/camera/core/q;-><init>(IIII)V

    invoke-virtual {v3}, Landroidx/camera/core/q;->o()LG/r;

    move-result-object v7

    new-array v9, v4, [LG/r;

    aput-object v5, v9, v1

    aput-object v7, v9, v2

    invoke-static {v9}, LG/s;->b([LG/r;)LG/r;

    move-result-object v7

    new-instance v9, Landroidx/camera/core/q;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v10

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    const/16 v11, 0x20

    invoke-direct {v9, v10, v0, v11, v8}, Landroidx/camera/core/q;-><init>(IIII)V

    invoke-virtual {v9}, Landroidx/camera/core/q;->o()LG/r;

    move-result-object v0

    new-array v4, v4, [LG/r;

    aput-object v5, v4, v1

    aput-object v0, v4, v2

    invoke-static {v4}, LG/s;->b([LG/r;)LG/r;

    move-result-object v0

    move-object v5, v7

    move-object v7, v0

    goto :goto_2

    :cond_2
    new-instance v9, Landroidx/camera/core/q;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v10

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    invoke-direct {v9, v10, v0, v3, v8}, Landroidx/camera/core/q;-><init>(IIII)V

    invoke-virtual {v9}, Landroidx/camera/core/q;->o()LG/r;

    move-result-object v0

    new-array v3, v4, [LG/r;

    aput-object v5, v3, v1

    aput-object v0, v3, v2

    invoke-static {v3}, LG/s;->b([LG/r;)LG/r;

    move-result-object v0

    move-object v5, v0

    move-object v3, v9

    move-object v9, v7

    :goto_2
    new-instance v0, LF/l;

    invoke-direct {v0, p0}, LF/l;-><init>(LF/u;)V

    goto :goto_3

    :cond_3
    new-instance v1, LF/F;

    invoke-virtual {p1}, LF/u$c;->c()Lz/d0;

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v2

    invoke-virtual {v0}, Landroid/util/Size;->getHeight()I

    move-result v0

    invoke-static {v7, v2, v0, v3}, LF/u;->h(Lz/d0;III)LG/F0;

    move-result-object v0

    invoke-direct {v1, v0}, LF/F;-><init>(LG/F0;)V

    iput-object v1, p0, LF/u;->g:LF/F;

    new-instance v0, LF/m;

    invoke-direct {v0, p0}, LF/m;-><init>(LF/u;)V

    move-object v3, v1

    move-object v9, v7

    :goto_3
    invoke-virtual {p1, v5}, LF/u$c;->o(LG/r;)V

    if-eqz v6, :cond_4

    if-eqz v7, :cond_4

    invoke-virtual {p1, v7}, LF/u$c;->q(LG/r;)V

    :cond_4
    invoke-interface {v3}, LG/F0;->getSurface()Landroid/view/Surface;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1, v1}, LF/u$c;->s(Landroid/view/Surface;)V

    new-instance v1, Landroidx/camera/core/r;

    invoke-direct {v1, v3}, Landroidx/camera/core/r;-><init>(LG/F0;)V

    iput-object v1, p0, LF/u;->b:Landroidx/camera/core/r;

    invoke-direct {p0, v3}, LF/u;->q(LG/F0;)V

    invoke-virtual {p1}, LF/u$c;->f()LF/G;

    if-eqz v6, :cond_5

    if-eqz v9, :cond_5

    invoke-interface {v9}, LG/F0;->getSurface()Landroid/view/Surface;

    move-result-object v1

    invoke-virtual {p1, v1}, LF/u$c;->r(Landroid/view/Surface;)V

    new-instance v1, Landroidx/camera/core/r;

    invoke-direct {v1, v9}, Landroidx/camera/core/r;-><init>(LG/F0;)V

    iput-object v1, p0, LF/u;->c:Landroidx/camera/core/r;

    invoke-direct {p0, v9}, LF/u;->q(LG/F0;)V

    :cond_5
    invoke-virtual {p1}, LF/u$c;->h()LQ/u;

    move-result-object v1

    invoke-virtual {v1, v0}, LQ/u;->a(LI0/a;)V

    invoke-virtual {p1}, LF/u$c;->b()LQ/u;

    move-result-object v0

    new-instance v1, LF/o;

    invoke-direct {v1, p0}, LF/o;-><init>(LF/u;)V

    invoke-virtual {v0, v1}, LQ/u;->a(LI0/a;)V

    invoke-virtual {p1}, LF/u$c;->d()I

    move-result v0

    invoke-virtual {p1}, LF/u$c;->e()Ljava/util/List;

    move-result-object p1

    invoke-static {v0, p1}, LF/Q$a;->e(ILjava/util/List;)LF/Q$a;

    move-result-object p1

    iput-object p1, p0, LF/u;->e:LF/Q$a;

    return-object p1
.end method
