.class LF/S;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:I

.field b:LF/i0;

.field private final c:Landroid/graphics/Rect;

.field private final d:I

.field private final e:I

.field private final f:Landroid/graphics/Matrix;

.field private final g:LF/X;

.field private final h:Ljava/lang/String;

.field private final i:Ljava/util/List;

.field final j:LW5/a;

.field private k:I


# direct methods
.method constructor <init>(LG/g0;LF/i0;LF/X;LW5/a;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, LF/S;->k:I

    iput p5, p0, LF/S;->a:I

    iput-object p2, p0, LF/S;->b:LF/i0;

    invoke-virtual {p2}, LF/i0;->m()Lz/V$g;

    invoke-virtual {p2}, LF/i0;->o()Lz/V$g;

    invoke-virtual {p2}, LF/i0;->k()I

    move-result p5

    iput p5, p0, LF/S;->e:I

    invoke-virtual {p2}, LF/i0;->n()I

    move-result p5

    iput p5, p0, LF/S;->d:I

    invoke-virtual {p2}, LF/i0;->i()Landroid/graphics/Rect;

    move-result-object p5

    iput-object p5, p0, LF/S;->c:Landroid/graphics/Rect;

    invoke-virtual {p2}, LF/i0;->p()Landroid/graphics/Matrix;

    move-result-object p2

    iput-object p2, p0, LF/S;->f:Landroid/graphics/Matrix;

    iput-object p3, p0, LF/S;->g:LF/X;

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p2

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, LF/S;->h:Ljava/lang/String;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, LF/S;->i:Ljava/util/List;

    invoke-interface {p1}, LG/g0;->a()Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p1, Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, LG/i0;

    iget-object p3, p0, LF/S;->i:Ljava/util/List;

    invoke-interface {p2}, LG/i0;->getId()I

    move-result p2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-interface {p3, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iput-object p4, p0, LF/S;->j:LW5/a;

    return-void
.end method


# virtual methods
.method a()LW5/a;
    .locals 0

    iget-object p0, p0, LF/S;->j:LW5/a;

    return-object p0
.end method

.method b()Landroid/graphics/Rect;
    .locals 0

    iget-object p0, p0, LF/S;->c:Landroid/graphics/Rect;

    return-object p0
.end method

.method c()I
    .locals 0

    iget p0, p0, LF/S;->e:I

    return p0
.end method

.method d()Lz/V$g;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public e()I
    .locals 0

    iget p0, p0, LF/S;->a:I

    return p0
.end method

.method f()I
    .locals 0

    iget p0, p0, LF/S;->d:I

    return p0
.end method

.method g()Lz/V$g;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method h()Landroid/graphics/Matrix;
    .locals 0

    iget-object p0, p0, LF/S;->f:Landroid/graphics/Matrix;

    return-object p0
.end method

.method i()Ljava/util/List;
    .locals 0

    iget-object p0, p0, LF/S;->i:Ljava/util/List;

    return-object p0
.end method

.method j()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LF/S;->h:Ljava/lang/String;

    return-object p0
.end method

.method k()LF/i0;
    .locals 0

    iget-object p0, p0, LF/S;->b:LF/i0;

    return-object p0
.end method

.method l()Z
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0}, LF/X;->a()Z

    move-result p0

    return p0
.end method

.method m()Z
    .locals 0

    invoke-virtual {p0}, LF/S;->d()Lz/V$g;

    invoke-virtual {p0}, LF/S;->g()Lz/V$g;

    const/4 p0, 0x1

    return p0
.end method

.method n(Lz/X;)V
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0, p1}, LF/X;->c(Lz/X;)V

    return-void
.end method

.method o(I)V
    .locals 1

    iget v0, p0, LF/S;->k:I

    if-eq v0, p1, :cond_0

    iput p1, p0, LF/S;->k:I

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0, p1}, LF/X;->onCaptureProcessProgressed(I)V

    :cond_0
    return-void
.end method

.method p()V
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0}, LF/X;->g()V

    return-void
.end method

.method q(Landroidx/camera/core/o;)V
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0, p1}, LF/X;->h(Landroidx/camera/core/o;)V

    return-void
.end method

.method r(Lz/V$h;)V
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0, p1}, LF/X;->f(Lz/V$h;)V

    return-void
.end method

.method s()V
    .locals 2

    iget v0, p0, LF/S;->k:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_0

    const/16 v0, 0x64

    invoke-virtual {p0, v0}, LF/S;->o(I)V

    :cond_0
    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0}, LF/X;->b()V

    return-void
.end method

.method t(Landroid/graphics/Bitmap;)V
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0, p1}, LF/X;->d(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method u(Lz/X;)V
    .locals 0

    iget-object p0, p0, LF/S;->g:LF/X;

    invoke-interface {p0, p1}, LF/X;->e(Lz/X;)V

    return-void
.end method
