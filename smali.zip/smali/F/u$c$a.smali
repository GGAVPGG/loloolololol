.class LF/u$c$a;
.super LG/r;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF/u$c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LF/u$c;


# direct methods
.method constructor <init>(LF/u$c;)V
    .locals 0

    iput-object p1, p0, LF/u$c$a;->a:LF/u$c;

    invoke-direct {p0}, LG/r;-><init>()V

    return-void
.end method
