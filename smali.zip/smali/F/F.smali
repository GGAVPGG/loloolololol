.class public LF/F;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/F0;


# instance fields
.field private final a:LG/F0;

.field private b:LF/S;


# direct methods
.method constructor <init>(LG/F0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/F;->a:LG/F0;

    return-void
.end method

.method public static synthetic c(LF/F;LG/F0$a;LG/F0;)V
    .locals 0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1, p0}, LG/F0$a;->a(LG/F0;)V

    return-void
.end method

.method private l(Landroidx/camera/core/o;)Landroidx/camera/core/o;
    .locals 6

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    iget-object v1, p0, LF/F;->b:LF/S;

    if-nez v1, :cond_1

    invoke-static {}, LG/r1;->b()LG/r1;

    move-result-object v1

    goto :goto_0

    :cond_1
    new-instance v1, Landroid/util/Pair;

    iget-object v2, p0, LF/F;->b:LF/S;

    invoke-virtual {v2}, LF/S;->j()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, LF/F;->b:LF/S;

    invoke-virtual {v3}, LF/S;->i()Ljava/util/List;

    move-result-object v3

    const/4 v4, 0x0

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v1}, LG/r1;->a(Landroid/util/Pair;)LG/r1;

    move-result-object v1

    :goto_0
    iput-object v0, p0, LF/F;->b:LF/S;

    new-instance p0, Landroidx/camera/core/s;

    new-instance v0, Landroid/util/Size;

    invoke-interface {p1}, Landroidx/camera/core/o;->b()I

    move-result v2

    invoke-interface {p1}, Landroidx/camera/core/o;->a()I

    move-result v3

    invoke-direct {v0, v2, v3}, Landroid/util/Size;-><init>(II)V

    new-instance v2, LL/c;

    new-instance v3, LU/l;

    invoke-interface {p1}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object v4

    invoke-interface {v4}, Lz/Y;->a()J

    move-result-wide v4

    invoke-direct {v3, v1, v4, v5}, LU/l;-><init>(LG/r1;J)V

    invoke-direct {v2, v3}, LL/c;-><init>(LG/B;)V

    invoke-direct {p0, p1, v0, v2}, Landroidx/camera/core/s;-><init>(Landroidx/camera/core/o;Landroid/util/Size;Lz/Y;)V

    return-object p0
.end method


# virtual methods
.method public a()I
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->a()I

    move-result p0

    return p0
.end method

.method public b()I
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->b()I

    move-result p0

    return p0
.end method

.method public close()V
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->close()V

    return-void
.end method

.method public d()Landroidx/camera/core/o;
    .locals 1

    iget-object v0, p0, LF/F;->a:LG/F0;

    invoke-interface {v0}, LG/F0;->d()Landroidx/camera/core/o;

    move-result-object v0

    invoke-direct {p0, v0}, LF/F;->l(Landroidx/camera/core/o;)Landroidx/camera/core/o;

    move-result-object p0

    return-object p0
.end method

.method public e()I
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->e()I

    move-result p0

    return p0
.end method

.method public f()V
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->f()V

    return-void
.end method

.method public g(LG/F0$a;Ljava/util/concurrent/Executor;)V
    .locals 2

    iget-object v0, p0, LF/F;->a:LG/F0;

    new-instance v1, LF/E;

    invoke-direct {v1, p0, p1}, LF/E;-><init>(LF/F;LG/F0$a;)V

    invoke-interface {v0, v1, p2}, LG/F0;->g(LG/F0$a;Ljava/util/concurrent/Executor;)V

    return-void
.end method

.method public getSurface()Landroid/view/Surface;
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->getSurface()Landroid/view/Surface;

    move-result-object p0

    return-object p0
.end method

.method public h()I
    .locals 0

    iget-object p0, p0, LF/F;->a:LG/F0;

    invoke-interface {p0}, LG/F0;->h()I

    move-result p0

    return p0
.end method

.method public i()Landroidx/camera/core/o;
    .locals 1

    iget-object v0, p0, LF/F;->a:LG/F0;

    invoke-interface {v0}, LG/F0;->i()Landroidx/camera/core/o;

    move-result-object v0

    invoke-direct {p0, v0}, LF/F;->l(Landroidx/camera/core/o;)Landroidx/camera/core/o;

    move-result-object p0

    return-object p0
.end method

.method j(LF/S;)V
    .locals 2

    iget-object v0, p0, LF/F;->b:LF/S;

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    const-string v1, "Pending request should be null"

    invoke-static {v0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    iput-object p1, p0, LF/F;->b:LF/S;

    return-void
.end method

.method k()V
    .locals 1

    const/4 v0, 0x0

    iput-object v0, p0, LF/F;->b:LF/S;

    return-void
.end method
