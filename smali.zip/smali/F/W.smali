.class public final LF/W;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/camera/core/o;


# instance fields
.field private final f:Ljava/lang/Object;

.field private final g:I

.field private final h:I

.field private final i:Landroid/graphics/Rect;

.field j:[Landroidx/camera/core/o$a;

.field private final k:Lz/Y;


# direct methods
.method public constructor <init>(LQ/z;)V
    .locals 8

    .line 1
    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Landroid/graphics/Bitmap;

    .line 2
    invoke-virtual {p1}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object v3

    .line 3
    invoke-virtual {p1}, LQ/z;->f()I

    move-result v4

    invoke-virtual {p1}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object v5

    .line 4
    invoke-virtual {p1}, LQ/z;->a()LG/B;

    move-result-object p1

    invoke-interface {p1}, LG/B;->a()J

    move-result-wide v6

    move-object v1, p0

    .line 5
    invoke-direct/range {v1 .. v7}, LF/W;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Rect;ILandroid/graphics/Matrix;J)V

    return-void
.end method

.method public constructor <init>(Landroid/graphics/Bitmap;Landroid/graphics/Rect;ILandroid/graphics/Matrix;J)V
    .locals 10

    .line 6
    invoke-static {p1}, LP/b;->e(Landroid/graphics/Bitmap;)Ljava/nio/ByteBuffer;

    move-result-object v1

    .line 7
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    .line 8
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    const/4 v2, 0x4

    move-object v0, p0

    move-object v5, p2

    move v6, p3

    move-object v7, p4

    move-wide v8, p5

    .line 9
    invoke-direct/range {v0 .. v9}, LF/W;-><init>(Ljava/nio/ByteBuffer;IIILandroid/graphics/Rect;ILandroid/graphics/Matrix;J)V

    return-void
.end method

.method public constructor <init>(Ljava/nio/ByteBuffer;IIILandroid/graphics/Rect;ILandroid/graphics/Matrix;J)V
    .locals 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, LF/W;->f:Ljava/lang/Object;

    .line 12
    iput p3, p0, LF/W;->g:I

    .line 13
    iput p4, p0, LF/W;->h:I

    .line 14
    iput-object p5, p0, LF/W;->i:Landroid/graphics/Rect;

    .line 15
    invoke-static {p8, p9, p6, p7}, LF/W;->l(JILandroid/graphics/Matrix;)Lz/Y;

    move-result-object p4

    iput-object p4, p0, LF/W;->k:Lz/Y;

    .line 16
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    mul-int/2addr p3, p2

    .line 17
    invoke-static {p1, p3, p2}, LF/W;->n(Ljava/nio/ByteBuffer;II)Landroidx/camera/core/o$a;

    move-result-object p1

    const/4 p2, 0x1

    new-array p2, p2, [Landroidx/camera/core/o$a;

    const/4 p3, 0x0

    aput-object p1, p2, p3

    iput-object p2, p0, LF/W;->j:[Landroidx/camera/core/o$a;

    return-void
.end method

.method private d()V
    .locals 2

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, LF/W;->j:[Landroidx/camera/core/o$a;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    const-string v1, "The image is closed."

    invoke-static {p0, v1}, LI0/g;->j(ZLjava/lang/String;)V

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method private static l(JILandroid/graphics/Matrix;)Lz/Y;
    .locals 1

    new-instance v0, LF/W$b;

    invoke-direct {v0, p0, p1, p2, p3}, LF/W$b;-><init>(JILandroid/graphics/Matrix;)V

    return-object v0
.end method

.method private static n(Ljava/nio/ByteBuffer;II)Landroidx/camera/core/o$a;
    .locals 1

    new-instance v0, LF/W$a;

    invoke-direct {v0, p1, p2, p0}, LF/W$a;-><init>(IILjava/nio/ByteBuffer;)V

    return-object v0
.end method


# virtual methods
.method public G()[Landroidx/camera/core/o$a;
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    iget-object p0, p0, LF/W;->j:[Landroidx/camera/core/o$a;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p0, [Landroidx/camera/core/o$a;

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public a()I
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    iget p0, p0, LF/W;->h:I

    monitor-exit v0

    return p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public b()I
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    iget p0, p0, LF/W;->g:I

    monitor-exit v0

    return p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public b1(Landroid/graphics/Rect;)V
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    if-eqz p1, :cond_0

    iget-object p0, p0, LF/W;->i:Landroid/graphics/Rect;

    invoke-virtual {p0, p1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    return-void

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public close()V
    .locals 2

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    const/4 v1, 0x0

    iput-object v1, p0, LF/W;->j:[Landroidx/camera/core/o$a;

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public getFormat()I
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    const/4 p0, 0x1

    monitor-exit v0

    return p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public w()Lz/Y;
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    iget-object p0, p0, LF/W;->k:Lz/Y;

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public z1()Landroid/media/Image;
    .locals 1

    iget-object v0, p0, LF/W;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, LF/W;->d()V

    const/4 p0, 0x0

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method
