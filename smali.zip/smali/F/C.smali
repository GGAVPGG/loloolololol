.class public LF/C;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LQ/z;)LQ/z;
    .locals 7

    new-instance p0, Landroidx/camera/core/r;

    invoke-virtual {p1}, LQ/z;->h()Landroid/util/Size;

    move-result-object v0

    invoke-virtual {v0}, Landroid/util/Size;->getWidth()I

    move-result v0

    invoke-virtual {p1}, LQ/z;->h()Landroid/util/Size;

    move-result-object v1

    invoke-virtual {v1}, Landroid/util/Size;->getHeight()I

    move-result v1

    const/16 v2, 0x100

    const/4 v3, 0x2

    invoke-static {v0, v1, v2, v3}, Landroidx/camera/core/p;->a(IIII)LG/F0;

    move-result-object v0

    invoke-direct {p0, v0}, Landroidx/camera/core/r;-><init>(LG/F0;)V

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    invoke-static {p0, v0}, Landroidx/camera/core/ImageProcessingUtil;->e(LG/F0;[B)Landroidx/camera/core/o;

    move-result-object v0

    invoke-virtual {p0}, Landroidx/camera/core/r;->l()V

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Landroidx/camera/core/o;

    invoke-virtual {p1}, LQ/z;->d()LI/g;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object v3

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v4

    invoke-virtual {p1}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object v5

    invoke-virtual {p1}, LQ/z;->a()LG/B;

    move-result-object v6

    invoke-static/range {v1 .. v6}, LQ/z;->j(Landroidx/camera/core/o;LI/g;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LQ/z;

    invoke-virtual {p0, p1}, LF/C;->a(LQ/z;)LQ/z;

    move-result-object p0

    return-object p0
.end method
