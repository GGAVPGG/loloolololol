.class final LF/b;
.super LF/u$c;
.source "SourceFile"


# instance fields
.field private final f:Landroid/util/Size;

.field private final g:I

.field private final h:Ljava/util/List;

.field private final i:Z

.field private final j:LF/G;

.field private final k:LQ/u;

.field private final l:LQ/u;


# direct methods
.method constructor <init>(Landroid/util/Size;ILjava/util/List;ZLz/d0;LF/G;LQ/u;LQ/u;)V
    .locals 0

    invoke-direct {p0}, LF/u$c;-><init>()V

    if-eqz p1, :cond_3

    iput-object p1, p0, LF/b;->f:Landroid/util/Size;

    iput p2, p0, LF/b;->g:I

    if-eqz p3, :cond_2

    iput-object p3, p0, LF/b;->h:Ljava/util/List;

    iput-boolean p4, p0, LF/b;->i:Z

    iput-object p6, p0, LF/b;->j:LF/G;

    if-eqz p7, :cond_1

    iput-object p7, p0, LF/b;->k:LQ/u;

    if-eqz p8, :cond_0

    iput-object p8, p0, LF/b;->l:LQ/u;

    return-void

    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null errorEdge"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null requestEdge"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null outputFormats"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Ljava/lang/NullPointerException;

    const-string p1, "Null size"

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method b()LQ/u;
    .locals 0

    iget-object p0, p0, LF/b;->l:LQ/u;

    return-object p0
.end method

.method c()Lz/d0;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method d()I
    .locals 0

    iget p0, p0, LF/b;->g:I

    return p0
.end method

.method e()Ljava/util/List;
    .locals 0

    iget-object p0, p0, LF/b;->h:Ljava/util/List;

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p1, p0, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LF/u$c;

    const/4 v2, 0x0

    if-eqz v1, :cond_1

    check-cast p1, LF/u$c;

    iget-object v1, p0, LF/b;->f:Landroid/util/Size;

    invoke-virtual {p1}, LF/u$c;->k()Landroid/util/Size;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/util/Size;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget v1, p0, LF/b;->g:I

    invoke-virtual {p1}, LF/u$c;->d()I

    move-result v3

    if-ne v1, v3, :cond_1

    iget-object v1, p0, LF/b;->h:Ljava/util/List;

    invoke-virtual {p1}, LF/u$c;->e()Ljava/util/List;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-boolean v1, p0, LF/b;->i:Z

    invoke-virtual {p1}, LF/u$c;->m()Z

    move-result v3

    if-ne v1, v3, :cond_1

    invoke-virtual {p1}, LF/u$c;->c()Lz/d0;

    invoke-virtual {p1}, LF/u$c;->f()LF/G;

    iget-object v1, p0, LF/b;->k:LQ/u;

    invoke-virtual {p1}, LF/u$c;->h()LQ/u;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object p0, p0, LF/b;->l:LQ/u;

    invoke-virtual {p1}, LF/u$c;->b()LQ/u;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    return v0

    :cond_1
    return v2
.end method

.method f()LF/G;
    .locals 0

    iget-object p0, p0, LF/b;->j:LF/G;

    return-object p0
.end method

.method h()LQ/u;
    .locals 0

    iget-object p0, p0, LF/b;->k:LQ/u;

    return-object p0
.end method

.method public hashCode()I
    .locals 3

    iget-object v0, p0, LF/b;->f:Landroid/util/Size;

    invoke-virtual {v0}, Landroid/util/Size;->hashCode()I

    move-result v0

    const v1, 0xf4243

    xor-int/2addr v0, v1

    mul-int/2addr v0, v1

    iget v2, p0, LF/b;->g:I

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, LF/b;->h:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->hashCode()I

    move-result v2

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-boolean v2, p0, LF/b;->i:Z

    if-eqz v2, :cond_0

    const/16 v2, 0x4cf

    goto :goto_0

    :cond_0
    const/16 v2, 0x4d5

    :goto_0
    xor-int/2addr v0, v2

    const v2, -0x2aff6277

    mul-int/2addr v0, v2

    xor-int/lit8 v0, v0, 0x0

    mul-int/2addr v0, v1

    iget-object v2, p0, LF/b;->k:LQ/u;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    xor-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object p0, p0, LF/b;->l:LQ/u;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method k()Landroid/util/Size;
    .locals 0

    iget-object p0, p0, LF/b;->f:Landroid/util/Size;

    return-object p0
.end method

.method m()Z
    .locals 0

    iget-boolean p0, p0, LF/b;->i:Z

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "In{size="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/b;->f:Landroid/util/Size;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", inputFormat="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, LF/b;->g:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", outputFormats="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/b;->h:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", virtualCamera="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, LF/b;->i:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", imageReaderProxyProvider="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", postviewSettings="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/b;->j:LF/G;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", requestEdge="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, LF/b;->k:LQ/u;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", errorEdge="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, LF/b;->l:LQ/u;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
