.class public final synthetic LF/N;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/S;

.field public final synthetic g:Lz/V$h;


# direct methods
.method public synthetic constructor <init>(LF/S;Lz/V$h;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/N;->f:LF/S;

    iput-object p2, p0, LF/N;->g:Lz/V$h;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/N;->f:LF/S;

    iget-object p0, p0, LF/N;->g:Lz/V$h;

    invoke-static {v0, p0}, LF/Q;->a(LF/S;Lz/V$h;)V

    return-void
.end method
