.class public final synthetic LF/e0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/i0;

.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(LF/i0;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/e0;->f:LF/i0;

    iput p2, p0, LF/e0;->g:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/e0;->f:LF/i0;

    iget p0, p0, LF/e0;->g:I

    invoke-static {v0, p0}, LF/i0;->e(LF/i0;I)V

    return-void
.end method
