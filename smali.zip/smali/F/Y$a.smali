.class public abstract LF/Y$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF/Y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static c(ILz/X;)LF/Y$a;
    .locals 1

    new-instance v0, LF/f;

    invoke-direct {v0, p0, p1}, LF/f;-><init>(ILz/X;)V

    return-object v0
.end method


# virtual methods
.method abstract a()Lz/X;
.end method

.method abstract b()I
.end method
