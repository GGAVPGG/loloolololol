.class LF/W$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/camera/core/o$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LF/W;->n(Ljava/nio/ByteBuffer;II)Landroidx/camera/core/o$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:I

.field final synthetic c:Ljava/nio/ByteBuffer;


# direct methods
.method constructor <init>(IILjava/nio/ByteBuffer;)V
    .locals 0

    iput p1, p0, LF/W$a;->a:I

    iput p2, p0, LF/W$a;->b:I

    iput-object p3, p0, LF/W$a;->c:Ljava/nio/ByteBuffer;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()I
    .locals 0

    iget p0, p0, LF/W$a;->a:I

    return p0
.end method

.method public b()I
    .locals 0

    iget p0, p0, LF/W$a;->b:I

    return p0
.end method

.method public j()Ljava/nio/ByteBuffer;
    .locals 0

    iget-object p0, p0, LF/W$a;->c:Ljava/nio/ByteBuffer;

    return-object p0
.end method
