.class public LF/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LQ/z;)Landroidx/camera/core/o;
    .locals 7

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroidx/camera/core/o;

    invoke-interface {p0}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object v0

    invoke-interface {v0}, Lz/Y;->b()LG/r1;

    move-result-object v1

    invoke-interface {p0}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object v0

    invoke-interface {v0}, Lz/Y;->a()J

    move-result-wide v2

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v4

    invoke-virtual {p1}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object v5

    invoke-interface {p0}, Landroidx/camera/core/o;->w()Lz/Y;

    move-result-object v0

    invoke-interface {v0}, Lz/Y;->c()I

    move-result v6

    invoke-static/range {v1 .. v6}, Lz/e0;->f(LG/r1;JILandroid/graphics/Matrix;I)Lz/Y;

    move-result-object v0

    new-instance v1, Landroidx/camera/core/s;

    invoke-virtual {p1}, LQ/z;->h()Landroid/util/Size;

    move-result-object v2

    invoke-direct {v1, p0, v2, v0}, Landroidx/camera/core/s;-><init>(Landroidx/camera/core/o;Landroid/util/Size;Lz/Y;)V

    invoke-virtual {p1}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object p0

    invoke-interface {v1, p0}, Landroidx/camera/core/o;->b1(Landroid/graphics/Rect;)V

    return-object v1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LQ/z;

    invoke-virtual {p0, p1}, LF/D;->a(LQ/z;)Landroidx/camera/core/o;

    move-result-object p0

    return-object p0
.end method
