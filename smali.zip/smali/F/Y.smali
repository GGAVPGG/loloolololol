.class public interface abstract LF/Y;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/Y$b;,
        LF/Y$a;
    }
.end annotation


# virtual methods
.method public abstract f()V
.end method

.method public abstract g()V
.end method

.method public abstract h()V
.end method

.method public abstract i(LF/i0;)V
.end method

.method public abstract j(LF/z;)V
.end method
