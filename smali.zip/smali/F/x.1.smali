.class final LF/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LQ/y;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF/x$a;
    }
.end annotation


# instance fields
.field private final a:LO/d;


# direct methods
.method constructor <init>(LG/d1;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LO/d;

    invoke-direct {v0, p1}, LO/d;-><init>(LG/d1;)V

    iput-object v0, p0, LF/x;->a:LO/d;

    return-void
.end method

.method private static b([B)LI/g;
    .locals 3

    :try_start_0
    new-instance v0, Ljava/io/ByteArrayInputStream;

    invoke-direct {v0, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-static {v0}, LI/g;->h(Ljava/io/InputStream;)LI/g;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    new-instance v0, Lz/X;

    const/4 v1, 0x0

    const-string v2, "Failed to extract Exif from YUV-generated JPEG"

    invoke-direct {v0, v1, v2, p0}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method private c(LF/x$a;I)LQ/z;
    .locals 9

    invoke-virtual {p1}, LF/x$a;->b()LQ/z;

    move-result-object p1

    iget-object p0, p0, LF/x;->a:LO/d;

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/o;

    invoke-virtual {p0, v0}, LO/d;->a(Landroidx/camera/core/o;)[B

    move-result-object v1

    invoke-virtual {p1}, LQ/z;->d()LI/g;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1}, LQ/z;->h()Landroid/util/Size;

    move-result-object v4

    invoke-virtual {p1}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object v5

    invoke-virtual {p1}, LQ/z;->f()I

    move-result v6

    invoke-virtual {p1}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object v7

    invoke-virtual {p1}, LQ/z;->a()LG/B;

    move-result-object v8

    move v3, p2

    invoke-static/range {v1 .. v8}, LQ/z;->l([BLI/g;ILandroid/util/Size;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0
.end method

.method private d(LF/x$a;)LQ/z;
    .locals 11

    invoke-virtual {p1}, LF/x$a;->b()LQ/z;

    move-result-object p0

    invoke-virtual {p0}, LQ/z;->c()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/camera/core/o;

    invoke-virtual {p0}, LQ/z;->b()Landroid/graphics/Rect;

    move-result-object v1

    :try_start_0
    invoke-virtual {p1}, LF/x$a;->a()I

    move-result p1

    invoke-virtual {p0}, LQ/z;->f()I

    move-result v2

    invoke-static {v0, v1, p1, v2}, LP/b;->m(Landroidx/camera/core/o;Landroid/graphics/Rect;II)[B

    move-result-object v3
    :try_end_0
    .catch LP/b$a; {:try_start_0 .. :try_end_0} :catch_0

    invoke-static {v3}, LF/x;->b([B)LI/g;

    move-result-object v4

    new-instance v6, Landroid/util/Size;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result p1

    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v0

    invoke-direct {v6, p1, v0}, Landroid/util/Size;-><init>(II)V

    new-instance v7, Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result p1

    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v2, 0x0

    invoke-direct {v7, v2, v2, p1, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {p0}, LQ/z;->f()I

    move-result v8

    invoke-virtual {p0}, LQ/z;->g()Landroid/graphics/Matrix;

    move-result-object p1

    invoke-static {p1, v1}, LI/z;->u(Landroid/graphics/Matrix;Landroid/graphics/Rect;)Landroid/graphics/Matrix;

    move-result-object v9

    invoke-virtual {p0}, LQ/z;->a()LG/B;

    move-result-object v10

    const/16 v5, 0x100

    invoke-static/range {v3 .. v10}, LQ/z;->l([BLI/g;ILandroid/util/Size;Landroid/graphics/Rect;ILandroid/graphics/Matrix;LG/B;)LQ/z;

    move-result-object p0

    return-object p0

    :catch_0
    move-exception v0

    move-object p0, v0

    new-instance p1, Lz/X;

    const/4 v0, 0x1

    const-string v1, "Failed to encode the image to JPEG."

    invoke-direct {p1, v0, v1, p0}, Lz/X;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method


# virtual methods
.method public a(LF/x$a;)LQ/z;
    .locals 3

    :try_start_0
    invoke-virtual {p1}, LF/x$a;->b()LQ/z;

    move-result-object v0

    invoke-virtual {v0}, LQ/z;->e()I

    move-result v0

    const/16 v1, 0x23

    if-eq v0, v1, :cond_2

    const/16 v1, 0x100

    if-eq v0, v1, :cond_1

    const/16 v1, 0x1005

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Unexpected format: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_1
    :goto_0
    invoke-direct {p0, p1, v0}, LF/x;->c(LF/x$a;I)LQ/z;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_1
    invoke-virtual {p1}, LF/x$a;->b()LQ/z;

    move-result-object p1

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/core/o;

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    return-object p0

    :cond_2
    :try_start_1
    invoke-direct {p0, p1}, LF/x;->d(LF/x$a;)LQ/z;

    move-result-object p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :goto_2
    invoke-virtual {p1}, LF/x$a;->b()LQ/z;

    move-result-object p1

    invoke-virtual {p1}, LQ/z;->c()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroidx/camera/core/o;

    invoke-interface {p1}, Landroidx/camera/core/o;->close()V

    throw p0
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LF/x$a;

    invoke-virtual {p0, p1}, LF/x;->a(LF/x$a;)LQ/z;

    move-result-object p0

    return-object p0
.end method
