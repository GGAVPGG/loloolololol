.class abstract LF/Q$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF/Q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "b"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static c(LF/S;Landroidx/camera/core/o;)LF/Q$b;
    .locals 1

    new-instance v0, LF/e;

    invoke-direct {v0, p0, p1}, LF/e;-><init>(LF/S;Landroidx/camera/core/o;)V

    return-object v0
.end method


# virtual methods
.method abstract a()Landroidx/camera/core/o;
.end method

.method abstract b()LF/S;
.end method
