.class public final synthetic LF/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/F0$a;


# instance fields
.field public final synthetic a:LF/F;

.field public final synthetic b:LG/F0$a;


# direct methods
.method public synthetic constructor <init>(LF/F;LG/F0$a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/E;->a:LF/F;

    iput-object p2, p0, LF/E;->b:LG/F0$a;

    return-void
.end method


# virtual methods
.method public final a(LG/F0;)V
    .locals 1

    iget-object v0, p0, LF/E;->a:LF/F;

    iget-object p0, p0, LF/E;->b:LG/F0$a;

    invoke-static {v0, p0, p1}, LF/F;->c(LF/F;LG/F0$a;LG/F0;)V

    return-void
.end method
