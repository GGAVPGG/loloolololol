.class public final synthetic LF/O;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/S;

.field public final synthetic g:Landroid/graphics/Bitmap;


# direct methods
.method public synthetic constructor <init>(LF/S;Landroid/graphics/Bitmap;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/O;->f:LF/S;

    iput-object p2, p0, LF/O;->g:Landroid/graphics/Bitmap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, LF/O;->f:LF/S;

    iget-object p0, p0, LF/O;->g:Landroid/graphics/Bitmap;

    invoke-static {v0, p0}, LF/Q;->f(LF/S;Landroid/graphics/Bitmap;)V

    return-void
.end method
