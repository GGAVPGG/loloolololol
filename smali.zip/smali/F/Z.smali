.class public final synthetic LF/Z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF/c0;


# direct methods
.method public synthetic constructor <init>(LF/c0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF/Z;->f:LF/c0;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 0

    iget-object p0, p0, LF/Z;->f:LF/c0;

    invoke-virtual {p0}, LF/c0;->k()V

    return-void
.end method
