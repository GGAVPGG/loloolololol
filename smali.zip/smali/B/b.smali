.class public abstract LB/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LB/b$a;,
        LB/b$b;
    }
.end annotation


# static fields
.field public static final b:LB/b$a;

.field public static final c:LB/b;

.field public static final d:LB/b;

.field public static final e:LB/b;

.field public static final f:LB/b;


# instance fields
.field private final a:Lkotlin/Lazy;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, LB/b$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LB/b$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LB/b;->b:LB/b$a;

    new-instance v0, LD/a;

    sget-object v1, Lz/H;->f:Lz/H;

    const-string v2, "HLG_10_BIT"

    invoke-static {v1, v2}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v1}, LD/a;-><init>(Lz/H;)V

    sput-object v0, LB/b;->c:LB/b;

    new-instance v0, LD/c;

    const/16 v1, 0x3c

    invoke-direct {v0, v1, v1}, LD/c;-><init>(II)V

    sput-object v0, LB/b;->d:LB/b;

    new-instance v0, LD/e;

    sget-object v1, LD/e$b;->h:LD/e$b;

    invoke-direct {v0, v1}, LD/e;-><init>(LD/e$b;)V

    sput-object v0, LB/b;->e:LB/b;

    new-instance v0, LD/d;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, LD/d;-><init>(I)V

    sput-object v0, LB/b;->f:LB/b;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LB/a;

    invoke-direct {v0, p0}, LB/a;-><init>(LB/b;)V

    invoke-static {v0}, Ly9/h;->a(LN9/a;)Lkotlin/Lazy;

    move-result-object v0

    iput-object v0, p0, LB/b;->a:Lkotlin/Lazy;

    return-void
.end method

.method public static synthetic a(LB/b;)I
    .locals 0

    invoke-static {p0}, LB/b;->b(LB/b;)I

    move-result p0

    return p0
.end method

.method private static final b(LB/b;)I
    .locals 1

    invoke-virtual {p0}, LB/b;->c()LD/b;

    move-result-object v0

    invoke-direct {p0, v0}, LB/b;->e(LD/b;)I

    move-result p0

    return p0
.end method

.method private final e(LD/b;)I
    .locals 1

    sget-object p0, LB/b$b;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p0, p0, p1

    const/4 p1, 0x1

    if-eq p0, p1, :cond_3

    const/4 v0, 0x2

    if-eq p0, v0, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 v0, 0x4

    if-ne p0, v0, :cond_0

    return p1

    :cond_0
    new-instance p0, Ly9/l;

    invoke-direct {p0}, Ly9/l;-><init>()V

    throw p0

    :cond_1
    return v0

    :cond_2
    return p1

    :cond_3
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public abstract c()LD/b;
.end method

.method public d(LG/L;Lz/v0;)Z
    .locals 0

    const-string p0, "cameraInfoInternal"

    invoke-static {p1, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "sessionConfig"

    invoke-static {p2, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p0, 0x1

    return p0
.end method
