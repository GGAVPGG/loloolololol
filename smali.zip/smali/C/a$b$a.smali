.class public final LC/a$b$a;
.super LG/q0;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC/a$b;->a(LG/A1;Landroid/util/Size;Lz/H;)LG/h1$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# direct methods
.method constructor <init>(Landroid/util/Size;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, LG/q0;-><init>(Landroid/util/Size;I)V

    return-void
.end method


# virtual methods
.method protected o()LW5/a;
    .locals 1

    const/4 p0, 0x0

    invoke-static {p0}, LK/n;->p(Ljava/lang/Object;)LW5/a;

    move-result-object p0

    const-string v0, "immediateFuture(...)"

    invoke-static {p0, v0}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
