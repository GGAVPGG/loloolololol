.class public final enum LC/c;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC/c$a;,
        LC/c$b;
    }
.end annotation


# static fields
.field public static final h:LC/c$a;

.field public static final enum i:LC/c;

.field public static final enum j:LC/c;

.field public static final enum k:LC/c;

.field public static final enum l:LC/c;

.field public static final enum m:LC/c;

.field private static final synthetic n:[LC/c;

.field private static final synthetic o:Lkotlin/enums/EnumEntries;


# instance fields
.field private final f:Ljava/lang/Class;

.field private final g:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    new-instance v0, LC/c;

    const-string v1, "PREVIEW"

    const/4 v2, 0x0

    const-class v3, Landroid/view/SurfaceHolder;

    const/16 v4, 0x22

    invoke-direct {v0, v1, v2, v3, v4}, LC/c;-><init>(Ljava/lang/String;ILjava/lang/Class;I)V

    sput-object v0, LC/c;->i:LC/c;

    new-instance v0, LC/c;

    const/16 v1, 0x100

    const-string v2, "IMAGE_CAPTURE"

    const/4 v3, 0x1

    const/4 v5, 0x0

    invoke-direct {v0, v2, v3, v5, v1}, LC/c;-><init>(Ljava/lang/String;ILjava/lang/Class;I)V

    sput-object v0, LC/c;->j:LC/c;

    new-instance v0, LC/c;

    const/4 v1, 0x2

    const-class v2, Landroid/media/MediaCodec;

    const-string v3, "VIDEO_CAPTURE"

    invoke-direct {v0, v3, v1, v2, v4}, LC/c;-><init>(Ljava/lang/String;ILjava/lang/Class;I)V

    sput-object v0, LC/c;->k:LC/c;

    new-instance v0, LC/c;

    const/4 v1, 0x3

    const-class v2, Landroid/graphics/SurfaceTexture;

    const-string v3, "STREAM_SHARING"

    invoke-direct {v0, v3, v1, v2, v4}, LC/c;-><init>(Ljava/lang/String;ILjava/lang/Class;I)V

    sput-object v0, LC/c;->l:LC/c;

    new-instance v0, LC/c;

    const-string v1, "UNDEFINED"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2, v5, v4}, LC/c;-><init>(Ljava/lang/String;ILjava/lang/Class;I)V

    sput-object v0, LC/c;->m:LC/c;

    invoke-static {}, LC/c;->c()[LC/c;

    move-result-object v0

    sput-object v0, LC/c;->n:[LC/c;

    invoke-static {v0}, LG9/a;->a([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, LC/c;->o:Lkotlin/enums/EnumEntries;

    new-instance v0, LC/c$a;

    invoke-direct {v0, v5}, LC/c$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LC/c;->h:LC/c$a;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/Class;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, LC/c;->f:Ljava/lang/Class;

    iput p4, p0, LC/c;->g:I

    return-void
.end method

.method private static final synthetic c()[LC/c;
    .locals 5

    sget-object v0, LC/c;->i:LC/c;

    sget-object v1, LC/c;->j:LC/c;

    sget-object v2, LC/c;->k:LC/c;

    sget-object v3, LC/c;->l:LC/c;

    sget-object v4, LC/c;->m:LC/c;

    filled-new-array {v0, v1, v2, v3, v4}, [LC/c;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LC/c;
    .locals 1

    const-class v0, LC/c;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LC/c;

    return-object p0
.end method

.method public static values()[LC/c;
    .locals 1

    sget-object v0, LC/c;->n:[LC/c;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LC/c;

    return-object v0
.end method


# virtual methods
.method public final d()Ljava/lang/Class;
    .locals 0

    iget-object p0, p0, LC/c;->f:Ljava/lang/Class;

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 1

    sget-object v0, LC/c$b;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_4

    const/4 v0, 0x2

    if-eq p0, v0, :cond_3

    const/4 v0, 0x3

    if-eq p0, v0, :cond_2

    const/4 v0, 0x4

    if-eq p0, v0, :cond_1

    const/4 v0, 0x5

    if-ne p0, v0, :cond_0

    const-string p0, "Undefined"

    return-object p0

    :cond_0
    new-instance p0, Ly9/l;

    invoke-direct {p0}, Ly9/l;-><init>()V

    throw p0

    :cond_1
    const-string p0, "StreamSharing"

    return-object p0

    :cond_2
    const-string p0, "VideoCapture"

    return-object p0

    :cond_3
    const-string p0, "ImageCapture"

    return-object p0

    :cond_4
    const-string p0, "Preview"

    return-object p0
.end method
