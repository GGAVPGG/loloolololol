.class public final LC/c$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC/c$a$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LC/c$a;-><init>()V

    return-void
.end method

.method private final d(LD/b;Lz/J0;)Z
    .locals 1

    sget-object v0, LC/c$a$a;->b:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_3

    const/4 v0, 0x2

    if-eq p1, v0, :cond_2

    const/4 v0, 0x3

    if-eq p1, v0, :cond_1

    const/4 v0, 0x4

    if-ne p1, v0, :cond_0

    invoke-direct {p0, p2}, LC/c$a;->g(Lz/J0;)Z

    move-result p0

    return p0

    :cond_0
    new-instance p0, Ly9/l;

    invoke-direct {p0}, Ly9/l;-><init>()V

    throw p0

    :cond_1
    invoke-direct {p0, p2}, LC/c$a;->h(Lz/J0;)Z

    move-result p0

    return p0

    :cond_2
    invoke-direct {p0, p2}, LC/c$a;->f(Lz/J0;)Z

    move-result p0

    return p0

    :cond_3
    invoke-direct {p0, p2}, LC/c$a;->e(Lz/J0;)Z

    move-result p0

    return p0
.end method

.method private final e(Lz/J0;)Z
    .locals 0

    invoke-virtual {p1}, Lz/J0;->e()LG/A1;

    move-result-object p0

    invoke-interface {p0}, LG/D0;->w()Z

    move-result p0

    return p0
.end method

.method private final f(Lz/J0;)Z
    .locals 0

    invoke-virtual {p1}, Lz/J0;->e()LG/A1;

    move-result-object p0

    invoke-interface {p0}, LG/A1;->b0()Z

    move-result p0

    return p0
.end method

.method private final g(Lz/J0;)Z
    .locals 0

    invoke-virtual {p1}, Lz/J0;->e()LG/A1;

    move-result-object p0

    sget-object p1, LG/C0;->U:LG/j0$a;

    invoke-interface {p0, p1}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    return p0
.end method

.method private final h(Lz/J0;)Z
    .locals 1

    invoke-virtual {p1}, Lz/J0;->e()LG/A1;

    move-result-object p0

    sget-object v0, LG/A1;->H:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    if-nez p0, :cond_1

    invoke-virtual {p1}, Lz/J0;->e()LG/A1;

    move-result-object p0

    sget-object p1, LG/A1;->I:LG/j0$a;

    invoke-interface {p0, p1}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x1

    return p0
.end method


# virtual methods
.method public final a(Lz/J0;)LD/b;
    .locals 3

    const-string p0, "<this>"

    invoke-static {p1, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {}, LD/b;->d()Lkotlin/enums/EnumEntries;

    move-result-object p0

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, LD/b;

    sget-object v2, LC/c;->h:LC/c$a;

    invoke-direct {v2, v1, p1}, LC/c$a;->d(LD/b;Lz/J0;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    check-cast v0, LD/b;

    return-object v0
.end method

.method public final b(LG/A1;)LC/c;
    .locals 0

    const-string p0, "<this>"

    invoke-static {p1, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, LG/A1;->J()LG/B1$b;

    move-result-object p0

    sget-object p1, LC/c$a$a;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, p1, p0

    const/4 p1, 0x1

    if-eq p0, p1, :cond_3

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    sget-object p0, LC/c;->m:LC/c;

    return-object p0

    :cond_0
    sget-object p0, LC/c;->l:LC/c;

    return-object p0

    :cond_1
    sget-object p0, LC/c;->k:LC/c;

    return-object p0

    :cond_2
    sget-object p0, LC/c;->i:LC/c;

    return-object p0

    :cond_3
    sget-object p0, LC/c;->j:LC/c;

    return-object p0
.end method

.method public final c(Lz/J0;)LC/c;
    .locals 0

    const-string p0, "<this>"

    invoke-static {p1, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    instance-of p0, p1, Lz/p0;

    if-eqz p0, :cond_0

    sget-object p0, LC/c;->i:LC/c;

    return-object p0

    :cond_0
    instance-of p0, p1, Lz/V;

    if-eqz p0, :cond_1

    sget-object p0, LC/c;->j:LC/c;

    return-object p0

    :cond_1
    invoke-static {p1}, LL/f;->e0(Lz/J0;)Z

    move-result p0

    if-eqz p0, :cond_2

    sget-object p0, LC/c;->k:LC/c;

    return-object p0

    :cond_2
    instance-of p0, p1, LU/g;

    if-eqz p0, :cond_3

    sget-object p0, LC/c;->l:LC/c;

    return-object p0

    :cond_3
    sget-object p0, LC/c;->m:LC/c;

    return-object p0
.end method
