.class public final LC/a$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field static final synthetic a:LC/a$b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LC/a$b;

    invoke-direct {v0}, LC/a$b;-><init>()V

    sput-object v0, LC/a$b;->a:LC/a$b;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(LG/A1;Landroid/util/Size;Lz/H;)LG/h1$b;
    .locals 1

    const-string p0, "<this>"

    invoke-static {p1, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "resolution"

    invoke-static {p2, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p0, "dynamicRange"

    invoke-static {p3, p0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1}, LG/D0;->t()I

    move-result p0

    new-instance v0, LC/a$b$a;

    invoke-direct {v0, p2, p0}, LC/a$b$a;-><init>(Landroid/util/Size;I)V

    sget-object p0, LC/c;->h:LC/c$a;

    invoke-virtual {p0, p1}, LC/c$a;->b(LG/A1;)LC/c;

    move-result-object p0

    invoke-virtual {p0}, LC/c;->d()Ljava/lang/Class;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {v0, p0}, LG/q0;->p(Ljava/lang/Class;)V

    :cond_0
    invoke-static {p1, p2}, LG/h1$b;->r(LG/A1;Landroid/util/Size;)LG/h1$b;

    move-result-object p0

    invoke-virtual {p0, v0, p3}, LG/h1$b;->m(LG/q0;Lz/H;)LG/h1$b;

    move-result-object p0

    const-string p1, "addSurface(...)"

    invoke-static {p0, p1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p0
.end method
