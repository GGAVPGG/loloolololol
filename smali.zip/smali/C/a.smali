.class public interface abstract LC/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC/a$b;
    }
.end annotation


# static fields
.field public static final a:LC/a$b;

.field public static final b:LC/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, LC/a$b;->a:LC/a$b;

    sput-object v0, LC/a;->a:LC/a$b;

    new-instance v0, LC/a$a;

    invoke-direct {v0}, LC/a$a;-><init>()V

    sput-object v0, LC/a;->b:LC/a;

    return-void
.end method

.method public static b(LG/A1;Landroid/util/Size;Lz/H;)LG/h1$b;
    .locals 1

    sget-object v0, LC/a;->a:LC/a$b;

    invoke-virtual {v0, p0, p1, p2}, LC/a$b;->a(LG/A1;Landroid/util/Size;Lz/H;)LG/h1$b;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public abstract a(LG/h1;)Z
.end method
