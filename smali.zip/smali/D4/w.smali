.class public final LD4/w;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly4/b;


# instance fields
.field private final a:Ljavax/inject/Provider;

.field private final b:Ljavax/inject/Provider;

.field private final c:Ljavax/inject/Provider;

.field private final d:Ljavax/inject/Provider;


# direct methods
.method public constructor <init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/w;->a:Ljavax/inject/Provider;

    iput-object p2, p0, LD4/w;->b:Ljavax/inject/Provider;

    iput-object p3, p0, LD4/w;->c:Ljavax/inject/Provider;

    iput-object p4, p0, LD4/w;->d:Ljavax/inject/Provider;

    return-void
.end method

.method public static a(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)LD4/w;
    .locals 1

    new-instance v0, LD4/w;

    invoke-direct {v0, p0, p1, p2, p3}, LD4/w;-><init>(Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;Ljavax/inject/Provider;)V

    return-object v0
.end method

.method public static c(Ljava/util/concurrent/Executor;LE4/d;LD4/x;LF4/b;)LD4/v;
    .locals 1

    new-instance v0, LD4/v;

    invoke-direct {v0, p0, p1, p2, p3}, LD4/v;-><init>(Ljava/util/concurrent/Executor;LE4/d;LD4/x;LF4/b;)V

    return-object v0
.end method


# virtual methods
.method public b()LD4/v;
    .locals 3

    iget-object v0, p0, LD4/w;->a:Ljavax/inject/Provider;

    invoke-interface {v0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Executor;

    iget-object v1, p0, LD4/w;->b:Ljavax/inject/Provider;

    invoke-interface {v1}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LE4/d;

    iget-object v2, p0, LD4/w;->c:Ljavax/inject/Provider;

    invoke-interface {v2}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD4/x;

    iget-object p0, p0, LD4/w;->d:Ljavax/inject/Provider;

    invoke-interface {p0}, Ljavax/inject/Provider;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LF4/b;

    invoke-static {v0, v1, v2, p0}, LD4/w;->c(Ljava/util/concurrent/Executor;LE4/d;LD4/x;LF4/b;)LD4/v;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic get()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, LD4/w;->b()LD4/v;

    move-result-object p0

    return-object p0
.end method
