.class public LD4/v;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/util/concurrent/Executor;

.field private final b:LE4/d;

.field private final c:LD4/x;

.field private final d:LF4/b;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Executor;LE4/d;LD4/x;LF4/b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/v;->a:Ljava/util/concurrent/Executor;

    iput-object p2, p0, LD4/v;->b:LE4/d;

    iput-object p3, p0, LD4/v;->c:LD4/x;

    iput-object p4, p0, LD4/v;->d:LF4/b;

    return-void
.end method

.method public static synthetic a(LD4/v;)Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, LD4/v;->b:LE4/d;

    invoke-interface {v0}, LE4/d;->l0()Ljava/lang/Iterable;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lw4/o;

    iget-object v2, p0, LD4/v;->c:LD4/x;

    const/4 v3, 0x1

    invoke-interface {v2, v1, v3}, LD4/x;->b(Lw4/o;I)V

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic b(LD4/v;)V
    .locals 2

    iget-object v0, p0, LD4/v;->d:LF4/b;

    new-instance v1, LD4/u;

    invoke-direct {v1, p0}, LD4/u;-><init>(LD4/v;)V

    invoke-interface {v0, v1}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public c()V
    .locals 2

    iget-object v0, p0, LD4/v;->a:Ljava/util/concurrent/Executor;

    new-instance v1, LD4/t;

    invoke-direct {v1, p0}, LD4/t;-><init>(LD4/v;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
