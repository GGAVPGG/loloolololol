.class public final synthetic LD4/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LD4/r;

.field public final synthetic b:Lw4/o;

.field public final synthetic c:J


# direct methods
.method public synthetic constructor <init>(LD4/r;Lw4/o;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/q;->a:LD4/r;

    iput-object p2, p0, LD4/q;->b:Lw4/o;

    iput-wide p3, p0, LD4/q;->c:J

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 4

    iget-object v0, p0, LD4/q;->a:LD4/r;

    iget-object v1, p0, LD4/q;->b:Lw4/o;

    iget-wide v2, p0, LD4/q;->c:J

    invoke-static {v0, v1, v2, v3}, LD4/r;->g(LD4/r;Lw4/o;J)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
