.class public final synthetic LD4/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LD4/r;

.field public final synthetic g:Lw4/o;

.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(LD4/r;Lw4/o;ILjava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/g;->f:LD4/r;

    iput-object p2, p0, LD4/g;->g:Lw4/o;

    iput p3, p0, LD4/g;->h:I

    iput-object p4, p0, LD4/g;->i:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, LD4/g;->f:LD4/r;

    iget-object v1, p0, LD4/g;->g:Lw4/o;

    iget v2, p0, LD4/g;->h:I

    iget-object p0, p0, LD4/g;->i:Ljava/lang/Runnable;

    invoke-static {v0, v1, v2, p0}, LD4/r;->i(LD4/r;Lw4/o;ILjava/lang/Runnable;)V

    return-void
.end method
