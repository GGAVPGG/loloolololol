.class public final synthetic LD4/o;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LD4/r;


# direct methods
.method public synthetic constructor <init>(LD4/r;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/o;->a:LD4/r;

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/o;->a:LD4/r;

    invoke-static {p0}, LD4/r;->c(LD4/r;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
