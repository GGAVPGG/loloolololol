.class public final synthetic LD4/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LE4/d;


# direct methods
.method public synthetic constructor <init>(LE4/d;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/i;->a:LE4/d;

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/i;->a:LE4/d;

    invoke-interface {p0}, LE4/d;->o()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0
.end method
