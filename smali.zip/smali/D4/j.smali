.class public final synthetic LD4/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LD4/r;

.field public final synthetic b:Lw4/o;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(LD4/r;Lw4/o;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/j;->a:LD4/r;

    iput-object p2, p0, LD4/j;->b:Lw4/o;

    iput p3, p0, LD4/j;->c:I

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LD4/j;->a:LD4/r;

    iget-object v1, p0, LD4/j;->b:Lw4/o;

    iget p0, p0, LD4/j;->c:I

    invoke-static {v0, v1, p0}, LD4/r;->f(LD4/r;Lw4/o;I)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
