.class public interface abstract LD4/x;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lw4/o;IZ)V
.end method

.method public abstract b(Lw4/o;I)V
.end method
