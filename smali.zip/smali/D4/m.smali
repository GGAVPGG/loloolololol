.class public final synthetic LD4/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LD4/r;

.field public final synthetic b:Ljava/lang/Iterable;

.field public final synthetic c:Lw4/o;

.field public final synthetic d:J


# direct methods
.method public synthetic constructor <init>(LD4/r;Ljava/lang/Iterable;Lw4/o;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/m;->a:LD4/r;

    iput-object p2, p0, LD4/m;->b:Ljava/lang/Iterable;

    iput-object p3, p0, LD4/m;->c:Lw4/o;

    iput-wide p4, p0, LD4/m;->d:J

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 5

    iget-object v0, p0, LD4/m;->a:LD4/r;

    iget-object v1, p0, LD4/m;->b:Ljava/lang/Iterable;

    iget-object v2, p0, LD4/m;->c:Lw4/o;

    iget-wide v3, p0, LD4/m;->d:J

    invoke-static {v0, v1, v2, v3, v4}, LD4/r;->b(LD4/r;Ljava/lang/Iterable;Lw4/o;J)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
