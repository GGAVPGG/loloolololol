.class public final synthetic LD4/u;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LD4/v;


# direct methods
.method public synthetic constructor <init>(LD4/v;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/u;->a:LD4/v;

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/u;->a:LD4/v;

    invoke-static {p0}, LD4/v;->a(LD4/v;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
