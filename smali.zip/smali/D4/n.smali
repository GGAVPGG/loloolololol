.class public final synthetic LD4/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LD4/r;

.field public final synthetic b:Ljava/lang/Iterable;


# direct methods
.method public synthetic constructor <init>(LD4/r;Ljava/lang/Iterable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/n;->a:LD4/r;

    iput-object p2, p0, LD4/n;->b:Ljava/lang/Iterable;

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, LD4/n;->a:LD4/r;

    iget-object p0, p0, LD4/n;->b:Ljava/lang/Iterable;

    invoke-static {v0, p0}, LD4/r;->e(LD4/r;Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
