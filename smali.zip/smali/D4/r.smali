.class public LD4/r;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lx4/e;

.field private final c:LE4/d;

.field private final d:LD4/x;

.field private final e:Ljava/util/concurrent/Executor;

.field private final f:LF4/b;

.field private final g:LG4/a;

.field private final h:LG4/a;

.field private final i:LE4/c;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lx4/e;LE4/d;LD4/x;Ljava/util/concurrent/Executor;LF4/b;LG4/a;LG4/a;LE4/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/r;->a:Landroid/content/Context;

    iput-object p2, p0, LD4/r;->b:Lx4/e;

    iput-object p3, p0, LD4/r;->c:LE4/d;

    iput-object p4, p0, LD4/r;->d:LD4/x;

    iput-object p5, p0, LD4/r;->e:Ljava/util/concurrent/Executor;

    iput-object p6, p0, LD4/r;->f:LF4/b;

    iput-object p7, p0, LD4/r;->g:LG4/a;

    iput-object p8, p0, LD4/r;->h:LG4/a;

    iput-object p9, p0, LD4/r;->i:LE4/c;

    return-void
.end method

.method public static synthetic a(LD4/r;Lw4/o;)Ljava/lang/Iterable;
    .locals 0

    iget-object p0, p0, LD4/r;->c:LE4/d;

    invoke-interface {p0, p1}, LE4/d;->e1(Lw4/o;)Ljava/lang/Iterable;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic b(LD4/r;Ljava/lang/Iterable;Lw4/o;J)Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LD4/r;->c:LE4/d;

    invoke-interface {v0, p1}, LE4/d;->R1(Ljava/lang/Iterable;)V

    iget-object p1, p0, LD4/r;->c:LE4/d;

    iget-object p0, p0, LD4/r;->g:LG4/a;

    invoke-interface {p0}, LG4/a;->a()J

    move-result-wide v0

    add-long/2addr v0, p3

    invoke-interface {p1, p2, v0, v1}, LE4/d;->O1(Lw4/o;J)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic c(LD4/r;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/r;->i:LE4/c;

    invoke-interface {p0}, LE4/c;->n()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic d(LD4/r;Lw4/o;)Ljava/lang/Boolean;
    .locals 0

    iget-object p0, p0, LD4/r;->c:LE4/d;

    invoke-interface {p0, p1}, LE4/d;->J(Lw4/o;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic e(LD4/r;Ljava/lang/Iterable;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/r;->c:LE4/d;

    invoke-interface {p0, p1}, LE4/d;->I(Ljava/lang/Iterable;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic f(LD4/r;Lw4/o;I)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/r;->d:LD4/x;

    add-int/lit8 p2, p2, 0x1

    invoke-interface {p0, p1, p2}, LD4/x;->b(Lw4/o;I)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic g(LD4/r;Lw4/o;J)Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, LD4/r;->c:LE4/d;

    iget-object p0, p0, LD4/r;->g:LG4/a;

    invoke-interface {p0}, LG4/a;->a()J

    move-result-wide v1

    add-long/2addr v1, p2

    invoke-interface {v0, p1, v1, v2}, LE4/d;->O1(Lw4/o;J)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic h(LD4/r;Ljava/util/Map;)Ljava/lang/Object;
    .locals 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    iget-object v1, p0, LD4/r;->i:LE4/c;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    int-to-long v2, v2

    sget-object v4, Lz4/c$b;->l:Lz4/c$b;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-interface {v1, v2, v3, v4, v0}, LE4/c;->l(JLz4/c$b;Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic i(LD4/r;Lw4/o;ILjava/lang/Runnable;)V
    .locals 3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v0, p0, LD4/r;->f:LF4/b;

    iget-object v1, p0, LD4/r;->c:LE4/d;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, LD4/i;

    invoke-direct {v2, v1}, LD4/i;-><init>(LE4/d;)V

    invoke-interface {v0, v2}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    invoke-virtual {p0}, LD4/r;->k()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, LD4/r;->f:LF4/b;

    new-instance v1, LD4/j;

    invoke-direct {v1, p0, p1, p2}, LD4/j;-><init>(LD4/r;Lw4/o;I)V

    invoke-interface {v0, v1}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    invoke-virtual {p0, p1, p2}, LD4/r;->l(Lw4/o;I)Lx4/g;
    :try_end_0
    .catch LF4/a; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    invoke-interface {p3}, Ljava/lang/Runnable;->run()V

    return-void

    :catch_0
    :try_start_1
    iget-object p0, p0, LD4/r;->d:LD4/x;

    add-int/lit8 p2, p2, 0x1

    invoke-interface {p0, p1, p2}, LD4/x;->b(Lw4/o;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-interface {p3}, Ljava/lang/Runnable;->run()V

    return-void

    :goto_1
    invoke-interface {p3}, Ljava/lang/Runnable;->run()V

    throw p0
.end method


# virtual methods
.method public j(Lx4/m;)Lw4/i;
    .locals 4

    iget-object v0, p0, LD4/r;->f:LF4/b;

    iget-object v1, p0, LD4/r;->i:LE4/c;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, LD4/h;

    invoke-direct {v2, v1}, LD4/h;-><init>(LE4/c;)V

    invoke-interface {v0, v2}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lz4/a;

    invoke-static {}, Lw4/i;->a()Lw4/i$a;

    move-result-object v1

    iget-object v2, p0, LD4/r;->g:LG4/a;

    invoke-interface {v2}, LG4/a;->a()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lw4/i$a;->i(J)Lw4/i$a;

    move-result-object v1

    iget-object p0, p0, LD4/r;->h:LG4/a;

    invoke-interface {p0}, LG4/a;->a()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lw4/i$a;->k(J)Lw4/i$a;

    move-result-object p0

    const-string v1, "GDT_CLIENT_METRICS"

    invoke-virtual {p0, v1}, Lw4/i$a;->j(Ljava/lang/String;)Lw4/i$a;

    move-result-object p0

    new-instance v1, Lw4/h;

    const-string v2, "proto"

    invoke-static {v2}, Lu4/c;->b(Ljava/lang/String;)Lu4/c;

    move-result-object v2

    invoke-virtual {v0}, Lz4/a;->f()[B

    move-result-object v0

    invoke-direct {v1, v2, v0}, Lw4/h;-><init>(Lu4/c;[B)V

    invoke-virtual {p0, v1}, Lw4/i$a;->h(Lw4/h;)Lw4/i$a;

    move-result-object p0

    invoke-virtual {p0}, Lw4/i$a;->d()Lw4/i;

    move-result-object p0

    invoke-interface {p1, p0}, Lx4/m;->a(Lw4/i;)Lw4/i;

    move-result-object p0

    return-object p0
.end method

.method k()Z
    .locals 1

    iget-object p0, p0, LD4/r;->a:Landroid/content/Context;

    const-string v0, "connectivity"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/ConnectivityManager;

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public l(Lw4/o;I)Lx4/g;
    .locals 11

    iget-object v0, p0, LD4/r;->b:Lx4/e;

    invoke-virtual {p1}, Lw4/o;->b()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lx4/e;->b(Ljava/lang/String;)Lx4/m;

    move-result-object v0

    const-wide/16 v1, 0x0

    invoke-static {v1, v2}, Lx4/g;->e(J)Lx4/g;

    move-result-object v3

    move-wide v8, v1

    :goto_0
    iget-object v1, p0, LD4/r;->f:LF4/b;

    new-instance v2, LD4/k;

    invoke-direct {v2, p0, p1}, LD4/k;-><init>(LD4/r;Lw4/o;)V

    invoke-interface {v1, v2}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_a

    iget-object v1, p0, LD4/r;->f:LF4/b;

    new-instance v2, LD4/l;

    invoke-direct {v2, p0, p1}, LD4/l;-><init>(LD4/r;Lw4/o;)V

    invoke-interface {v1, v2}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    move-result-object v1

    move-object v6, v1

    check-cast v6, Ljava/lang/Iterable;

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_0

    return-object v3

    :cond_0
    if-nez v0, :cond_1

    const-string v1, "Uploader"

    const-string v2, "Unknown backend for %s, deleting event batch for it..."

    invoke-static {v1, v2, p1}, LA4/a;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    invoke-static {}, Lx4/g;->a()Lx4/g;

    move-result-object v1

    :goto_1
    move-object v3, v1

    goto :goto_3

    :cond_1
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LE4/k;

    invoke-virtual {v3}, LE4/k;->b()Lw4/i;

    move-result-object v3

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, Lw4/o;->e()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual {p0, v0}, LD4/r;->j(Lx4/m;)Lw4/i;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    invoke-static {}, Lx4/f;->a()Lx4/f$a;

    move-result-object v2

    invoke-virtual {v2, v1}, Lx4/f$a;->b(Ljava/lang/Iterable;)Lx4/f$a;

    move-result-object v1

    invoke-virtual {p1}, Lw4/o;->c()[B

    move-result-object v2

    invoke-virtual {v1, v2}, Lx4/f$a;->c([B)Lx4/f$a;

    move-result-object v1

    invoke-virtual {v1}, Lx4/f$a;->a()Lx4/f;

    move-result-object v1

    invoke-interface {v0, v1}, Lx4/m;->b(Lx4/f;)Lx4/g;

    move-result-object v1

    goto :goto_1

    :goto_3
    invoke-virtual {v3}, Lx4/g;->c()Lx4/g$a;

    move-result-object v1

    sget-object v2, Lx4/g$a;->g:Lx4/g$a;

    const/4 v10, 0x1

    if-ne v1, v2, :cond_4

    iget-object v0, p0, LD4/r;->f:LF4/b;

    new-instance v4, LD4/m;

    move-object v5, p0

    move-object v7, p1

    invoke-direct/range {v4 .. v9}, LD4/m;-><init>(LD4/r;Ljava/lang/Iterable;Lw4/o;J)V

    invoke-interface {v0, v4}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    iget-object p0, v5, LD4/r;->d:LD4/x;

    add-int/2addr p2, v10

    invoke-interface {p0, v7, p2, v10}, LD4/x;->a(Lw4/o;IZ)V

    return-object v3

    :cond_4
    move-object v5, p0

    move-object v7, p1

    iget-object p0, v5, LD4/r;->f:LF4/b;

    new-instance p1, LD4/n;

    invoke-direct {p1, v5, v6}, LD4/n;-><init>(LD4/r;Ljava/lang/Iterable;)V

    invoke-interface {p0, p1}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    invoke-virtual {v3}, Lx4/g;->c()Lx4/g$a;

    move-result-object p0

    sget-object p1, Lx4/g$a;->f:Lx4/g$a;

    if-ne p0, p1, :cond_6

    invoke-virtual {v3}, Lx4/g;->b()J

    move-result-wide p0

    invoke-static {v8, v9, p0, p1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p0

    invoke-virtual {v7}, Lw4/o;->e()Z

    move-result v1

    if-eqz v1, :cond_5

    iget-object v1, v5, LD4/r;->f:LF4/b;

    new-instance v2, LD4/o;

    invoke-direct {v2, v5}, LD4/o;-><init>(LD4/r;)V

    invoke-interface {v1, v2}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    :cond_5
    move-wide v8, p0

    goto :goto_5

    :cond_6
    invoke-virtual {v3}, Lx4/g;->c()Lx4/g$a;

    move-result-object p0

    sget-object p1, Lx4/g$a;->i:Lx4/g$a;

    if-ne p0, p1, :cond_9

    new-instance p0, Ljava/util/HashMap;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LE4/k;

    invoke-virtual {v1}, LE4/k;->b()Lw4/i;

    move-result-object v1

    invoke-virtual {v1}, Lw4/i;->j()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_7

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_7
    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    add-int/2addr v2, v10

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_8
    iget-object p1, v5, LD4/r;->f:LF4/b;

    new-instance v1, LD4/p;

    invoke-direct {v1, v5, p0}, LD4/p;-><init>(LD4/r;Ljava/util/Map;)V

    invoke-interface {p1, v1}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    :cond_9
    :goto_5
    move-object p0, v5

    move-object p1, v7

    goto/16 :goto_0

    :cond_a
    move-object v5, p0

    move-object v7, p1

    iget-object p0, v5, LD4/r;->f:LF4/b;

    new-instance p1, LD4/q;

    invoke-direct {p1, v5, v7, v8, v9}, LD4/q;-><init>(LD4/r;Lw4/o;J)V

    invoke-interface {p0, p1}, LF4/b;->d(LF4/b$a;)Ljava/lang/Object;

    return-object v3
.end method

.method public m(Lw4/o;ILjava/lang/Runnable;)V
    .locals 2

    iget-object v0, p0, LD4/r;->e:Ljava/util/concurrent/Executor;

    new-instance v1, LD4/g;

    invoke-direct {v1, p0, p1, p2, p3}, LD4/g;-><init>(LD4/r;Lw4/o;ILjava/lang/Runnable;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
