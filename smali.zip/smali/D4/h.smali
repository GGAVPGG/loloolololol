.class public final synthetic LD4/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF4/b$a;


# instance fields
.field public final synthetic a:LE4/c;


# direct methods
.method public synthetic constructor <init>(LE4/c;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD4/h;->a:LE4/c;

    return-void
.end method


# virtual methods
.method public final n()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD4/h;->a:LE4/c;

    invoke-interface {p0}, LE4/c;->t()Lz4/a;

    move-result-object p0

    return-object p0
.end method
