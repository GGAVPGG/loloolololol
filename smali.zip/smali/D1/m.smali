.class public final LD1/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly1/i;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD1/m$a;
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:LH1/n;

.field private final c:Lkotlin/Lazy;

.field private final d:Lkotlin/Lazy;

.field private final e:Lkotlin/Lazy;

.field private final f:LD1/d;


# direct methods
.method public constructor <init>(Ljava/lang/String;LH1/n;Lkotlin/Lazy;Lkotlin/Lazy;Lkotlin/Lazy;LD1/d;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD1/m;->a:Ljava/lang/String;

    iput-object p2, p0, LD1/m;->b:LH1/n;

    iput-object p3, p0, LD1/m;->c:Lkotlin/Lazy;

    iput-object p4, p0, LD1/m;->d:Lkotlin/Lazy;

    iput-object p5, p0, LD1/m;->e:Lkotlin/Lazy;

    iput-object p6, p0, LD1/m;->f:LD1/d;

    return-void
.end method

.method public static final synthetic b(LD1/m;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LD1/m;->a:Ljava/lang/String;

    return-object p0
.end method

.method public static final synthetic c(LD1/m;LD1/r;LD9/e;)Ljava/lang/Object;
    .locals 0

    invoke-direct {p0, p1, p2}, LD1/m;->n(LD1/r;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic d(LD1/m;LNb/h;)Lw1/s;
    .locals 0

    invoke-direct {p0, p1}, LD1/m;->o(LNb/h;)Lw1/s;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic e(LD1/m;Lx1/a$c;)Lw1/s;
    .locals 0

    invoke-direct {p0, p1}, LD1/m;->p(Lx1/a$c;)Lw1/s;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic f(LD1/m;Lx1/a$c;)LD1/q;
    .locals 0

    invoke-direct {p0, p1}, LD1/m;->q(Lx1/a$c;)LD1/q;

    move-result-object p0

    return-object p0
.end method

.method public static final synthetic g(LD1/m;Lx1/a$c;LD1/q;LD1/o;LD1/q;LD9/e;)Ljava/lang/Object;
    .locals 0

    invoke-direct/range {p0 .. p5}, LD1/m;->r(Lx1/a$c;LD1/q;LD1/o;LD1/q;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method private final h(LD1/o;Lkotlin/jvm/functions/Function2;LD9/e;)Ljava/lang/Object;
    .locals 2

    iget-object v0, p0, LD1/m;->b:LH1/n;

    invoke-virtual {v0}, LH1/n;->h()LH1/c;

    move-result-object v0

    invoke-virtual {v0}, LH1/c;->d()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, LE1/f;->a()V

    :cond_0
    iget-object p0, p0, LD1/m;->c:Lkotlin/Lazy;

    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LD1/i;

    new-instance v0, LD1/m$b;

    const/4 v1, 0x0

    invoke-direct {v0, p2, v1}, LD1/m$b;-><init>(Lkotlin/jvm/functions/Function2;LD9/e;)V

    invoke-interface {p0, p1, v0, p3}, LD1/i;->a(LD1/o;Lkotlin/jvm/functions/Function2;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method private final i()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, LD1/m;->b:LH1/n;

    invoke-virtual {v0}, LH1/n;->d()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    iget-object p0, p0, LD1/m;->a:Ljava/lang/String;

    return-object p0

    :cond_0
    return-object v0
.end method

.method private final j()LNb/o;
    .locals 1

    iget-object v0, p0, LD1/m;->d:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lx1/a;

    if-eqz v0, :cond_1

    invoke-interface {v0}, Lx1/a;->getFileSystem()LNb/o;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    return-object v0

    :cond_1
    :goto_0
    iget-object p0, p0, LD1/m;->b:LH1/n;

    invoke-virtual {p0}, LH1/n;->g()LNb/o;

    move-result-object p0

    return-object p0
.end method

.method private final l()LD1/o;
    .locals 4

    iget-object v0, p0, LD1/m;->b:LH1/n;

    invoke-static {v0}, LD1/h;->b(LH1/n;)LD1/n;

    move-result-object v0

    invoke-virtual {v0}, LD1/n;->d()LD1/n$a;

    move-result-object v0

    iget-object v1, p0, LD1/m;->b:LH1/n;

    invoke-virtual {v1}, LH1/n;->e()LH1/c;

    move-result-object v1

    invoke-virtual {v1}, LH1/c;->d()Z

    move-result v1

    iget-object v2, p0, LD1/m;->b:LH1/n;

    invoke-virtual {v2}, LH1/n;->h()LH1/c;

    move-result-object v2

    invoke-virtual {v2}, LH1/c;->d()Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, LD1/m;->f:LD1/d;

    invoke-interface {v2}, LD1/d;->b()Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    const-string v3, "Cache-Control"

    if-nez v2, :cond_1

    if-eqz v1, :cond_1

    const-string v1, "only-if-cached, max-stale=2147483647"

    invoke-virtual {v0, v3, v1}, LD1/n$a;->c(Ljava/lang/String;Ljava/lang/String;)LD1/n$a;

    goto :goto_1

    :cond_1
    if-eqz v2, :cond_3

    if-nez v1, :cond_3

    iget-object v1, p0, LD1/m;->b:LH1/n;

    invoke-virtual {v1}, LH1/n;->e()LH1/c;

    move-result-object v1

    invoke-virtual {v1}, LH1/c;->h()Z

    move-result v1

    if-eqz v1, :cond_2

    const-string v1, "no-cache"

    invoke-virtual {v0, v3, v1}, LD1/n$a;->c(Ljava/lang/String;Ljava/lang/String;)LD1/n$a;

    goto :goto_1

    :cond_2
    const-string v1, "no-cache, no-store"

    invoke-virtual {v0, v3, v1}, LD1/n$a;->c(Ljava/lang/String;Ljava/lang/String;)LD1/n$a;

    goto :goto_1

    :cond_3
    if-nez v2, :cond_4

    if-nez v1, :cond_4

    const-string v1, "no-cache, only-if-cached"

    invoke-virtual {v0, v3, v1}, LD1/n$a;->c(Ljava/lang/String;Ljava/lang/String;)LD1/n$a;

    :cond_4
    :goto_1
    new-instance v1, LD1/o;

    iget-object v2, p0, LD1/m;->a:Ljava/lang/String;

    iget-object v3, p0, LD1/m;->b:LH1/n;

    invoke-static {v3}, LD1/h;->c(LH1/n;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, LD1/n$a;->b()LD1/n;

    move-result-object v0

    iget-object p0, p0, LD1/m;->b:LH1/n;

    invoke-static {p0}, LD1/h;->a(LH1/n;)LD1/p;

    const/4 p0, 0x0

    invoke-direct {v1, v2, v3, v0, p0}, LD1/o;-><init>(Ljava/lang/String;Ljava/lang/String;LD1/n;LD1/p;)V

    return-object v1
.end method

.method private final m()Lx1/a$c;
    .locals 2

    iget-object v0, p0, LD1/m;->b:LH1/n;

    invoke-virtual {v0}, LH1/n;->e()LH1/c;

    move-result-object v0

    invoke-virtual {v0}, LH1/c;->d()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, LD1/m;->d:Lkotlin/Lazy;

    invoke-interface {v0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lx1/a;

    if-eqz v0, :cond_0

    invoke-direct {p0}, LD1/m;->i()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0}, Lx1/a;->b(Ljava/lang/String;)Lx1/a$c;

    move-result-object p0

    return-object p0

    :cond_0
    return-object v1
.end method

.method private final n(LD1/r;LD9/e;)Ljava/lang/Object;
    .locals 4

    instance-of v0, p2, LD1/m$f;

    if-eqz v0, :cond_0

    move-object v0, p2

    check-cast v0, LD1/m$f;

    iget v1, v0, LD1/m$f;->m:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, LD1/m$f;->m:I

    goto :goto_0

    :cond_0
    new-instance v0, LD1/m$f;

    invoke-direct {v0, p0, p2}, LD1/m$f;-><init>(LD1/m;LD9/e;)V

    :goto_0
    iget-object p2, v0, LD1/m$f;->k:Ljava/lang/Object;

    invoke-static {}, LE9/b;->e()Ljava/lang/Object;

    move-result-object v1

    iget v2, v0, LD1/m$f;->m:I

    const/4 v3, 0x1

    if-eqz v2, :cond_2

    if-ne v2, v3, :cond_1

    iget-object p0, v0, LD1/m$f;->j:Ljava/lang/Object;

    check-cast p0, LNb/h;

    iget-object p1, v0, LD1/m$f;->i:Ljava/lang/Object;

    check-cast p1, LD1/m;

    invoke-static {p2}, Ly9/o;->b(Ljava/lang/Object;)V

    move-object p2, p0

    move-object p0, p1

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {p2}, Ly9/o;->b(Ljava/lang/Object;)V

    new-instance p2, LNb/h;

    invoke-direct {p2}, LNb/h;-><init>()V

    iput-object p0, v0, LD1/m$f;->i:Ljava/lang/Object;

    iput-object p2, v0, LD1/m$f;->j:Ljava/lang/Object;

    iput v3, v0, LD1/m$f;->m:I

    invoke-interface {p1, p2, v0}, LD1/r;->q1(LNb/i;LD9/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_3

    return-object v1

    :cond_3
    :goto_1
    invoke-direct {p0, p2}, LD1/m;->o(LNb/h;)Lw1/s;

    move-result-object p0

    return-object p0
.end method

.method private final o(LNb/h;)Lw1/s;
    .locals 2

    invoke-direct {p0}, LD1/m;->j()LNb/o;

    move-result-object p0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p1, p0, v0, v1, v0}, Lw1/t;->c(LNb/j;LNb/o;Lw1/s$a;ILjava/lang/Object;)Lw1/s;

    move-result-object p0

    return-object p0
.end method

.method private final p(Lx1/a$c;)Lw1/s;
    .locals 7

    invoke-interface {p1}, Lx1/a$c;->getData()LNb/F;

    move-result-object v0

    invoke-direct {p0}, LD1/m;->j()LNb/o;

    move-result-object v1

    invoke-direct {p0}, LD1/m;->i()Ljava/lang/String;

    move-result-object v2

    const/16 v5, 0x10

    const/4 v6, 0x0

    const/4 v4, 0x0

    move-object v3, p1

    invoke-static/range {v0 .. v6}, Lw1/t;->d(LNb/F;LNb/o;Ljava/lang/String;Ljava/lang/AutoCloseable;Lw1/s$a;ILjava/lang/Object;)Lw1/s;

    move-result-object p0

    return-object p0
.end method

.method private final q(Lx1/a$c;)LD1/q;
    .locals 1

    const/4 v0, 0x0

    :try_start_0
    invoke-direct {p0}, LD1/m;->j()LNb/o;

    move-result-object p0

    invoke-interface {p1}, Lx1/a$c;->getMetadata()LNb/F;

    move-result-object p1

    invoke-virtual {p0, p1}, LNb/o;->q(LNb/F;)LNb/O;

    move-result-object p0

    invoke-static {p0}, LNb/z;->d(LNb/O;)LNb/j;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    sget-object p1, LD1/a;->a:LD1/a;

    invoke-virtual {p1, p0}, LD1/a;->a(LNb/j;)LD1/q;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz p0, :cond_0

    :try_start_2
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_0
    :goto_0
    move-object p0, v0

    goto :goto_2

    :catchall_1
    move-exception p1

    if-eqz p0, :cond_1

    :try_start_3
    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    goto :goto_1

    :catchall_2
    move-exception p0

    :try_start_4
    invoke-static {p1, p0}, Ly9/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    move-object p0, p1

    move-object p1, v0

    :goto_2
    if-nez p0, :cond_2

    return-object p1

    :cond_2
    throw p0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    return-object v0
.end method

.method private final r(Lx1/a$c;LD1/q;LD1/o;LD1/q;LD9/e;)Ljava/lang/Object;
    .locals 10

    instance-of v0, p5, LD1/m$g;

    if-eqz v0, :cond_0

    move-object v0, p5

    check-cast v0, LD1/m$g;

    iget v1, v0, LD1/m$g;->n:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, LD1/m$g;->n:I

    :goto_0
    move-object v6, v0

    goto :goto_1

    :cond_0
    new-instance v0, LD1/m$g;

    invoke-direct {v0, p0, p5}, LD1/m$g;-><init>(LD1/m;LD9/e;)V

    goto :goto_0

    :goto_1
    iget-object p5, v6, LD1/m$g;->l:Ljava/lang/Object;

    invoke-static {}, LE9/b;->e()Ljava/lang/Object;

    move-result-object v7

    iget v0, v6, LD1/m$g;->n:I

    const/4 v8, 0x2

    const/4 v1, 0x1

    const/4 v9, 0x0

    if-eqz v0, :cond_3

    if-eq v0, v1, :cond_2

    if-ne v0, v8, :cond_1

    iget-object p0, v6, LD1/m$g;->k:Ljava/lang/Object;

    check-cast p0, Lx1/a$b;

    iget-object p1, v6, LD1/m$g;->j:Ljava/lang/Object;

    check-cast p1, LD1/q;

    iget-object p2, v6, LD1/m$g;->i:Ljava/lang/Object;

    check-cast p2, LD1/q;

    :try_start_0
    invoke-static {p5}, Ly9/o;->b(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_6

    :catch_0
    move-exception v0

    move-object p3, v0

    goto/16 :goto_7

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    iget-object p0, v6, LD1/m$g;->k:Ljava/lang/Object;

    move-object p4, p0

    check-cast p4, LD1/q;

    iget-object p0, v6, LD1/m$g;->j:Ljava/lang/Object;

    move-object p1, p0

    check-cast p1, Lx1/a$c;

    iget-object p0, v6, LD1/m$g;->i:Ljava/lang/Object;

    check-cast p0, LD1/m;

    invoke-static {p5}, Ly9/o;->b(Ljava/lang/Object;)V

    goto :goto_2

    :cond_3
    invoke-static {p5}, Ly9/o;->b(Ljava/lang/Object;)V

    iget-object p5, p0, LD1/m;->b:LH1/n;

    invoke-virtual {p5}, LH1/n;->e()LH1/c;

    move-result-object p5

    invoke-virtual {p5}, LH1/c;->h()Z

    move-result p5

    if-nez p5, :cond_5

    if-eqz p1, :cond_4

    invoke-static {p1}, LE1/e;->c(Ljava/lang/AutoCloseable;)V

    :cond_4
    return-object v9

    :cond_5
    iget-object p5, p0, LD1/m;->e:Lkotlin/Lazy;

    invoke-interface {p5}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object p5

    check-cast p5, LD1/b;

    iget-object v5, p0, LD1/m;->b:LH1/n;

    iput-object p0, v6, LD1/m$g;->i:Ljava/lang/Object;

    iput-object p1, v6, LD1/m$g;->j:Ljava/lang/Object;

    iput-object p4, v6, LD1/m$g;->k:Ljava/lang/Object;

    iput v1, v6, LD1/m$g;->n:I

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v1, p5

    invoke-interface/range {v1 .. v6}, LD1/b;->b(LD1/q;LD1/o;LD1/q;LH1/n;LD9/e;)Ljava/lang/Object;

    move-result-object p5

    if-ne p5, v7, :cond_6

    goto/16 :goto_5

    :cond_6
    move-object p4, v4

    :goto_2
    check-cast p5, LD1/b$c;

    invoke-virtual {p5}, LD1/b$c;->a()LD1/q;

    move-result-object p2

    if-nez p2, :cond_7

    return-object v9

    :cond_7
    if-eqz p1, :cond_8

    invoke-interface {p1}, Lx1/a$c;->F0()Lx1/a$b;

    move-result-object p1

    goto :goto_3

    :cond_8
    iget-object p1, p0, LD1/m;->d:Lkotlin/Lazy;

    invoke-interface {p1}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lx1/a;

    if-eqz p1, :cond_9

    invoke-direct {p0}, LD1/m;->i()Ljava/lang/String;

    move-result-object p3

    invoke-interface {p1, p3}, Lx1/a;->a(Ljava/lang/String;)Lx1/a$b;

    move-result-object p1

    goto :goto_3

    :cond_9
    move-object p1, v9

    :goto_3
    if-nez p1, :cond_a

    return-object v9

    :cond_a
    :try_start_1
    invoke-direct {p0}, LD1/m;->j()LNb/o;

    move-result-object p3

    invoke-interface {p1}, Lx1/a$b;->getMetadata()LNb/F;

    move-result-object p5

    const/4 v0, 0x0

    invoke-virtual {p3, p5, v0}, LNb/o;->p(LNb/F;Z)LNb/M;

    move-result-object p3

    invoke-static {p3}, LNb/z;->c(LNb/M;)LNb/i;

    move-result-object p3
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    sget-object p5, LD1/a;->a:LD1/a;

    invoke-virtual {p5, p2, p3}, LD1/a;->b(LD1/q;LNb/i;)V

    sget-object p5, Ly9/A;->a:Ly9/A;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-eqz p3, :cond_b

    :try_start_3
    invoke-interface {p3}, Ljava/io/Closeable;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_4

    :catchall_0
    move-exception v0

    move-object v9, v0

    goto :goto_4

    :catchall_1
    move-exception v0

    move-object p5, v0

    move-object v9, p5

    if-eqz p3, :cond_b

    :try_start_4
    invoke-interface {p3}, Ljava/io/Closeable;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    goto :goto_4

    :catchall_2
    move-exception v0

    move-object p3, v0

    :try_start_5
    invoke-static {v9, p3}, Ly9/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    goto :goto_4

    :catch_1
    move-exception v0

    move-object p3, v0

    move-object p0, p1

    move-object p1, p2

    move-object p2, p4

    goto :goto_7

    :cond_b
    :goto_4
    if-nez v9, :cond_d

    invoke-virtual {p2}, LD1/q;->c()LD1/r;

    move-result-object p3

    if-eqz p3, :cond_c

    invoke-direct {p0}, LD1/m;->j()LNb/o;

    move-result-object p0

    invoke-interface {p1}, Lx1/a$b;->getData()LNb/F;

    move-result-object p5

    iput-object p4, v6, LD1/m$g;->i:Ljava/lang/Object;

    iput-object p2, v6, LD1/m$g;->j:Ljava/lang/Object;

    iput-object p1, v6, LD1/m$g;->k:Ljava/lang/Object;

    iput v8, v6, LD1/m$g;->n:I

    invoke-interface {p3, p0, p5, v6}, LD1/r;->z0(LNb/o;LNb/F;LD9/e;)Ljava/lang/Object;

    move-result-object p0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    if-ne p0, v7, :cond_c

    :goto_5
    return-object v7

    :cond_c
    move-object p0, p1

    move-object p1, p2

    move-object p2, p4

    :goto_6
    :try_start_6
    invoke-interface {p0}, Lx1/a$b;->b()Lx1/a$c;

    move-result-object p0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    return-object p0

    :cond_d
    :try_start_7
    throw v9
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1

    :goto_7
    invoke-static {p0}, LE1/e;->a(Lx1/a$b;)V

    invoke-virtual {p2}, LD1/q;->c()LD1/r;

    move-result-object p0

    if-eqz p0, :cond_e

    invoke-static {p0}, LE1/e;->c(Ljava/lang/AutoCloseable;)V

    :cond_e
    invoke-virtual {p1}, LD1/q;->c()LD1/r;

    move-result-object p0

    if-eqz p0, :cond_f

    invoke-static {p0}, LE1/e;->c(Ljava/lang/AutoCloseable;)V

    :cond_f
    throw p3
.end method


# virtual methods
.method public a(LD9/e;)Ljava/lang/Object;
    .locals 14

    instance-of v0, p1, LD1/m$c;

    if-eqz v0, :cond_0

    move-object v0, p1

    check-cast v0, LD1/m$c;

    iget v1, v0, LD1/m$c;->n:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    iput v1, v0, LD1/m$c;->n:I

    goto :goto_0

    :cond_0
    new-instance v0, LD1/m$c;

    invoke-direct {v0, p0, p1}, LD1/m$c;-><init>(LD1/m;LD9/e;)V

    :goto_0
    iget-object p1, v0, LD1/m$c;->l:Ljava/lang/Object;

    invoke-static {}, LE9/b;->e()Ljava/lang/Object;

    move-result-object v1

    iget v2, v0, LD1/m$c;->n:I

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_4

    if-eq v2, v5, :cond_3

    if-eq v2, v4, :cond_2

    if-ne v2, v3, :cond_1

    iget-object p0, v0, LD1/m$c;->i:Ljava/lang/Object;

    check-cast p0, LO9/A;

    :try_start_0
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_a

    :catch_0
    move-exception v0

    move-object p1, v0

    goto/16 :goto_b

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    iget-object p0, v0, LD1/m$c;->j:Ljava/lang/Object;

    check-cast p0, LO9/A;

    iget-object v2, v0, LD1/m$c;->i:Ljava/lang/Object;

    check-cast v2, LD1/m;

    :try_start_1
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto/16 :goto_8

    :cond_3
    iget-object p0, v0, LD1/m$c;->k:Ljava/lang/Object;

    check-cast p0, LO9/A;

    iget-object v2, v0, LD1/m$c;->j:Ljava/lang/Object;

    check-cast v2, LO9/A;

    iget-object v5, v0, LD1/m$c;->i:Ljava/lang/Object;

    check-cast v5, LD1/m;

    :try_start_2
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    move-object v13, v2

    move-object v2, p0

    move-object p0, v5

    move-object v5, p1

    move-object p1, v13

    goto/16 :goto_2

    :catch_1
    move-exception v0

    move-object p1, v0

    move-object p0, v2

    goto/16 :goto_b

    :cond_4
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    new-instance p1, LO9/A;

    invoke-direct {p1}, LO9/A;-><init>()V

    invoke-direct {p0}, LD1/m;->m()Lx1/a$c;

    move-result-object v2

    iput-object v2, p1, LO9/A;->f:Ljava/lang/Object;

    :try_start_3
    new-instance v2, LO9/A;

    invoke-direct {v2}, LO9/A;-><init>()V

    iget-object v7, p1, LO9/A;->f:Ljava/lang/Object;

    if-eqz v7, :cond_9

    invoke-direct {p0}, LD1/m;->j()LNb/o;

    move-result-object v7

    iget-object v8, p1, LO9/A;->f:Ljava/lang/Object;

    check-cast v8, Lx1/a$c;

    invoke-interface {v8}, Lx1/a$c;->getMetadata()LNb/F;

    move-result-object v8

    invoke-virtual {v7, v8}, LNb/o;->l(LNb/F;)LNb/n;

    move-result-object v7

    invoke-virtual {v7}, LNb/n;->d()Ljava/lang/Long;

    move-result-object v7

    if-nez v7, :cond_5

    goto :goto_1

    :cond_5
    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    const-wide/16 v9, 0x0

    cmp-long v7, v7, v9

    if-nez v7, :cond_6

    new-instance v0, Ly1/n;

    iget-object v1, p1, LO9/A;->f:Ljava/lang/Object;

    check-cast v1, Lx1/a$c;

    invoke-direct {p0, v1}, LD1/m;->p(Lx1/a$c;)Lw1/s;

    move-result-object v1

    iget-object v2, p0, LD1/m;->a:Ljava/lang/String;

    invoke-virtual {p0, v2, v6}, LD1/m;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v2, Lw1/f;->h:Lw1/f;

    invoke-direct {v0, v1, p0, v2}, Ly1/n;-><init>(Lw1/s;Ljava/lang/String;Lw1/f;)V

    return-object v0

    :catch_2
    move-exception v0

    move-object p0, v0

    move-object v13, p1

    move-object p1, p0

    move-object p0, v13

    goto/16 :goto_b

    :cond_6
    :goto_1
    iget-object v7, p1, LO9/A;->f:Ljava/lang/Object;

    check-cast v7, Lx1/a$c;

    invoke-direct {p0, v7}, LD1/m;->q(Lx1/a$c;)LD1/q;

    move-result-object v7

    iput-object v7, v2, LO9/A;->f:Ljava/lang/Object;

    if-eqz v7, :cond_9

    iget-object v7, p0, LD1/m;->e:Lkotlin/Lazy;

    invoke-interface {v7}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, LD1/b;

    iget-object v8, v2, LO9/A;->f:Ljava/lang/Object;

    check-cast v8, LD1/q;

    invoke-direct {p0}, LD1/m;->l()LD1/o;

    move-result-object v9

    iget-object v10, p0, LD1/m;->b:LH1/n;

    iput-object p0, v0, LD1/m$c;->i:Ljava/lang/Object;

    iput-object p1, v0, LD1/m$c;->j:Ljava/lang/Object;

    iput-object v2, v0, LD1/m$c;->k:Ljava/lang/Object;

    iput v5, v0, LD1/m$c;->n:I

    invoke-interface {v7, v8, v9, v10, v0}, LD1/b;->a(LD1/q;LD1/o;LH1/n;LD9/e;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v1, :cond_7

    goto/16 :goto_9

    :cond_7
    :goto_2
    check-cast v5, LD1/b$b;

    invoke-virtual {v5}, LD1/b$b;->b()LD1/q;

    move-result-object v7

    if-eqz v7, :cond_8

    new-instance v0, Ly1/n;

    iget-object v1, p1, LO9/A;->f:Ljava/lang/Object;

    check-cast v1, Lx1/a$c;

    invoke-direct {p0, v1}, LD1/m;->p(Lx1/a$c;)Lw1/s;

    move-result-object v1

    iget-object v2, p0, LD1/m;->a:Ljava/lang/String;

    invoke-virtual {v5}, LD1/b$b;->b()LD1/q;

    move-result-object v3

    invoke-virtual {v3}, LD1/q;->e()LD1/n;

    move-result-object v3

    const-string v4, "Content-Type"

    invoke-virtual {v3, v4}, LD1/n;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v2, v3}, LD1/m;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v2, Lw1/f;->h:Lw1/f;

    invoke-direct {v0, v1, p0, v2}, Ly1/n;-><init>(Lw1/s;Ljava/lang/String;Lw1/f;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    return-object v0

    :cond_8
    :goto_3
    move-object v9, p0

    move-object v8, p1

    move-object v10, v2

    goto :goto_4

    :cond_9
    move-object v5, v6

    goto :goto_3

    :goto_4
    if-eqz v5, :cond_b

    :try_start_4
    invoke-virtual {v5}, LD1/b$b;->a()LD1/o;

    move-result-object p0

    if-nez p0, :cond_a

    goto :goto_6

    :cond_a
    :goto_5
    move-object v11, p0

    goto :goto_7

    :catch_3
    move-exception v0

    move-object p1, v0

    move-object p0, v8

    goto :goto_b

    :cond_b
    :goto_6
    invoke-direct {v9}, LD1/m;->l()LD1/o;

    move-result-object p0

    goto :goto_5

    :goto_7
    new-instance v7, LD1/m$e;

    const/4 v12, 0x0

    invoke-direct/range {v7 .. v12}, LD1/m$e;-><init>(LO9/A;LD1/m;LO9/A;LD1/o;LD9/e;)V

    iput-object v9, v0, LD1/m$c;->i:Ljava/lang/Object;

    iput-object v8, v0, LD1/m$c;->j:Ljava/lang/Object;

    iput-object v6, v0, LD1/m$c;->k:Ljava/lang/Object;

    iput v4, v0, LD1/m$c;->n:I

    invoke-direct {v9, v11, v7, v0}, LD1/m;->h(LD1/o;Lkotlin/jvm/functions/Function2;LD9/e;)Ljava/lang/Object;

    move-result-object p1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    if-ne p1, v1, :cond_c

    goto :goto_9

    :cond_c
    move-object p0, v8

    move-object v2, v9

    :goto_8
    :try_start_5
    check-cast p1, Ly1/n;

    if-nez p1, :cond_e

    invoke-direct {v2}, LD1/m;->l()LD1/o;

    move-result-object p1

    new-instance v4, LD1/m$d;

    invoke-direct {v4, v2, v6}, LD1/m$d;-><init>(LD1/m;LD9/e;)V

    iput-object p0, v0, LD1/m$c;->i:Ljava/lang/Object;

    iput-object v6, v0, LD1/m$c;->j:Ljava/lang/Object;

    iput v3, v0, LD1/m$c;->n:I

    invoke-direct {v2, p1, v4, v0}, LD1/m;->h(LD1/o;Lkotlin/jvm/functions/Function2;LD9/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_d

    :goto_9
    return-object v1

    :cond_d
    :goto_a
    check-cast p1, Ly1/n;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    :cond_e
    return-object p1

    :goto_b
    iget-object p0, p0, LO9/A;->f:Ljava/lang/Object;

    check-cast p0, Lx1/a$c;

    if-eqz p0, :cond_f

    invoke-static {p0}, LE1/e;->c(Ljava/lang/AutoCloseable;)V

    :cond_f
    throw p1
.end method

.method public final k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 p0, 0x2

    const/4 v0, 0x0

    if-eqz p2, :cond_0

    const-string v1, "text/plain"

    const/4 v2, 0x0

    invoke-static {p2, v1, v2, p0, v0}, Lib/q;->M(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    sget-object v1, LN1/s;->a:LN1/s;

    invoke-virtual {v1, p1}, LN1/s;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1

    return-object p1

    :cond_1
    if-eqz p2, :cond_2

    const/16 p1, 0x3b

    invoke-static {p2, p1, v0, p0, v0}, Lib/q;->Y0(Ljava/lang/String;CLjava/lang/String;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    return-object v0
.end method
