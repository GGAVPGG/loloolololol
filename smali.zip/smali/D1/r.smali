.class public interface abstract LD1/r;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/AutoCloseable;


# virtual methods
.method public abstract q1(LNb/i;LD9/e;)Ljava/lang/Object;
.end method

.method public abstract z0(LNb/o;LNb/F;LD9/e;)Ljava/lang/Object;
.end method
