.class public interface abstract LD1/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD1/b$a;,
        LD1/b$b;,
        LD1/b$c;
    }
.end annotation


# static fields
.field public static final a:LD1/b$a;

.field public static final b:LD1/b;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, LD1/b$a;->a:LD1/b$a;

    sput-object v0, LD1/b;->a:LD1/b$a;

    new-instance v0, LE1/a;

    invoke-direct {v0}, LE1/a;-><init>()V

    sput-object v0, LD1/b;->b:LD1/b;

    return-void
.end method


# virtual methods
.method public abstract a(LD1/q;LD1/o;LH1/n;LD9/e;)Ljava/lang/Object;
.end method

.method public abstract b(LD1/q;LD1/o;LD1/q;LH1/n;LD9/e;)Ljava/lang/Object;
.end method
