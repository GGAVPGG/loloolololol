.class public interface abstract LD1/p;
.super Ljava/lang/Object;
.source "SourceFile"
