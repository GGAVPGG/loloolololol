.class public interface abstract LD1/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LD1/o;Lkotlin/jvm/functions/Function2;LD9/e;)Ljava/lang/Object;
.end method
