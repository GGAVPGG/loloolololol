.class final LD1/s;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD1/r;


# instance fields
.field private final f:LNb/j;


# direct methods
.method private synthetic constructor <init>(LNb/j;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD1/s;->f:LNb/j;

    return-void
.end method

.method public static E(LNb/j;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "SourceResponseBody(source="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a0(LNb/j;LNb/i;LD9/e;)Ljava/lang/Object;
    .locals 0

    invoke-interface {p0, p1}, LNb/j;->B1(LNb/M;)J

    sget-object p0, Ly9/A;->a:Ly9/A;

    return-object p0
.end method

.method public static b0(LNb/j;LNb/o;LNb/F;LD9/e;)Ljava/lang/Object;
    .locals 0

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3}, LNb/o;->p(LNb/F;Z)LNb/M;

    move-result-object p1

    invoke-static {p1}, LNb/z;->c(LNb/M;)LNb/i;

    move-result-object p1

    :try_start_0
    invoke-interface {p0, p1}, LNb/j;->B1(LNb/M;)J

    move-result-wide p2

    invoke-static {p2, p3}, LF9/b;->d(J)Ljava/lang/Long;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz p1, :cond_0

    :try_start_1
    invoke-interface {p1}, Ljava/io/Closeable;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p0, 0x0

    goto :goto_1

    :catchall_1
    move-exception p0

    if-eqz p1, :cond_1

    :try_start_2
    invoke-interface {p1}, Ljava/io/Closeable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    goto :goto_1

    :catchall_2
    move-exception p1

    invoke-static {p0, p1}, Ly9/a;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    if-nez p0, :cond_2

    sget-object p0, Ly9/A;->a:Ly9/A;

    return-object p0

    :cond_2
    throw p0
.end method

.method public static final synthetic d(LNb/j;)LD1/s;
    .locals 1

    new-instance v0, LD1/s;

    invoke-direct {v0, p0}, LD1/s;-><init>(LNb/j;)V

    return-object v0
.end method

.method public static l(LNb/j;)V
    .locals 0

    invoke-interface {p0}, LNb/O;->close()V

    return-void
.end method

.method public static n(LNb/j;)LNb/j;
    .locals 0

    return-object p0
.end method

.method public static t(LNb/j;Ljava/lang/Object;)Z
    .locals 2

    instance-of v0, p1, LD1/s;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    check-cast p1, LD1/s;

    invoke-virtual {p1}, LD1/s;->F()LNb/j;

    move-result-object p1

    invoke-static {p0, p1}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    return v1

    :cond_1
    const/4 p0, 0x1

    return p0
.end method

.method public static z(LNb/j;)I
    .locals 0

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    return p0
.end method


# virtual methods
.method public final synthetic F()LNb/j;
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    return-object p0
.end method

.method public close()V
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    invoke-static {p0}, LD1/s;->l(LNb/j;)V

    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    invoke-static {p0, p1}, LD1/s;->t(LNb/j;Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public hashCode()I
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    invoke-static {p0}, LD1/s;->z(LNb/j;)I

    move-result p0

    return p0
.end method

.method public q1(LNb/i;LD9/e;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    invoke-static {p0, p1, p2}, LD1/s;->a0(LNb/j;LNb/i;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    invoke-static {p0}, LD1/s;->E(LNb/j;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public z0(LNb/o;LNb/F;LD9/e;)Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD1/s;->f:LNb/j;

    invoke-static {p0, p1, p2, p3}, LD1/s;->b0(LNb/j;LNb/o;LNb/F;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
