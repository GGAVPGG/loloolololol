.class public final synthetic LD1/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LN9/a;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    invoke-static {}, LD1/m$a;->b()LD1/b;

    move-result-object p0

    return-object p0
.end method
