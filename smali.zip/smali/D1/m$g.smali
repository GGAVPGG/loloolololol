.class final LD1/m$g;
.super LF9/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD1/m;->r(Lx1/a$c;LD1/q;LD1/o;LD1/q;LD9/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field i:Ljava/lang/Object;

.field j:Ljava/lang/Object;

.field k:Ljava/lang/Object;

.field synthetic l:Ljava/lang/Object;

.field final synthetic m:LD1/m;

.field n:I


# direct methods
.method constructor <init>(LD1/m;LD9/e;)V
    .locals 0

    iput-object p1, p0, LD1/m$g;->m:LD1/m;

    invoke-direct {p0, p2}, LF9/d;-><init>(LD9/e;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    iput-object p1, p0, LD1/m$g;->l:Ljava/lang/Object;

    iget p1, p0, LD1/m$g;->n:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LD1/m$g;->n:I

    iget-object v0, p0, LD1/m$g;->m:LD1/m;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object v5, p0

    invoke-static/range {v0 .. v5}, LD1/m;->g(LD1/m;Lx1/a$c;LD1/q;LD1/o;LD1/q;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
