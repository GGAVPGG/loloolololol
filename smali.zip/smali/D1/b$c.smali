.class public final LD1/b$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD1/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD1/b$c$a;
    }
.end annotation


# static fields
.field public static final b:LD1/b$c$a;

.field public static final c:LD1/b$c;


# instance fields
.field private final a:LD1/q;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LD1/b$c$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD1/b$c$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LD1/b$c;->b:LD1/b$c$a;

    new-instance v0, LD1/b$c;

    invoke-direct {v0}, LD1/b$c;-><init>()V

    sput-object v0, LD1/b$c;->c:LD1/b$c;

    return-void
.end method

.method private constructor <init>()V
    .locals 1

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 4
    iput-object v0, p0, LD1/b$c;->a:LD1/q;

    return-void
.end method

.method public constructor <init>(LD1/q;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, LD1/b$c;->a:LD1/q;

    return-void
.end method


# virtual methods
.method public final a()LD1/q;
    .locals 0

    iget-object p0, p0, LD1/b$c;->a:LD1/q;

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x1

    if-ne p0, p1, :cond_0

    return v0

    :cond_0
    instance-of v1, p1, LD1/b$c;

    if-eqz v1, :cond_1

    iget-object p0, p0, LD1/b$c;->a:LD1/q;

    check-cast p1, LD1/b$c;

    iget-object p1, p1, LD1/b$c;->a:LD1/q;

    invoke-static {p0, p1}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    return v0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method

.method public hashCode()I
    .locals 0

    iget-object p0, p0, LD1/b$c;->a:LD1/q;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, LD1/q;->hashCode()I

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "WriteResult(response="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, LD1/b$c;->a:LD1/q;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
