.class final synthetic LD1/m$a$a;
.super LO9/k;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD1/m$a;-><init>(LN9/a;LN9/a;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation


# static fields
.field public static final o:LD1/m$a$a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LD1/m$a$a;

    invoke-direct {v0}, LD1/m$a$a;-><init>()V

    sput-object v0, LD1/m$a$a;->o:LD1/m$a$a;

    return-void
.end method

.method constructor <init>()V
    .locals 6

    const-string v4, "ConnectivityChecker(Landroid/content/Context;)Lcoil3/network/ConnectivityChecker;"

    const/4 v5, 0x1

    const/4 v1, 0x1

    const-class v2, LD1/f;

    const-string v3, "ConnectivityChecker"

    move-object v0, p0

    invoke-direct/range {v0 .. v5}, LO9/k;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final J(Landroid/content/Context;)LD1/d;
    .locals 0

    invoke-static {p1}, LD1/f;->a(Landroid/content/Context;)LD1/d;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Landroid/content/Context;

    invoke-virtual {p0, p1}, LD1/m$a$a;->J(Landroid/content/Context;)LD1/d;

    move-result-object p0

    return-object p0
.end method
