.class final LD1/m$b;
.super LF9/l;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD1/m;->h(LD1/o;Lkotlin/jvm/functions/Function2;LD9/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field j:I

.field synthetic k:Ljava/lang/Object;

.field final synthetic l:Lkotlin/jvm/functions/Function2;


# direct methods
.method constructor <init>(Lkotlin/jvm/functions/Function2;LD9/e;)V
    .locals 0

    iput-object p1, p0, LD1/m$b;->l:Lkotlin/jvm/functions/Function2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LF9/l;-><init>(ILD9/e;)V

    return-void
.end method


# virtual methods
.method public bridge synthetic B(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD1/q;

    check-cast p2, LD9/e;

    invoke-virtual {p0, p1, p2}, LD1/m$b;->z(LD1/q;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final f(Ljava/lang/Object;LD9/e;)LD9/e;
    .locals 1

    new-instance v0, LD1/m$b;

    iget-object p0, p0, LD1/m$b;->l:Lkotlin/jvm/functions/Function2;

    invoke-direct {v0, p0, p2}, LD1/m$b;-><init>(Lkotlin/jvm/functions/Function2;LD9/e;)V

    iput-object p1, v0, LD1/m$b;->k:Ljava/lang/Object;

    return-object v0
.end method

.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    invoke-static {}, LE9/b;->e()Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, LD1/m$b;->j:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    return-object p1

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    iget-object p1, p0, LD1/m$b;->k:Ljava/lang/Object;

    check-cast p1, LD1/q;

    invoke-virtual {p1}, LD1/q;->d()I

    move-result v1

    const/16 v3, 0xc8

    if-gt v3, v1, :cond_2

    const/16 v3, 0x12c

    if-ge v1, v3, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, LD1/q;->d()I

    move-result v1

    const/16 v3, 0x130

    if-ne v1, v3, :cond_4

    :goto_0
    iget-object v1, p0, LD1/m$b;->l:Lkotlin/jvm/functions/Function2;

    iput v2, p0, LD1/m$b;->j:I

    invoke-interface {v1, p1, p0}, Lkotlin/jvm/functions/Function2;->B(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_3

    return-object v0

    :cond_3
    return-object p0

    :cond_4
    new-instance p0, LD1/g;

    invoke-direct {p0, p1}, LD1/g;-><init>(LD1/q;)V

    throw p0
.end method

.method public final z(LD1/q;LD9/e;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1, p2}, LD1/m$b;->f(Ljava/lang/Object;LD9/e;)LD9/e;

    move-result-object p0

    check-cast p0, LD1/m$b;

    sget-object p1, Ly9/A;->a:Ly9/A;

    invoke-virtual {p0, p1}, LD1/m$b;->j(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
