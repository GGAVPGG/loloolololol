.class public final synthetic LD1/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LN9/a;


# instance fields
.field public final synthetic f:Lv1/r;


# direct methods
.method public synthetic constructor <init>(Lv1/r;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD1/k;->f:Lv1/r;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, LD1/k;->f:Lv1/r;

    invoke-static {p0}, LD1/m$a;->c(Lv1/r;)Lx1/a;

    move-result-object p0

    return-object p0
.end method
