.class public abstract LD1/h;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Lv1/l$c;

.field private static final b:Lv1/l$c;

.field private static final c:Lv1/l$c;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lv1/l$c;

    const-string v1, "GET"

    invoke-direct {v0, v1}, Lv1/l$c;-><init>(Ljava/lang/Object;)V

    sput-object v0, LD1/h;->a:Lv1/l$c;

    new-instance v0, Lv1/l$c;

    sget-object v1, LD1/n;->c:LD1/n;

    invoke-direct {v0, v1}, Lv1/l$c;-><init>(Ljava/lang/Object;)V

    sput-object v0, LD1/h;->b:Lv1/l$c;

    new-instance v0, Lv1/l$c;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lv1/l$c;-><init>(Ljava/lang/Object;)V

    sput-object v0, LD1/h;->c:Lv1/l$c;

    return-void
.end method

.method public static final a(LH1/n;)LD1/p;
    .locals 1

    sget-object v0, LD1/h;->c:Lv1/l$c;

    invoke-static {p0, v0}, Lv1/m;->b(LH1/n;Lv1/l$c;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroid/support/v4/media/session/b;->a(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static final b(LH1/n;)LD1/n;
    .locals 1

    sget-object v0, LD1/h;->b:Lv1/l$c;

    invoke-static {p0, v0}, Lv1/m;->b(LH1/n;Lv1/l$c;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LD1/n;

    return-object p0
.end method

.method public static final c(LH1/n;)Ljava/lang/String;
    .locals 1

    sget-object v0, LD1/h;->a:Lv1/l$c;

    invoke-static {p0, v0}, Lv1/m;->b(LH1/n;Lv1/l$c;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
