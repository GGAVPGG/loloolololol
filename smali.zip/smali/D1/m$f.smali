.class final LD1/m$f;
.super LF9/d;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD1/m;->n(LD1/r;LD9/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field i:Ljava/lang/Object;

.field j:Ljava/lang/Object;

.field synthetic k:Ljava/lang/Object;

.field final synthetic l:LD1/m;

.field m:I


# direct methods
.method constructor <init>(LD1/m;LD9/e;)V
    .locals 0

    iput-object p1, p0, LD1/m$f;->l:LD1/m;

    invoke-direct {p0, p2}, LF9/d;-><init>(LD9/e;)V

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, LD1/m$f;->k:Ljava/lang/Object;

    iget p1, p0, LD1/m$f;->m:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LD1/m$f;->m:I

    iget-object p1, p0, LD1/m$f;->l:LD1/m;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, LD1/m;->c(LD1/m;LD1/r;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
