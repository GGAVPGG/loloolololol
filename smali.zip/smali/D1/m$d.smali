.class final LD1/m$d;
.super LF9/l;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD1/m;->a(LD9/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field j:I

.field synthetic k:Ljava/lang/Object;

.field final synthetic l:LD1/m;


# direct methods
.method constructor <init>(LD1/m;LD9/e;)V
    .locals 0

    iput-object p1, p0, LD1/m$d;->l:LD1/m;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, LF9/l;-><init>(ILD9/e;)V

    return-void
.end method


# virtual methods
.method public bridge synthetic B(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD1/q;

    check-cast p2, LD9/e;

    invoke-virtual {p0, p1, p2}, LD1/m$d;->z(LD1/q;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final f(Ljava/lang/Object;LD9/e;)LD9/e;
    .locals 1

    new-instance v0, LD1/m$d;

    iget-object p0, p0, LD1/m$d;->l:LD1/m;

    invoke-direct {v0, p0, p2}, LD1/m$d;-><init>(LD1/m;LD9/e;)V

    iput-object p1, v0, LD1/m$d;->k:Ljava/lang/Object;

    return-object v0
.end method

.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    invoke-static {}, LE9/b;->e()Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, LD1/m$d;->j:I

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    if-ne v1, v2, :cond_0

    iget-object v0, p0, LD1/m$d;->k:Ljava/lang/Object;

    check-cast v0, LD1/q;

    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    iget-object p1, p0, LD1/m$d;->k:Ljava/lang/Object;

    check-cast p1, LD1/q;

    iget-object v1, p0, LD1/m$d;->l:LD1/m;

    invoke-static {p1}, LE1/e;->f(LD1/q;)LD1/r;

    move-result-object v3

    iput-object p1, p0, LD1/m$d;->k:Ljava/lang/Object;

    iput v2, p0, LD1/m$d;->j:I

    invoke-static {v1, v3, p0}, LD1/m;->c(LD1/m;LD1/r;LD9/e;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_2

    return-object v0

    :cond_2
    move-object v0, p1

    move-object p1, v1

    :goto_0
    check-cast p1, Lw1/s;

    iget-object p0, p0, LD1/m$d;->l:LD1/m;

    invoke-static {p0}, LD1/m;->b(LD1/m;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, LD1/q;->e()LD1/n;

    move-result-object v0

    const-string v2, "Content-Type"

    invoke-virtual {v0, v2}, LD1/n;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, LD1/m;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v0, Lw1/f;->i:Lw1/f;

    new-instance v1, Ly1/n;

    invoke-direct {v1, p1, p0, v0}, Ly1/n;-><init>(Lw1/s;Ljava/lang/String;Lw1/f;)V

    return-object v1
.end method

.method public final z(LD1/q;LD9/e;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1, p2}, LD1/m$d;->f(Ljava/lang/Object;LD9/e;)LD9/e;

    move-result-object p0

    check-cast p0, LD1/m$d;

    sget-object p1, Ly9/A;->a:Ly9/A;

    invoke-virtual {p0, p1}, LD1/m$d;->j(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
