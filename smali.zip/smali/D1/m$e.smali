.class final LD1/m$e;
.super LF9/l;
.source "SourceFile"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LD1/m;->a(LD9/e;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation


# instance fields
.field j:Ljava/lang/Object;

.field k:I

.field synthetic l:Ljava/lang/Object;

.field final synthetic m:LO9/A;

.field final synthetic n:LD1/m;

.field final synthetic o:LO9/A;

.field final synthetic p:LD1/o;


# direct methods
.method constructor <init>(LO9/A;LD1/m;LO9/A;LD1/o;LD9/e;)V
    .locals 0

    iput-object p1, p0, LD1/m$e;->m:LO9/A;

    iput-object p2, p0, LD1/m$e;->n:LD1/m;

    iput-object p3, p0, LD1/m$e;->o:LO9/A;

    iput-object p4, p0, LD1/m$e;->p:LD1/o;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, LF9/l;-><init>(ILD9/e;)V

    return-void
.end method


# virtual methods
.method public bridge synthetic B(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, LD1/q;

    check-cast p2, LD9/e;

    invoke-virtual {p0, p1, p2}, LD1/m$e;->z(LD1/q;LD9/e;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final f(Ljava/lang/Object;LD9/e;)LD9/e;
    .locals 6

    new-instance v0, LD1/m$e;

    iget-object v1, p0, LD1/m$e;->m:LO9/A;

    iget-object v2, p0, LD1/m$e;->n:LD1/m;

    iget-object v3, p0, LD1/m$e;->o:LO9/A;

    iget-object v4, p0, LD1/m$e;->p:LD1/o;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, LD1/m$e;-><init>(LO9/A;LD1/m;LO9/A;LD1/o;LD9/e;)V

    iput-object p1, v0, LD1/m$e;->l:Ljava/lang/Object;

    return-object v0
.end method

.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    invoke-static {}, LE9/b;->e()Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, LD1/m$e;->k:I

    const-string v2, "Content-Type"

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    if-eq v1, v4, :cond_1

    if-ne v1, v3, :cond_0

    iget-object v0, p0, LD1/m$e;->l:Ljava/lang/Object;

    check-cast v0, LD1/q;

    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    move-object v11, p0

    goto/16 :goto_2

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    iget-object v1, p0, LD1/m$e;->j:Ljava/lang/Object;

    check-cast v1, LO9/A;

    iget-object v4, p0, LD1/m$e;->l:Ljava/lang/Object;

    check-cast v4, LD1/q;

    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    move-object v11, p0

    goto :goto_0

    :cond_2
    invoke-static {p1}, Ly9/o;->b(Ljava/lang/Object;)V

    iget-object p1, p0, LD1/m$e;->l:Ljava/lang/Object;

    move-object v10, p1

    check-cast v10, LD1/q;

    iget-object v1, p0, LD1/m$e;->m:LO9/A;

    iget-object v6, p0, LD1/m$e;->n:LD1/m;

    iget-object p1, v1, LO9/A;->f:Ljava/lang/Object;

    move-object v7, p1

    check-cast v7, Lx1/a$c;

    iget-object p1, p0, LD1/m$e;->o:LO9/A;

    iget-object p1, p1, LO9/A;->f:Ljava/lang/Object;

    move-object v8, p1

    check-cast v8, LD1/q;

    iget-object v9, p0, LD1/m$e;->p:LD1/o;

    iput-object v10, p0, LD1/m$e;->l:Ljava/lang/Object;

    iput-object v1, p0, LD1/m$e;->j:Ljava/lang/Object;

    iput v4, p0, LD1/m$e;->k:I

    move-object v11, p0

    invoke-static/range {v6 .. v11}, LD1/m;->g(LD1/m;Lx1/a$c;LD1/q;LD1/o;LD1/q;LD9/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3

    goto :goto_1

    :cond_3
    move-object v4, v10

    :goto_0
    iput-object p1, v1, LO9/A;->f:Ljava/lang/Object;

    iget-object p0, v11, LD1/m$e;->m:LO9/A;

    iget-object p0, p0, LO9/A;->f:Ljava/lang/Object;

    if-eqz p0, :cond_5

    iget-object p1, v11, LD1/m$e;->o:LO9/A;

    iget-object v0, v11, LD1/m$e;->n:LD1/m;

    invoke-static {p0}, LO9/l;->d(Ljava/lang/Object;)V

    check-cast p0, Lx1/a$c;

    invoke-static {v0, p0}, LD1/m;->f(LD1/m;Lx1/a$c;)LD1/q;

    move-result-object p0

    iput-object p0, p1, LO9/A;->f:Ljava/lang/Object;

    new-instance p0, Ly1/n;

    iget-object p1, v11, LD1/m$e;->n:LD1/m;

    iget-object v0, v11, LD1/m$e;->m:LO9/A;

    iget-object v0, v0, LO9/A;->f:Ljava/lang/Object;

    invoke-static {v0}, LO9/l;->d(Ljava/lang/Object;)V

    check-cast v0, Lx1/a$c;

    invoke-static {p1, v0}, LD1/m;->e(LD1/m;Lx1/a$c;)Lw1/s;

    move-result-object p1

    iget-object v0, v11, LD1/m$e;->n:LD1/m;

    invoke-static {v0}, LD1/m;->b(LD1/m;)Ljava/lang/String;

    move-result-object v1

    iget-object v3, v11, LD1/m$e;->o:LO9/A;

    iget-object v3, v3, LO9/A;->f:Ljava/lang/Object;

    check-cast v3, LD1/q;

    if-eqz v3, :cond_4

    invoke-virtual {v3}, LD1/q;->e()LD1/n;

    move-result-object v3

    if-eqz v3, :cond_4

    invoke-virtual {v3, v2}, LD1/n;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :cond_4
    invoke-virtual {v0, v1, v5}, LD1/m;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lw1/f;->i:Lw1/f;

    invoke-direct {p0, p1, v0, v1}, Ly1/n;-><init>(Lw1/s;Ljava/lang/String;Lw1/f;)V

    return-object p0

    :cond_5
    invoke-static {v4}, LE1/e;->f(LD1/q;)LD1/r;

    move-result-object p0

    iput-object v4, v11, LD1/m$e;->l:Ljava/lang/Object;

    iput-object v5, v11, LD1/m$e;->j:Ljava/lang/Object;

    iput v3, v11, LD1/m$e;->k:I

    invoke-static {p0, v11}, LE1/e;->e(LD1/r;LD9/e;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_6

    :goto_1
    return-object v0

    :cond_6
    move-object v0, v4

    :goto_2
    check-cast p1, LNb/h;

    invoke-virtual {p1}, LNb/h;->size()J

    move-result-wide v3

    const-wide/16 v6, 0x0

    cmp-long p0, v3, v6

    if-lez p0, :cond_7

    new-instance p0, Ly1/n;

    iget-object v1, v11, LD1/m$e;->n:LD1/m;

    invoke-static {v1, p1}, LD1/m;->d(LD1/m;LNb/h;)Lw1/s;

    move-result-object p1

    iget-object v1, v11, LD1/m$e;->n:LD1/m;

    invoke-static {v1}, LD1/m;->b(LD1/m;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0}, LD1/q;->e()LD1/n;

    move-result-object v0

    invoke-virtual {v0, v2}, LD1/n;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v3, v0}, LD1/m;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lw1/f;->i:Lw1/f;

    invoke-direct {p0, p1, v0, v1}, Ly1/n;-><init>(Lw1/s;Ljava/lang/String;Lw1/f;)V

    return-object p0

    :cond_7
    return-object v5
.end method

.method public final z(LD1/q;LD9/e;)Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0, p1, p2}, LD1/m$e;->f(Ljava/lang/Object;LD9/e;)LD9/e;

    move-result-object p0

    check-cast p0, LD1/m$e;

    sget-object p1, Ly9/A;->a:Ly9/A;

    invoke-virtual {p0, p1}, LD1/m$e;->j(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
