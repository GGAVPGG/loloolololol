.class public final LD1/m$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly1/i$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD1/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Lkotlin/Lazy;

.field private final b:Lkotlin/Lazy;

.field private final c:LE1/b;


# direct methods
.method public constructor <init>(LN9/a;LN9/a;Lkotlin/jvm/functions/Function1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    invoke-static {p1}, Ly9/h;->a(LN9/a;)Lkotlin/Lazy;

    move-result-object p1

    iput-object p1, p0, LD1/m$a;->a:Lkotlin/Lazy;

    .line 3
    invoke-static {p2}, Ly9/h;->a(LN9/a;)Lkotlin/Lazy;

    move-result-object p1

    iput-object p1, p0, LD1/m$a;->b:Lkotlin/Lazy;

    .line 4
    invoke-static {p3}, LE1/c;->a(Lkotlin/jvm/functions/Function1;)LE1/b;

    move-result-object p1

    iput-object p1, p0, LD1/m$a;->c:LE1/b;

    return-void
.end method

.method public synthetic constructor <init>(LN9/a;LN9/a;Lkotlin/jvm/functions/Function1;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    .locals 0

    and-int/lit8 p5, p4, 0x2

    if-eqz p5, :cond_0

    .line 5
    new-instance p2, LD1/l;

    invoke-direct {p2}, LD1/l;-><init>()V

    :cond_0
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_1

    .line 6
    sget-object p3, LD1/m$a$a;->o:LD1/m$a$a;

    .line 7
    :cond_1
    invoke-direct {p0, p1, p2, p3}, LD1/m$a;-><init>(LN9/a;LN9/a;Lkotlin/jvm/functions/Function1;)V

    return-void
.end method

.method public static synthetic b()LD1/b;
    .locals 1

    invoke-static {}, LD1/m$a;->d()LD1/b;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic c(Lv1/r;)Lx1/a;
    .locals 0

    invoke-static {p0}, LD1/m$a;->f(Lv1/r;)Lx1/a;

    move-result-object p0

    return-object p0
.end method

.method private static final d()LD1/b;
    .locals 1

    sget-object v0, LD1/b;->b:LD1/b;

    return-object v0
.end method

.method private static final f(Lv1/r;)Lx1/a;
    .locals 0

    invoke-interface {p0}, Lv1/r;->c()Lx1/a;

    move-result-object p0

    return-object p0
.end method

.method private final g(Lv1/C;)Z
    .locals 1

    invoke-virtual {p1}, Lv1/C;->c()Ljava/lang/String;

    move-result-object p0

    const-string v0, "http"

    invoke-static {p0, v0}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    invoke-virtual {p1}, Lv1/C;->c()Ljava/lang/String;

    move-result-object p0

    const-string p1, "https"

    invoke-static {p0, p1}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x1

    return p0
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;LH1/n;Lv1/r;)Ly1/i;
    .locals 0

    check-cast p1, Lv1/C;

    invoke-virtual {p0, p1, p2, p3}, LD1/m$a;->e(Lv1/C;LH1/n;Lv1/r;)Ly1/i;

    move-result-object p0

    return-object p0
.end method

.method public e(Lv1/C;LH1/n;Lv1/r;)Ly1/i;
    .locals 7

    invoke-direct {p0, p1}, LD1/m$a;->g(Lv1/C;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, LD1/m;

    invoke-virtual {p1}, Lv1/C;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, LD1/m$a;->a:Lkotlin/Lazy;

    new-instance p1, LD1/k;

    invoke-direct {p1, p3}, LD1/k;-><init>(Lv1/r;)V

    invoke-static {p1}, Ly9/h;->a(LN9/a;)Lkotlin/Lazy;

    move-result-object v4

    iget-object v5, p0, LD1/m$a;->b:Lkotlin/Lazy;

    iget-object p0, p0, LD1/m$a;->c:LE1/b;

    invoke-virtual {p2}, LH1/n;->c()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0, p1}, LE1/b;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    move-object v6, p0

    check-cast v6, LD1/d;

    move-object v2, p2

    invoke-direct/range {v0 .. v6}, LD1/m;-><init>(Ljava/lang/String;LH1/n;Lkotlin/Lazy;Lkotlin/Lazy;Lkotlin/Lazy;LD1/d;)V

    return-object v0
.end method
