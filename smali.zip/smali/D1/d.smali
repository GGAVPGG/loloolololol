.class public interface abstract LD1/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LD1/d$a;
    }
.end annotation


# static fields
.field public static final a:LD1/d$a;

.field public static final b:LD1/d;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, LD1/d$a;->a:LD1/d$a;

    sput-object v0, LD1/d;->a:LD1/d$a;

    new-instance v0, LD1/c;

    invoke-direct {v0}, LD1/c;-><init>()V

    sput-object v0, LD1/d;->b:LD1/d;

    return-void
.end method

.method private static a()Z
    .locals 1

    const/4 v0, 0x1

    return v0
.end method

.method public static synthetic c()Z
    .locals 1

    invoke-static {}, LD1/d;->a()Z

    move-result v0

    return v0
.end method


# virtual methods
.method public abstract b()Z
.end method
