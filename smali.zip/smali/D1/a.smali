.class public final LD1/a;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD1/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LD1/a;

    invoke-direct {v0}, LD1/a;-><init>()V

    sput-object v0, LD1/a;->a:LD1/a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(LNb/j;)LD1/q;
    .locals 11

    invoke-interface {p1}, LNb/j;->p1()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    invoke-interface {p1}, LNb/j;->p1()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    invoke-interface {p1}, LNb/j;->p1()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    new-instance p0, LD1/n$a;

    invoke-direct {p0}, LD1/n$a;-><init>()V

    invoke-interface {p1}, LNb/j;->p1()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v6, 0x0

    :goto_0
    if-ge v6, v0, :cond_0

    invoke-interface {p1}, LNb/j;->p1()Ljava/lang/String;

    move-result-object v7

    invoke-static {p0, v7}, LE1/e;->b(LD1/n$a;Ljava/lang/String;)LD1/n$a;

    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_0
    new-instance v0, LD1/q;

    invoke-virtual {p0}, LD1/n$a;->b()LD1/n;

    move-result-object v6

    const/16 v9, 0x30

    const/4 v10, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct/range {v0 .. v10}, LD1/q;-><init>(IJJLD1/n;LD1/r;Ljava/lang/Object;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method public final b(LD1/q;LNb/i;)V
    .locals 5

    invoke-virtual {p1}, LD1/q;->d()I

    move-result p0

    int-to-long v0, p0

    invoke-interface {p2, v0, v1}, LNb/i;->X1(J)LNb/i;

    move-result-object p0

    const/16 v0, 0xa

    invoke-interface {p0, v0}, LNb/i;->writeByte(I)LNb/i;

    invoke-virtual {p1}, LD1/q;->f()J

    move-result-wide v1

    invoke-interface {p2, v1, v2}, LNb/i;->X1(J)LNb/i;

    move-result-object p0

    invoke-interface {p0, v0}, LNb/i;->writeByte(I)LNb/i;

    invoke-virtual {p1}, LD1/q;->g()J

    move-result-wide v1

    invoke-interface {p2, v1, v2}, LNb/i;->X1(J)LNb/i;

    move-result-object p0

    invoke-interface {p0, v0}, LNb/i;->writeByte(I)LNb/i;

    invoke-virtual {p1}, LD1/q;->e()LD1/n;

    move-result-object p0

    invoke-virtual {p0}, LD1/n;->b()Ljava/util/Map;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v1, 0x0

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    add-int/2addr v1, v2

    goto :goto_0

    :cond_0
    int-to-long v1, v1

    invoke-interface {p2, v1, v2}, LNb/i;->X1(J)LNb/i;

    move-result-object p1

    invoke-interface {p1, v0}, LNb/i;->writeByte(I)LNb/i;

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {p2, v3}, LNb/i;->N0(Ljava/lang/String;)LNb/i;

    move-result-object v3

    const-string v4, ":"

    invoke-interface {v3, v4}, LNb/i;->N0(Ljava/lang/String;)LNb/i;

    move-result-object v3

    invoke-interface {v3, v2}, LNb/i;->N0(Ljava/lang/String;)LNb/i;

    move-result-object v2

    invoke-interface {v2, v0}, LNb/i;->writeByte(I)LNb/i;

    goto :goto_1

    :cond_2
    return-void
.end method
