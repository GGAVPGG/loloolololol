.class public abstract LD1/j;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(LNb/j;)LD1/r;
    .locals 0

    invoke-static {p0}, LD1/s;->n(LNb/j;)LNb/j;

    move-result-object p0

    invoke-static {p0}, LD1/s;->d(LNb/j;)LD1/s;

    move-result-object p0

    return-object p0
.end method
