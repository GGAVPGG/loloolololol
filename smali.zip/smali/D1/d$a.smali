.class public final LD1/d$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LD1/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field static final synthetic a:LD1/d$a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LD1/d$a;

    invoke-direct {v0}, LD1/d$a;-><init>()V

    sput-object v0, LD1/d$a;->a:LD1/d$a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
