.class public interface abstract LF3/b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF3/b$a;
    }
.end annotation


# virtual methods
.method public abstract a()LF3/b$a;
.end method
