.class final LF3/a$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF3/b$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF3/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Landroid/view/Choreographer;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object v0

    const-string v1, "getInstance(...)"

    invoke-static {v0, v1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    iput-object v0, p0, LF3/a$a;->a:Landroid/view/Choreographer;

    return-void
.end method


# virtual methods
.method public a(Landroid/view/Choreographer$FrameCallback;)V
    .locals 1

    const-string v0, "callback"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, LF3/a$a;->a:Landroid/view/Choreographer;

    invoke-virtual {p0, p1}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    return-void
.end method

.method public b(Landroid/view/Choreographer$FrameCallback;)V
    .locals 1

    const-string v0, "callback"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, LF3/a$a;->a:Landroid/view/Choreographer;

    invoke-virtual {p0, p1}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    return-void
.end method
