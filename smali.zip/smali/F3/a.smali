.class public final LF3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF3/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF3/a$a;
    }
.end annotation


# static fields
.field public static final a:LF3/a;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LF3/a;

    invoke-direct {v0}, LF3/a;-><init>()V

    sput-object v0, LF3/a;->a:LF3/a;

    return-void
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final b()LF3/a;
    .locals 1

    sget-object v0, LF3/a;->a:LF3/a;

    return-object v0
.end method


# virtual methods
.method public a()LF3/b$a;
    .locals 0

    invoke-static {}, Lcom/facebook/react/bridge/UiThreadUtil;->assertOnUiThread()V

    new-instance p0, LF3/a$a;

    invoke-direct {p0}, LF3/a$a;-><init>()V

    return-object p0
.end method
