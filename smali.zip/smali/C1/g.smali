.class public final LC1/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/d;


# instance fields
.field private final a:LC1/j;

.field private final b:LC1/k;

.field private final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LC1/j;LC1/k;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC1/g;->a:LC1/j;

    iput-object p2, p0, LC1/g;->b:LC1/k;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC1/g;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(LC1/d$b;)Z
    .locals 2

    iget-object v0, p0, LC1/g;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, LC1/g;->a:LC1/j;

    invoke-interface {v1, p1}, LC1/j;->b(LC1/d$b;)Z

    move-result v1

    iget-object p0, p0, LC1/g;->b:LC1/k;

    invoke-interface {p0, p1}, LC1/k;->b(LC1/d$b;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v1, :cond_1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    monitor-exit v0

    return p0

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public c()J
    .locals 3

    iget-object v0, p0, LC1/g;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, LC1/g;->a:LC1/j;

    invoke-interface {p0}, LC1/j;->c()J

    move-result-wide v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-wide v1

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public clear()V
    .locals 2

    iget-object v0, p0, LC1/g;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, LC1/g;->a:LC1/j;

    invoke-interface {v1}, LC1/j;->clear()V

    iget-object p0, p0, LC1/g;->b:LC1/k;

    invoke-interface {p0}, LC1/k;->clear()V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public d(LC1/d$b;)LC1/d$c;
    .locals 3

    iget-object v0, p0, LC1/g;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, LC1/g;->a:LC1/j;

    invoke-interface {v1, p1}, LC1/j;->d(LC1/d$b;)LC1/d$c;

    move-result-object v1

    if-nez v1, :cond_0

    iget-object v1, p0, LC1/g;->b:LC1/k;

    invoke-interface {v1, p1}, LC1/k;->d(LC1/d$b;)LC1/d$c;

    move-result-object v1

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {v1}, LC1/d$c;->b()Lv1/n;

    move-result-object v2

    invoke-interface {v2}, Lv1/n;->e()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {p0, p1}, LC1/g;->a(LC1/d$b;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit v0

    return-object v1

    :goto_1
    monitor-exit v0

    throw p0
.end method

.method public e(J)V
    .locals 1

    iget-object v0, p0, LC1/g;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, LC1/g;->a:LC1/j;

    invoke-interface {p0, p1, p2}, LC1/j;->e(J)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public f(LC1/d$b;LC1/d$c;)V
    .locals 8

    iget-object v1, p0, LC1/g;->c:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    invoke-virtual {p2}, LC1/d$c;->b()Lv1/n;

    move-result-object v0

    invoke-interface {v0}, Lv1/n;->c()J

    move-result-wide v6

    const-wide/16 v2, 0x0

    cmp-long v0, v6, v2

    if-ltz v0, :cond_0

    iget-object v2, p0, LC1/g;->a:LC1/j;

    invoke-virtual {p2}, LC1/d$c;->b()Lv1/n;

    move-result-object v4

    invoke-virtual {p2}, LC1/d$c;->a()Ljava/util/Map;

    move-result-object v5

    move-object v3, p1

    invoke-interface/range {v2 .. v7}, LC1/j;->a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V

    sget-object p0, Ly9/A;->a:Ly9/A;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_0

    :cond_0
    :try_start_1
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string p1, "Image size must be non-negative: "

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    monitor-exit v1

    throw p0
.end method
