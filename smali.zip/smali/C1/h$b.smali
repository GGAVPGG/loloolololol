.class public final LC1/h$b;
.super LN1/r;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LC1/h;-><init>(JLC1/k;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation


# instance fields
.field final synthetic d:LC1/h;


# direct methods
.method constructor <init>(JLC1/h;)V
    .locals 0

    iput-object p3, p0, LC1/h$b;->d:LC1/h;

    invoke-direct {p0, p1, p2}, LN1/r;-><init>(J)V

    return-void
.end method


# virtual methods
.method public bridge synthetic b(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    check-cast p1, LC1/d$b;

    check-cast p2, LC1/h$a;

    check-cast p3, LC1/h$a;

    invoke-virtual {p0, p1, p2, p3}, LC1/h$b;->l(LC1/d$b;LC1/h$a;LC1/h$a;)V

    return-void
.end method

.method public bridge synthetic j(Ljava/lang/Object;Ljava/lang/Object;)J
    .locals 0

    check-cast p1, LC1/d$b;

    check-cast p2, LC1/h$a;

    invoke-virtual {p0, p1, p2}, LC1/h$b;->m(LC1/d$b;LC1/h$a;)J

    move-result-wide p0

    return-wide p0
.end method

.method public l(LC1/d$b;LC1/h$a;LC1/h$a;)V
    .locals 6

    iget-object p0, p0, LC1/h$b;->d:LC1/h;

    invoke-static {p0}, LC1/h;->f(LC1/h;)LC1/k;

    move-result-object v0

    invoke-virtual {p2}, LC1/h$a;->b()Lv1/n;

    move-result-object v2

    invoke-virtual {p2}, LC1/h$a;->a()Ljava/util/Map;

    move-result-object v3

    invoke-virtual {p2}, LC1/h$a;->c()J

    move-result-wide v4

    move-object v1, p1

    invoke-interface/range {v0 .. v5}, LC1/k;->a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V

    return-void
.end method

.method public m(LC1/d$b;LC1/h$a;)J
    .locals 0

    invoke-virtual {p2}, LC1/h$a;->c()J

    move-result-wide p0

    return-wide p0
.end method
