.class public final LC1/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/j;


# instance fields
.field private final a:LC1/k;


# direct methods
.method public constructor <init>(LC1/k;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC1/a;->a:LC1/k;

    return-void
.end method


# virtual methods
.method public a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V
    .locals 0

    iget-object p0, p0, LC1/a;->a:LC1/k;

    invoke-interface/range {p0 .. p5}, LC1/k;->a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V

    return-void
.end method

.method public b(LC1/d$b;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public c()J
    .locals 2

    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public clear()V
    .locals 0

    return-void
.end method

.method public d(LC1/d$b;)LC1/d$c;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public e(J)V
    .locals 0

    return-void
.end method
