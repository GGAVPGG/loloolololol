.class public final LC1/e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC1/e$a;,
        LC1/e$b;
    }
.end annotation


# static fields
.field public static final c:LC1/e$a;


# instance fields
.field private final a:Lv1/r;

.field private final b:LH1/p;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LC1/e$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LC1/e$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LC1/e;->c:LC1/e$a;

    return-void
.end method

.method public constructor <init>(Lv1/r;LH1/p;LN1/q;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC1/e;->a:Lv1/r;

    iput-object p2, p0, LC1/e;->b:LH1/p;

    return-void
.end method

.method private final b(LC1/d$c;)Ljava/lang/String;
    .locals 0

    invoke-virtual {p1}, LC1/d$c;->a()Ljava/util/Map;

    move-result-object p0

    const-string p1, "coil#disk_cache_key"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_0

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method private final d(LH1/f;LC1/d$b;LC1/d$c;LI1/f;LI1/e;)Z
    .locals 13

    invoke-virtual {p2}, LC1/d$b;->a()Ljava/util/Map;

    move-result-object v0

    const-string v1, "coil#size"

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-virtual/range {p4 .. p4}, LI1/f;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    return v2

    :cond_0
    return v1

    :cond_1
    move-object/from16 v0, p3

    invoke-direct {p0, v0}, LC1/e;->e(LC1/d$c;)Z

    move-result p0

    if-nez p0, :cond_3

    invoke-static/range {p4 .. p4}, LI1/g;->b(LI1/f;)Z

    move-result p0

    if-nez p0, :cond_2

    invoke-virtual {p1}, LH1/f;->v()LI1/c;

    move-result-object p0

    sget-object v3, LI1/c;->g:LI1/c;

    if-ne p0, v3, :cond_3

    :cond_2
    return v2

    :cond_3
    invoke-virtual {v0}, LC1/d$c;->b()Lv1/n;

    move-result-object p0

    invoke-interface {p0}, Lv1/n;->b()I

    move-result p0

    invoke-virtual {v0}, LC1/d$c;->b()Lv1/n;

    move-result-object v3

    invoke-interface {v3}, Lv1/n;->a()I

    move-result v3

    invoke-virtual {v0}, LC1/d$c;->b()Lv1/n;

    move-result-object v0

    instance-of v0, v0, Lv1/a;

    if-eqz v0, :cond_4

    invoke-static {p1}, LH1/g;->b(LH1/f;)LI1/f;

    move-result-object v0

    goto :goto_0

    :cond_4
    sget-object v0, LI1/f;->d:LI1/f;

    :goto_0
    invoke-virtual/range {p4 .. p4}, LI1/f;->b()LI1/a;

    move-result-object v4

    instance-of v5, v4, LI1/a$a;

    const v6, 0x7fffffff

    if-eqz v5, :cond_5

    check-cast v4, LI1/a$a;

    invoke-virtual {v4}, LI1/a$a;->f()I

    move-result v4

    goto :goto_1

    :cond_5
    move v4, v6

    :goto_1
    invoke-virtual {v0}, LI1/f;->b()LI1/a;

    move-result-object v5

    instance-of v7, v5, LI1/a$a;

    if-eqz v7, :cond_6

    check-cast v5, LI1/a$a;

    invoke-virtual {v5}, LI1/a$a;->f()I

    move-result v5

    goto :goto_2

    :cond_6
    move v5, v6

    :goto_2
    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual/range {p4 .. p4}, LI1/f;->a()LI1/a;

    move-result-object v5

    instance-of v7, v5, LI1/a$a;

    if-eqz v7, :cond_7

    check-cast v5, LI1/a$a;

    invoke-virtual {v5}, LI1/a$a;->f()I

    move-result v5

    goto :goto_3

    :cond_7
    move v5, v6

    :goto_3
    invoke-virtual {v0}, LI1/f;->a()LI1/a;

    move-result-object v0

    instance-of v7, v0, LI1/a$a;

    if-eqz v7, :cond_8

    check-cast v0, LI1/a$a;

    invoke-virtual {v0}, LI1/a$a;->f()I

    move-result v0

    goto :goto_4

    :cond_8
    move v0, v6

    :goto_4
    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    int-to-double v7, v4

    int-to-double v9, p0

    div-double/2addr v7, v9

    int-to-double v9, v0

    int-to-double v11, v3

    div-double/2addr v9, v11

    if-eq v4, v6, :cond_9

    if-eq v0, v6, :cond_9

    move-object/from16 v5, p5

    goto :goto_5

    :cond_9
    sget-object v5, LI1/e;->g:LI1/e;

    :goto_5
    sget-object v6, LC1/e$b;->a:[I

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    aget v5, v6, v5

    const/4 v6, 0x2

    if-eq v5, v2, :cond_c

    if-ne v5, v6, :cond_b

    cmpg-double v5, v7, v9

    if-gez v5, :cond_a

    sub-int/2addr v4, p0

    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    move-result p0

    goto :goto_7

    :cond_a
    sub-int/2addr v0, v3

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result p0

    :goto_6
    move-wide v7, v9

    goto :goto_7

    :cond_b
    new-instance p0, Ly9/l;

    invoke-direct {p0}, Ly9/l;-><init>()V

    throw p0

    :cond_c
    cmpl-double v5, v7, v9

    if-lez v5, :cond_d

    sub-int/2addr v4, p0

    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    move-result p0

    goto :goto_7

    :cond_d
    sub-int/2addr v0, v3

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result p0

    goto :goto_6

    :goto_7
    if-gt p0, v2, :cond_e

    return v2

    :cond_e
    invoke-virtual {p1}, LH1/f;->v()LI1/c;

    move-result-object p0

    sget-object p1, LC1/e$b;->b:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, p1, p0

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    if-eq p0, v2, :cond_11

    if-ne p0, v6, :cond_10

    cmpg-double p0, v7, v3

    if-gtz p0, :cond_f

    return v2

    :cond_f
    return v1

    :cond_10
    new-instance p0, Ly9/l;

    invoke-direct {p0}, Ly9/l;-><init>()V

    throw p0

    :cond_11
    cmpg-double p0, v7, v3

    if-nez p0, :cond_12

    return v2

    :cond_12
    return v1
.end method

.method private final e(LC1/d$c;)Z
    .locals 0

    invoke-virtual {p1}, LC1/d$c;->a()Ljava/util/Map;

    move-result-object p0

    const-string p1, "coil#is_sampled"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/Boolean;

    if-eqz p1, :cond_0

    check-cast p0, Ljava/lang/Boolean;

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    :cond_1
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final a(LH1/f;LC1/d$b;LI1/f;LI1/e;)LC1/d$c;
    .locals 8

    invoke-virtual {p1}, LH1/f;->s()LH1/c;

    move-result-object v0

    invoke-virtual {v0}, LH1/c;->d()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    iget-object v0, p0, LC1/e;->a:Lv1/r;

    invoke-interface {v0}, Lv1/r;->d()LC1/d;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-interface {v0, p2}, LC1/d;->d(LC1/d$b;)LC1/d$c;

    move-result-object v0

    move-object v5, v0

    goto :goto_0

    :cond_1
    move-object v5, v1

    :goto_0
    if-eqz v5, :cond_2

    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move-object v6, p3

    move-object v7, p4

    invoke-virtual/range {v2 .. v7}, LC1/e;->c(LH1/f;LC1/d$b;LC1/d$c;LI1/f;LI1/e;)Z

    move-result p0

    if-eqz p0, :cond_2

    return-object v5

    :cond_2
    return-object v1
.end method

.method public final c(LH1/f;LC1/d$b;LC1/d$c;LI1/f;LI1/e;)Z
    .locals 6

    iget-object v0, p0, LC1/e;->b:LH1/p;

    invoke-interface {v0, p1, p3}, LH1/p;->d(LH1/f;LC1/d$c;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    invoke-direct/range {v0 .. v5}, LC1/e;->d(LH1/f;LC1/d$b;LC1/d$c;LI1/f;LI1/e;)Z

    move-result p0

    return p0
.end method

.method public final f(LH1/f;Ljava/lang/Object;LH1/n;Lv1/j;)LC1/d$b;
    .locals 1

    invoke-virtual {p1}, LH1/f;->q()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    new-instance p0, LC1/d$b;

    invoke-virtual {p1}, LH1/f;->q()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1}, LH1/f;->r()Ljava/util/Map;

    move-result-object p1

    invoke-direct {p0, p2, p1}, LC1/d$b;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    return-object p0

    :cond_0
    invoke-virtual {p4, p1, p2}, Lv1/j;->j(LH1/f;Ljava/lang/Object;)V

    iget-object p0, p0, LC1/e;->a:Lv1/r;

    invoke-interface {p0}, Lv1/r;->getComponents()Lv1/h;

    move-result-object p0

    invoke-virtual {p0, p2, p3}, Lv1/h;->j(Ljava/lang/Object;LH1/n;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p4, p1, p0}, Lv1/j;->i(LH1/f;Ljava/lang/String;)V

    if-nez p0, :cond_1

    const/4 p0, 0x0

    return-object p0

    :cond_1
    invoke-virtual {p1}, LH1/f;->r()Ljava/util/Map;

    move-result-object p2

    invoke-static {p2}, Lz9/L;->u(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p2

    invoke-static {p1}, LC1/f;->a(LH1/f;)Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {p3}, LH1/n;->k()LI1/f;

    move-result-object p1

    invoke-virtual {p1}, LI1/f;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p3, "coil#size"

    invoke-interface {p2, p3, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    new-instance p1, LC1/d$b;

    invoke-direct {p1, p0, p2}, LC1/d$b;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    return-object p1
.end method

.method public final g(Lz1/c$a;LH1/f;LC1/d$b;LC1/d$c;)LH1/r;
    .locals 8

    new-instance v0, LH1/r;

    invoke-virtual {p4}, LC1/d$c;->b()Lv1/n;

    move-result-object v1

    sget-object v3, Lw1/f;->f:Lw1/f;

    invoke-direct {p0, p4}, LC1/e;->b(LC1/d$c;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {p0, p4}, LC1/e;->e(LC1/d$c;)Z

    move-result v6

    invoke-static {p1}, LN1/C;->n(Lz1/c$a;)Z

    move-result v7

    move-object v2, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v7}, LH1/r;-><init>(Lv1/n;LH1/f;Lw1/f;LC1/d$b;Ljava/lang/String;ZZ)V

    return-object v0
.end method

.method public final h(LC1/d$b;LH1/f;Lz1/a$b;)Z
    .locals 2

    const/4 v0, 0x0

    if-eqz p1, :cond_3

    invoke-virtual {p2}, LH1/f;->s()LH1/c;

    move-result-object p2

    invoke-virtual {p2}, LH1/c;->h()Z

    move-result p2

    if-eqz p2, :cond_3

    invoke-virtual {p3}, Lz1/a$b;->e()Lv1/n;

    move-result-object p2

    invoke-interface {p2}, Lv1/n;->e()Z

    move-result p2

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, LC1/e;->a:Lv1/r;

    invoke-interface {p0}, Lv1/r;->d()LC1/d;

    move-result-object p0

    if-nez p0, :cond_1

    return v0

    :cond_1
    new-instance p2, Ljava/util/LinkedHashMap;

    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {p3}, Lz1/a$b;->f()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const-string v1, "coil#is_sampled"

    invoke-interface {p2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p3}, Lz1/a$b;->d()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_2

    const-string v1, "coil#disk_cache_key"

    invoke-interface {p2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    new-instance v0, LC1/d$c;

    invoke-virtual {p3}, Lz1/a$b;->e()Lv1/n;

    move-result-object p3

    invoke-direct {v0, p3, p2}, LC1/d$c;-><init>(Lv1/n;Ljava/util/Map;)V

    invoke-interface {p0, p1, v0}, LC1/d;->f(LC1/d$b;LC1/d$c;)V

    const/4 p0, 0x1

    return p0

    :cond_3
    :goto_0
    return v0
.end method
