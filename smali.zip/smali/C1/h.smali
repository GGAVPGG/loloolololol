.class public final LC1/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/j;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC1/h$a;
    }
.end annotation


# instance fields
.field private final a:LC1/k;

.field private final b:LC1/h$b;


# direct methods
.method public constructor <init>(JLC1/k;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, LC1/h;->a:LC1/k;

    new-instance p3, LC1/h$b;

    invoke-direct {p3, p1, p2, p0}, LC1/h$b;-><init>(JLC1/h;)V

    iput-object p3, p0, LC1/h;->b:LC1/h$b;

    return-void
.end method

.method public static final synthetic f(LC1/h;)LC1/k;
    .locals 0

    iget-object p0, p0, LC1/h;->a:LC1/k;

    return-object p0
.end method


# virtual methods
.method public a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V
    .locals 2

    invoke-virtual {p0}, LC1/h;->g()J

    move-result-wide v0

    cmp-long v0, p4, v0

    if-gtz v0, :cond_0

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    new-instance v0, LC1/h$a;

    invoke-direct {v0, p2, p3, p4, p5}, LC1/h$a;-><init>(Lv1/n;Ljava/util/Map;J)V

    invoke-virtual {p0, p1, v0}, LN1/r;->f(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_0
    iget-object v0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {v0, p1}, LN1/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, p0, LC1/h;->a:LC1/k;

    invoke-interface/range {p0 .. p5}, LC1/k;->a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V

    return-void
.end method

.method public b(LC1/d$b;)Z
    .locals 0

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {p0, p1}, LN1/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public c()J
    .locals 2

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {p0}, LN1/r;->e()J

    move-result-wide v0

    return-wide v0
.end method

.method public clear()V
    .locals 0

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {p0}, LN1/r;->a()V

    return-void
.end method

.method public d(LC1/d$b;)LC1/d$c;
    .locals 1

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {p0, p1}, LN1/r;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LC1/h$a;

    if-eqz p0, :cond_0

    new-instance p1, LC1/d$c;

    invoke-virtual {p0}, LC1/h$a;->b()Lv1/n;

    move-result-object v0

    invoke-virtual {p0}, LC1/h$a;->a()Ljava/util/Map;

    move-result-object p0

    invoke-direct {p1, v0, p0}, LC1/d$c;-><init>(Lv1/n;Ljava/util/Map;)V

    return-object p1

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public e(J)V
    .locals 0

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {p0, p1, p2}, LN1/r;->k(J)V

    return-void
.end method

.method public g()J
    .locals 2

    iget-object p0, p0, LC1/h;->b:LC1/h$b;

    invoke-virtual {p0}, LN1/r;->d()J

    move-result-wide v0

    return-wide v0
.end method
