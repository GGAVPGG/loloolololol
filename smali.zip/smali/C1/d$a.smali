.class public final LC1/d$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC1/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private a:LN9/a;

.field private b:Z

.field private c:Z


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, LC1/d$a;->b:Z

    iput-boolean v0, p0, LC1/d$a;->c:Z

    return-void
.end method

.method public static synthetic a(DLandroid/content/Context;)J
    .locals 0

    invoke-static {p0, p1, p2}, LC1/d$a;->e(DLandroid/content/Context;)J

    move-result-wide p0

    return-wide p0
.end method

.method public static synthetic d(LC1/d$a;Landroid/content/Context;DILjava/lang/Object;)LC1/d$a;
    .locals 0

    and-int/lit8 p4, p4, 0x2

    if-eqz p4, :cond_0

    invoke-static {p1}, LN1/d;->a(Landroid/content/Context;)D

    move-result-wide p2

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, LC1/d$a;->c(Landroid/content/Context;D)LC1/d$a;

    move-result-object p0

    return-object p0
.end method

.method private static final e(DLandroid/content/Context;)J
    .locals 2

    invoke-static {p2}, LN1/d;->g(Landroid/content/Context;)J

    move-result-wide v0

    long-to-double v0, v0

    mul-double/2addr p0, v0

    double-to-long p0, p0

    return-wide p0
.end method


# virtual methods
.method public final b()LC1/d;
    .locals 5

    iget-boolean v0, p0, LC1/d$a;->c:Z

    if-eqz v0, :cond_0

    new-instance v0, LC1/i;

    invoke-direct {v0}, LC1/i;-><init>()V

    goto :goto_0

    :cond_0
    new-instance v0, LC1/b;

    invoke-direct {v0}, LC1/b;-><init>()V

    :goto_0
    iget-boolean v1, p0, LC1/d$a;->b:Z

    if-eqz v1, :cond_3

    iget-object p0, p0, LC1/d$a;->a:LN9/a;

    if-eqz p0, :cond_2

    invoke-interface {p0}, LN9/a;->invoke()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long p0, v1, v3

    if-lez p0, :cond_1

    new-instance p0, LC1/h;

    invoke-direct {p0, v1, v2, v0}, LC1/h;-><init>(JLC1/k;)V

    goto :goto_1

    :cond_1
    new-instance p0, LC1/a;

    invoke-direct {p0, v0}, LC1/a;-><init>(LC1/k;)V

    goto :goto_1

    :cond_2
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "maxSizeBytesFactory == null"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, LC1/a;

    invoke-direct {p0, v0}, LC1/a;-><init>(LC1/k;)V

    :goto_1
    new-instance v1, LC1/g;

    invoke-direct {v1, p0, v0}, LC1/g;-><init>(LC1/j;LC1/k;)V

    return-object v1
.end method

.method public final c(Landroid/content/Context;D)LC1/d$a;
    .locals 2

    const-wide/16 v0, 0x0

    cmpg-double v0, v0, p2

    if-gtz v0, :cond_0

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    cmpg-double v0, p2, v0

    if-gtz v0, :cond_0

    new-instance v0, LC1/c;

    invoke-direct {v0, p2, p3, p1}, LC1/c;-><init>(DLandroid/content/Context;)V

    iput-object v0, p0, LC1/d$a;->a:LN9/a;

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "percent must be in the range [0.0, 1.0]."

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
