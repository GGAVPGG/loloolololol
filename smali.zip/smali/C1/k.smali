.class public interface abstract LC1/k;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V
.end method

.method public abstract b(LC1/d$b;)Z
.end method

.method public abstract clear()V
.end method

.method public abstract d(LC1/d$b;)LC1/d$c;
.end method
