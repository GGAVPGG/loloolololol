.class public abstract LC1/f;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static final a(LH1/f;)Z
    .locals 0

    invoke-static {p0}, LH1/h;->l(LH1/f;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method
