.class public final synthetic LC1/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LN9/a;


# instance fields
.field public final synthetic f:D

.field public final synthetic g:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(DLandroid/content/Context;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LC1/c;->f:D

    iput-object p3, p0, LC1/c;->g:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .locals 2

    iget-wide v0, p0, LC1/c;->f:D

    iget-object p0, p0, LC1/c;->g:Landroid/content/Context;

    invoke-static {v0, v1, p0}, LC1/d$a;->a(DLandroid/content/Context;)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0
.end method
