.class public final LC1/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LC1/k;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LC1/d$b;Lv1/n;Ljava/util/Map;J)V
    .locals 0

    return-void
.end method

.method public b(LC1/d$b;)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public clear()V
    .locals 0

    return-void
.end method

.method public d(LC1/d$b;)LC1/d$c;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method
