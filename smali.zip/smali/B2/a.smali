.class public final LB2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LA2/a;
.implements LA2/c$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LB2/a$a;
    }
.end annotation


# static fields
.field public static final r:LB2/a$a;

.field private static final s:Ljava/lang/Class;


# instance fields
.field private final a:LW2/d;

.field private final b:LB2/b;

.field private final c:LA2/d;

.field private final d:LB2/c;

.field private final e:Z

.field private final f:LD2/a;

.field private final g:LD2/b;

.field private final h:[F

.field private final i:Landroid/graphics/Bitmap$Config;

.field private final j:Landroid/graphics/Paint;

.field private k:Landroid/graphics/Rect;

.field private l:I

.field private m:I

.field private final n:Landroid/graphics/Path;

.field private final o:Landroid/graphics/Matrix;

.field private p:I

.field private q:LA2/a$a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LB2/a$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LB2/a$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LB2/a;->r:LB2/a$a;

    const-class v0, LB2/a;

    sput-object v0, LB2/a;->s:Ljava/lang/Class;

    return-void
.end method

.method public constructor <init>(LW2/d;LB2/b;LA2/d;LB2/c;ZLD2/a;LD2/b;LN2/d;)V
    .locals 0

    const-string p8, "platformBitmapFactory"

    invoke-static {p1, p8}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p8, "bitmapFrameCache"

    invoke-static {p2, p8}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p8, "animationInformation"

    invoke-static {p3, p8}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p8, "bitmapFrameRenderer"

    invoke-static {p4, p8}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB2/a;->a:LW2/d;

    iput-object p2, p0, LB2/a;->b:LB2/b;

    iput-object p3, p0, LB2/a;->c:LA2/d;

    iput-object p4, p0, LB2/a;->d:LB2/c;

    iput-boolean p5, p0, LB2/a;->e:Z

    iput-object p6, p0, LB2/a;->f:LD2/a;

    iput-object p7, p0, LB2/a;->g:LD2/b;

    const/4 p1, 0x0

    iput-object p1, p0, LB2/a;->h:[F

    sget-object p1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    iput-object p1, p0, LB2/a;->i:Landroid/graphics/Bitmap$Config;

    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x6

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, LB2/a;->j:Landroid/graphics/Paint;

    new-instance p1, Landroid/graphics/Path;

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    iput-object p1, p0, LB2/a;->n:Landroid/graphics/Path;

    new-instance p1, Landroid/graphics/Matrix;

    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    iput-object p1, p0, LB2/a;->o:Landroid/graphics/Matrix;

    const/4 p1, -0x1

    iput p1, p0, LB2/a;->p:I

    invoke-direct {p0}, LB2/a;->s()V

    return-void
.end method

.method private final o(ILandroid/graphics/Bitmap;Landroid/graphics/Canvas;)V
    .locals 3

    iget-object v0, p0, LB2/a;->k:Landroid/graphics/Rect;

    if-nez v0, :cond_0

    iget-object p0, p0, LB2/a;->j:Landroid/graphics/Paint;

    const/4 p1, 0x0

    invoke-virtual {p3, p2, p1, p1, p0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    return-void

    :cond_0
    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    invoke-direct {p0, p1, p2, v1, v2}, LB2/a;->t(ILandroid/graphics/Bitmap;FF)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, p0, LB2/a;->n:Landroid/graphics/Path;

    iget-object p0, p0, LB2/a;->j:Landroid/graphics/Paint;

    invoke-virtual {p3, p1, p0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void

    :cond_1
    const/4 p1, 0x0

    iget-object p0, p0, LB2/a;->j:Landroid/graphics/Paint;

    invoke-virtual {p3, p2, p1, v0, p0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    return-void
.end method

.method private final p(ILc2/a;Landroid/graphics/Canvas;I)Z
    .locals 2

    if-eqz p2, :cond_2

    invoke-static {p2}, Lc2/a;->c1(Lc2/a;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "get(...)"

    invoke-static {v0, v1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/graphics/Bitmap;

    invoke-direct {p0, p1, v0, p3}, LB2/a;->o(ILandroid/graphics/Bitmap;Landroid/graphics/Canvas;)V

    const/4 p3, 0x3

    if-eq p4, p3, :cond_1

    iget-boolean p3, p0, LB2/a;->e:Z

    if-nez p3, :cond_1

    iget-object p0, p0, LB2/a;->b:LB2/b;

    invoke-interface {p0, p1, p2, p4}, LB2/b;->y(ILc2/a;I)V

    :cond_1
    const/4 p0, 0x1

    return p0

    :cond_2
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method private final q(Landroid/graphics/Canvas;II)Z
    .locals 9

    const/4 v0, 0x0

    :try_start_0
    iget-boolean v1, p0, LB2/a;->e:Z

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_3

    iget-object p3, p0, LB2/a;->f:LD2/a;

    if-eqz p3, :cond_0

    invoke-virtual {p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result v1

    invoke-virtual {p1}, Landroid/graphics/Canvas;->getHeight()I

    move-result v4

    invoke-interface {p3, p2, v1, v4}, LD2/a;->c(III)Lc2/a;

    move-result-object p3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto/16 :goto_3

    :cond_0
    move-object p3, v0

    :goto_0
    if-eqz p3, :cond_1

    :try_start_1
    invoke-virtual {p3}, Lc2/a;->X0()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p3}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "get(...)"

    invoke-static {v0, v1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/graphics/Bitmap;

    invoke-direct {p0, p2, v0, p1}, LB2/a;->o(ILandroid/graphics/Bitmap;Landroid/graphics/Canvas;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    invoke-static {p3}, Lc2/a;->a0(Lc2/a;)V

    return v3

    :catchall_1
    move-exception p0

    move-object v0, p3

    goto/16 :goto_3

    :cond_1
    :try_start_2
    iget-object p0, p0, LB2/a;->f:LD2/a;

    if-eqz p0, :cond_2

    invoke-virtual {p1}, Landroid/graphics/Canvas;->getWidth()I

    move-result p2

    invoke-virtual {p1}, Landroid/graphics/Canvas;->getHeight()I

    move-result p1

    invoke-interface {p0, p2, p1, v0}, LD2/a;->b(IILN9/a;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_2
    invoke-static {p3}, Lc2/a;->a0(Lc2/a;)V

    return v2

    :cond_3
    const/4 v1, -0x1

    if-eqz p3, :cond_9

    const/4 v4, 0x2

    if-eq p3, v3, :cond_7

    const/4 v5, 0x3

    if-eq p3, v4, :cond_5

    if-eq p3, v5, :cond_4

    invoke-static {v0}, Lc2/a;->a0(Lc2/a;)V

    return v2

    :cond_4
    :try_start_3
    iget-object p3, p0, LB2/a;->b:LB2/b;

    invoke-interface {p3, p2}, LB2/b;->x(I)Lc2/a;

    move-result-object v0

    invoke-direct {p0, p2, v0, p1, v5}, LB2/a;->p(ILc2/a;Landroid/graphics/Canvas;I)Z

    move-result p3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    move v3, v1

    goto :goto_1

    :cond_5
    :try_start_4
    iget-object p3, p0, LB2/a;->a:LW2/d;

    iget v6, p0, LB2/a;->l:I

    iget v7, p0, LB2/a;->m:I

    iget-object v8, p0, LB2/a;->i:Landroid/graphics/Bitmap$Config;

    invoke-virtual {p3, v6, v7, v8}, LW2/d;->b(IILandroid/graphics/Bitmap$Config;)Lc2/a;

    move-result-object v0
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    invoke-direct {p0, p2, v0}, LB2/a;->r(ILc2/a;)Z

    move-result p3

    if-eqz p3, :cond_6

    invoke-direct {p0, p2, v0, p1, v4}, LB2/a;->p(ILc2/a;Landroid/graphics/Canvas;I)Z

    move-result p3

    if-eqz p3, :cond_6

    move v2, v3

    :cond_6
    move p3, v2

    move v3, v5

    goto :goto_1

    :catch_0
    move-exception p0

    sget-object p1, LB2/a;->s:Ljava/lang/Class;

    const-string p2, "Failed to create frame bitmap"

    invoke-static {p1, p2, p0}, LZ1/a;->F(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    invoke-static {v0}, Lc2/a;->a0(Lc2/a;)V

    return v2

    :cond_7
    :try_start_6
    iget-object p3, p0, LB2/a;->b:LB2/b;

    iget v5, p0, LB2/a;->l:I

    iget v6, p0, LB2/a;->m:I

    invoke-interface {p3, p2, v5, v6}, LB2/b;->u(III)Lc2/a;

    move-result-object v0

    invoke-direct {p0, p2, v0}, LB2/a;->r(ILc2/a;)Z

    move-result p3

    if-eqz p3, :cond_8

    invoke-direct {p0, p2, v0, p1, v3}, LB2/a;->p(ILc2/a;Landroid/graphics/Canvas;I)Z

    move-result p3

    if-eqz p3, :cond_8

    move v2, v3

    :cond_8
    move p3, v2

    move v3, v4

    goto :goto_1

    :cond_9
    iget-object p3, p0, LB2/a;->b:LB2/b;

    invoke-interface {p3, p2}, LB2/b;->w(I)Lc2/a;

    move-result-object v0

    invoke-direct {p0, p2, v0, p1, v2}, LB2/a;->p(ILc2/a;Landroid/graphics/Canvas;I)Z

    move-result p3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_1
    invoke-static {v0}, Lc2/a;->a0(Lc2/a;)V

    if-nez p3, :cond_b

    if-ne v3, v1, :cond_a

    goto :goto_2

    :cond_a
    invoke-direct {p0, p1, p2, v3}, LB2/a;->q(Landroid/graphics/Canvas;II)Z

    move-result p0

    return p0

    :cond_b
    :goto_2
    return p3

    :goto_3
    invoke-static {v0}, Lc2/a;->a0(Lc2/a;)V

    throw p0
.end method

.method private final r(ILc2/a;)Z
    .locals 2

    if-eqz p2, :cond_2

    invoke-virtual {p2}, Lc2/a;->X0()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, LB2/a;->d:LB2/c;

    invoke-virtual {p2}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v0

    const-string v1, "get(...)"

    invoke-static {v0, v1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v0, Landroid/graphics/Bitmap;

    invoke-interface {p0, p1, v0}, LB2/c;->c(ILandroid/graphics/Bitmap;)Z

    move-result p0

    if-nez p0, :cond_1

    invoke-static {p2}, Lc2/a;->a0(Lc2/a;)V

    :cond_1
    return p0

    :cond_2
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method private final s()V
    .locals 2

    iget-object v0, p0, LB2/a;->d:LB2/c;

    invoke-interface {v0}, LB2/c;->e()I

    move-result v0

    iput v0, p0, LB2/a;->l:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_1

    iget-object v0, p0, LB2/a;->k:Landroid/graphics/Rect;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iput v0, p0, LB2/a;->l:I

    :cond_1
    iget-object v0, p0, LB2/a;->d:LB2/c;

    invoke-interface {v0}, LB2/c;->a()I

    move-result v0

    iput v0, p0, LB2/a;->m:I

    if-ne v0, v1, :cond_3

    iget-object v0, p0, LB2/a;->k:Landroid/graphics/Rect;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v1

    :cond_2
    iput v1, p0, LB2/a;->m:I

    :cond_3
    return-void
.end method

.method private final t(ILandroid/graphics/Bitmap;FF)Z
    .locals 6

    iget-object v0, p0, LB2/a;->h:[F

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iget v0, p0, LB2/a;->p:I

    const/4 v1, 0x1

    if-ne p1, v0, :cond_1

    return v1

    :cond_1
    new-instance v0, Landroid/graphics/BitmapShader;

    sget-object v2, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct {v0, p2, v2, v2}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    new-instance p2, Landroid/graphics/RectF;

    iget v2, p0, LB2/a;->l:I

    int-to-float v2, v2

    iget v3, p0, LB2/a;->m:I

    int-to-float v3, v3

    const/4 v4, 0x0

    invoke-direct {p2, v4, v4, v2, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2, v4, v4, p3, p4}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v3, p0, LB2/a;->o:Landroid/graphics/Matrix;

    sget-object v5, Landroid/graphics/Matrix$ScaleToFit;->FILL:Landroid/graphics/Matrix$ScaleToFit;

    invoke-virtual {v3, p2, v2, v5}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    iget-object p2, p0, LB2/a;->o:Landroid/graphics/Matrix;

    invoke-virtual {v0, p2}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    iget-object p2, p0, LB2/a;->j:Landroid/graphics/Paint;

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    iget-object p2, p0, LB2/a;->n:Landroid/graphics/Path;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0, v4, v4, p3, p4}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object p3, p0, LB2/a;->h:[F

    sget-object p4, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {p2, v0, p3, p4}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;[FLandroid/graphics/Path$Direction;)V

    iput p1, p0, LB2/a;->p:I

    return v1
.end method


# virtual methods
.method public a()I
    .locals 0

    iget p0, p0, LB2/a;->m:I

    return p0
.end method

.method public b(Landroid/graphics/Rect;)V
    .locals 1

    iput-object p1, p0, LB2/a;->k:Landroid/graphics/Rect;

    iget-object v0, p0, LB2/a;->d:LB2/c;

    invoke-interface {v0, p1}, LB2/c;->b(Landroid/graphics/Rect;)V

    invoke-direct {p0}, LB2/a;->s()V

    return-void
.end method

.method public c()I
    .locals 0

    iget-object p0, p0, LB2/a;->c:LA2/d;

    invoke-interface {p0}, LA2/d;->c()I

    move-result p0

    return p0
.end method

.method public clear()V
    .locals 1

    iget-boolean v0, p0, LB2/a;->e:Z

    if-eqz v0, :cond_1

    iget-object p0, p0, LB2/a;->f:LD2/a;

    if-eqz p0, :cond_0

    invoke-interface {p0}, LD2/a;->d()V

    :cond_0
    return-void

    :cond_1
    iget-object p0, p0, LB2/a;->b:LB2/b;

    invoke-interface {p0}, LB2/b;->clear()V

    return-void
.end method

.method public d()I
    .locals 0

    iget-object p0, p0, LB2/a;->c:LA2/d;

    invoke-interface {p0}, LA2/d;->d()I

    move-result p0

    return p0
.end method

.method public e()I
    .locals 0

    iget p0, p0, LB2/a;->l:I

    return p0
.end method

.method public f()V
    .locals 1

    iget-boolean v0, p0, LB2/a;->e:Z

    if-eqz v0, :cond_1

    iget-object p0, p0, LB2/a;->f:LD2/a;

    if-eqz p0, :cond_0

    invoke-interface {p0}, LD2/a;->a()V

    :cond_0
    return-void

    :cond_1
    invoke-virtual {p0}, LB2/a;->clear()V

    return-void
.end method

.method public g(LA2/a$a;)V
    .locals 0

    iput-object p1, p0, LB2/a;->q:LA2/a$a;

    return-void
.end method

.method public h(Landroid/graphics/ColorFilter;)V
    .locals 0

    iget-object p0, p0, LB2/a;->j:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method

.method public i()I
    .locals 0

    iget-object p0, p0, LB2/a;->c:LA2/d;

    invoke-interface {p0}, LA2/d;->i()I

    move-result p0

    return p0
.end method

.method public j()I
    .locals 0

    iget-object p0, p0, LB2/a;->c:LA2/d;

    invoke-interface {p0}, LA2/d;->j()I

    move-result p0

    return p0
.end method

.method public k(I)I
    .locals 0

    iget-object p0, p0, LB2/a;->c:LA2/d;

    invoke-interface {p0, p1}, LA2/d;->k(I)I

    move-result p0

    return p0
.end method

.method public l(I)V
    .locals 0

    iget-object p0, p0, LB2/a;->j:Landroid/graphics/Paint;

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public m()I
    .locals 0

    iget-object p0, p0, LB2/a;->c:LA2/d;

    invoke-interface {p0}, LA2/d;->m()I

    move-result p0

    return p0
.end method

.method public n(Landroid/graphics/drawable/Drawable;Landroid/graphics/Canvas;I)Z
    .locals 8

    const-string v0, "parent"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p1, "canvas"

    invoke-static {p2, p1}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p1, 0x0

    invoke-direct {p0, p2, p3, p1}, LB2/a;->q(Landroid/graphics/Canvas;II)Z

    move-result p1

    iget-boolean p2, p0, LB2/a;->e:Z

    if-nez p2, :cond_0

    iget-object v1, p0, LB2/a;->g:LD2/b;

    if-eqz v1, :cond_0

    iget-object v0, p0, LB2/a;->f:LD2/a;

    if-eqz v0, :cond_0

    iget-object v2, p0, LB2/a;->b:LB2/b;

    const/16 v6, 0x10

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v3, p0

    move v4, p3

    invoke-static/range {v0 .. v7}, LD2/a$a;->f(LD2/a;LD2/b;LB2/b;LA2/a;ILN9/a;ILjava/lang/Object;)V

    :cond_0
    return p1
.end method
