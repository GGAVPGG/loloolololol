.class public interface abstract LB2/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract clear()V
.end method

.method public abstract t(I)Z
.end method

.method public abstract u(III)Lc2/a;
.end method

.method public abstract v(ILc2/a;I)V
.end method

.method public abstract w(I)Lc2/a;
.end method

.method public abstract x(I)Lc2/a;
.end method

.method public abstract y(ILc2/a;I)V
.end method
