.class public final LE2/c;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:I


# direct methods
.method public constructor <init>(I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LE2/c;->a:I

    return-void
.end method


# virtual methods
.method public final a(III)Ljava/util/Map;
    .locals 3

    const/4 v0, 0x1

    invoke-static {p3, v0}, LU9/g;->d(II)I

    move-result p3

    iget v0, p0, LE2/c;->a:I

    invoke-static {p3, v0}, LU9/g;->h(II)I

    move-result p3

    int-to-float p3, p3

    invoke-virtual {p0, p1}, LE2/c;->b(I)F

    move-result p0

    mul-float/2addr p3, p0

    const/4 p0, 0x0

    invoke-static {p3, p0}, LU9/g;->c(FF)F

    move-result p0

    int-to-float p1, p2

    invoke-static {p0, p1}, LU9/g;->g(FF)F

    move-result p0

    div-float/2addr p1, p0

    const/4 p0, 0x0

    invoke-static {p0, p2}, LU9/g;->p(II)LU9/c;

    move-result-object p2

    new-instance p3, Ljava/util/LinkedHashMap;

    const/16 v0, 0xa

    invoke-static {p2, v0}, Lz9/q;->v(Ljava/lang/Iterable;I)I

    move-result v0

    invoke-static {v0}, Lz9/L;->d(I)I

    move-result v0

    const/16 v1, 0x10

    invoke-static {v0, v1}, LU9/g;->d(II)I

    move-result v0

    invoke-direct {p3, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    int-to-float v2, v1

    rem-float/2addr v2, p1

    float-to-int v2, v2

    if-nez v2, :cond_0

    move p0, v1

    :cond_0
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p3, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    return-object p3
.end method

.method public final b(I)F
    .locals 0

    int-to-float p0, p1

    const/high16 p1, 0x447a0000    # 1000.0f

    div-float/2addr p0, p1

    return p0
.end method
