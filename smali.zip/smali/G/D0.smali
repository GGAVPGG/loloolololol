.class public interface abstract LG/D0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/e1;


# static fields
.field public static final j:LG/j0$a;

.field public static final k:LG/j0$a;

.field public static final l:LG/j0$a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "camerax.core.imageInput.inputFormat"

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/D0;->j:LG/j0$a;

    const-string v0, "camerax.core.imageInput.secondaryInputFormat"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/D0;->k:LG/j0$a;

    const-string v0, "camerax.core.imageInput.inputDynamicRange"

    const-class v1, Lz/H;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/D0;->l:LG/j0$a;

    return-void
.end method


# virtual methods
.method public L()I
    .locals 2

    sget-object v0, LG/D0;->k:LG/j0$a;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public m()Lz/H;
    .locals 2

    sget-object v0, LG/D0;->l:LG/j0$a;

    sget-object v1, Lz/H;->c:Lz/H;

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lz/H;

    invoke-static {p0}, LI0/g;->g(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lz/H;

    return-object p0
.end method

.method public t()I
    .locals 1

    sget-object v0, LG/D0;->j:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public w()Z
    .locals 1

    sget-object v0, LG/D0;->l:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    return p0
.end method
