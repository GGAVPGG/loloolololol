.class public interface abstract LG/B1;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LG/B1$c;,
        LG/B1$b;
    }
.end annotation


# static fields
.field public static final a:LG/B1;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LG/B1$a;

    invoke-direct {v0}, LG/B1$a;-><init>()V

    sput-object v0, LG/B1;->a:LG/B1;

    return-void
.end method


# virtual methods
.method public abstract a(LG/B1$b;I)LG/j0;
.end method
