.class public abstract LG/C;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Lz/Y;)LG/B;
    .locals 1

    instance-of v0, p0, LL/c;

    if-eqz v0, :cond_0

    check-cast p0, LL/c;

    invoke-virtual {p0}, LL/c;->f()LG/B;

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method
