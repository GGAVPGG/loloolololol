.class LG/A1$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF/Y$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = LG/A1;->v()LF/Y$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:LG/A1;


# direct methods
.method constructor <init>(LG/A1;)V
    .locals 0

    iput-object p1, p0, LG/A1$a;->a:LG/A1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LF/y;)LF/Y;
    .locals 0

    new-instance p0, LF/c0;

    invoke-direct {p0, p1}, LF/c0;-><init>(LF/y;)V

    return-object p0
.end method
