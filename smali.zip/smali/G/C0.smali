.class public final LG/C0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/A1;
.implements LG/E0;
.implements LL/i;


# static fields
.field public static final Q:LG/j0$a;

.field public static final R:LG/j0$a;

.field public static final S:LG/j0$a;

.field public static final T:LG/j0$a;

.field public static final U:LG/j0$a;

.field public static final V:LG/j0$a;

.field public static final W:LG/j0$a;

.field public static final X:LG/j0$a;

.field public static final Y:LG/j0$a;

.field public static final Z:LG/j0$a;

.field public static final a0:LG/j0$a;

.field public static final b0:LG/j0$a;

.field public static final c0:LG/j0$a;


# instance fields
.field private final P:LG/V0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const-string v0, "camerax.core.imageCapture.captureMode"

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->Q:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.flashMode"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->R:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.captureBundle"

    const-class v2, LG/g0;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->S:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.bufferFormat"

    const-class v2, Ljava/lang/Integer;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->T:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.outputFormat"

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->U:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.maxCaptureStages"

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->V:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.imageReaderProxyProvider"

    const-class v2, Lz/d0;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->W:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.useSoftwareJpegEncoder"

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->X:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.flashType"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->Y:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.jpegCompressionQuality"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->Z:LG/j0$a;

    const-string v0, "camerax.core.imageCapture.screenFlash"

    const-class v1, Lz/V$i;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->a0:LG/j0$a;

    const-string v0, "camerax.core.useCase.postviewResolutionSelector"

    const-class v1, LT/c;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->b0:LG/j0$a;

    const-string v0, "camerax.core.useCase.isPostviewEnabled"

    const-class v1, Ljava/lang/Boolean;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/C0;->c0:LG/j0$a;

    return-void
.end method

.method public constructor <init>(LG/V0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LG/C0;->P:LG/V0;

    return-void
.end method


# virtual methods
.method public f0(LG/g0;)LG/g0;
    .locals 1

    sget-object v0, LG/C0;->S:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/g0;

    return-object p0
.end method

.method public g0()I
    .locals 1

    sget-object v0, LG/C0;->Q:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public h0(I)I
    .locals 1

    sget-object v0, LG/C0;->R:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public i0(I)I
    .locals 1

    sget-object v0, LG/C0;->Y:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public j0()Lz/d0;
    .locals 2

    sget-object v0, LG/C0;->W:LG/j0$a;

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroid/support/v4/media/session/b;->a(Ljava/lang/Object;)V

    return-object v1
.end method

.method public k0(Ljava/util/concurrent/Executor;)Ljava/util/concurrent/Executor;
    .locals 1

    sget-object v0, LL/i;->L:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/concurrent/Executor;

    return-object p0
.end method

.method public l0()I
    .locals 1

    sget-object v0, LG/C0;->Z:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public m0()Lz/V$i;
    .locals 2

    sget-object v0, LG/C0;->a0:LG/j0$a;

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lz/V$i;

    return-object p0
.end method

.method public n0()Z
    .locals 1

    sget-object v0, LG/C0;->Q:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    return p0
.end method

.method public q()LG/j0;
    .locals 0

    iget-object p0, p0, LG/C0;->P:LG/V0;

    return-object p0
.end method

.method public t()I
    .locals 1

    sget-object v0, LG/D0;->j:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method
