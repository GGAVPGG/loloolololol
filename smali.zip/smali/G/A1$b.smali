.class public interface abstract LG/A1$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lz/I;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LG/A1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "b"
.end annotation


# virtual methods
.method public abstract c()LG/A1;
.end method
