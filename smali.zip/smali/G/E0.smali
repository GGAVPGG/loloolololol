.class public interface abstract LG/E0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/e1;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LG/E0$a;
    }
.end annotation


# static fields
.field public static final m:LG/j0$a;

.field public static final n:LG/j0$a;

.field public static final o:LG/j0$a;

.field public static final p:LG/j0$a;

.field public static final q:LG/j0$a;

.field public static final r:LG/j0$a;

.field public static final s:LG/j0$a;

.field public static final t:LG/j0$a;

.field public static final u:LG/j0$a;

.field public static final v:LG/j0$a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const-string v0, "camerax.core.imageOutput.targetAspectRatio"

    const-class v1, Lz/a;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->m:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.targetRotation"

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->n:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.appTargetRotation"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->o:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.mirrorMode"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->p:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.targetResolution"

    const-class v1, Landroid/util/Size;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->q:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.defaultResolution"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->r:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.maxResolution"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->s:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.supportedResolutions"

    const-class v1, Ljava/util/List;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->t:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.resolutionSelector"

    const-class v2, LT/c;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->u:LG/j0$a;

    const-string v0, "camerax.core.imageOutput.customOrderedResolutions"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E0;->v:LG/j0$a;

    return-void
.end method

.method public static S(LG/E0;)V
    .locals 3

    invoke-interface {p0}, LG/E0;->P()Z

    move-result v0

    const/4 v1, 0x0

    invoke-interface {p0, v1}, LG/E0;->C(Landroid/util/Size;)Landroid/util/Size;

    move-result-object v2

    if-eqz v2, :cond_0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    if-eqz v0, :cond_2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    :goto_1
    invoke-interface {p0, v1}, LG/E0;->u(LT/c;)LT/c;

    move-result-object p0

    if-eqz p0, :cond_4

    if-nez v0, :cond_3

    if-nez v2, :cond_3

    goto :goto_2

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Cannot use setTargetResolution or setTargetAspectRatio with setResolutionSelector on the same config."

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    :goto_2
    return-void
.end method


# virtual methods
.method public C(Landroid/util/Size;)Landroid/util/Size;
    .locals 1

    sget-object v0, LG/E0;->q:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/util/Size;

    return-object p0
.end method

.method public D(I)I
    .locals 1

    sget-object v0, LG/E0;->o:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public P()Z
    .locals 1

    sget-object v0, LG/E0;->m:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    return p0
.end method

.method public R()I
    .locals 1

    sget-object v0, LG/E0;->m:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public c0(I)I
    .locals 1

    sget-object v0, LG/E0;->n:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public d0(I)I
    .locals 1

    sget-object v0, LG/E0;->p:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public i(Landroid/util/Size;)Landroid/util/Size;
    .locals 1

    sget-object v0, LG/E0;->s:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/util/Size;

    return-object p0
.end method

.method public n(Ljava/util/List;)Ljava/util/List;
    .locals 1

    sget-object v0, LG/E0;->t:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    return-object p0
.end method

.method public p()LT/c;
    .locals 1

    sget-object v0, LG/E0;->u:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LT/c;

    return-object p0
.end method

.method public r(Ljava/util/List;)Ljava/util/List;
    .locals 1

    sget-object v0, LG/E0;->v:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    if-eqz p0, :cond_0

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    return-object p1

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public u(LT/c;)LT/c;
    .locals 1

    sget-object v0, LG/E0;->u:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LT/c;

    return-object p0
.end method

.method public y(Landroid/util/Size;)Landroid/util/Size;
    .locals 1

    sget-object v0, LG/E0;->r:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/util/Size;

    return-object p0
.end method
