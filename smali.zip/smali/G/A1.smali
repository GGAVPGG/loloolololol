.class public interface abstract LG/A1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LL/q;
.implements LG/D0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LG/A1$b;
    }
.end annotation


# static fields
.field public static final A:LG/j0$a;

.field public static final B:LG/j0$a;

.field public static final C:LG/j0$a;

.field public static final D:LG/j0$a;

.field public static final E:LG/j0$a;

.field public static final F:LG/j0$a;

.field public static final G:LG/j0$a;

.field public static final H:LG/j0$a;

.field public static final I:LG/j0$a;

.field public static final J:LG/j0$a;

.field public static final K:LG/j0$a;

.field public static final w:LG/j0$a;

.field public static final x:LG/j0$a;

.field public static final y:LG/j0$a;

.field public static final z:LG/j0$a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const-string v0, "camerax.core.useCase.defaultSessionConfig"

    const-class v1, LG/h1;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->w:LG/j0$a;

    const-string v0, "camerax.core.useCase.defaultCaptureConfig"

    const-class v1, LG/h0;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->x:LG/j0$a;

    const-string v0, "camerax.core.useCase.sessionConfigUnpacker"

    const-class v1, LG/h1$e;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->y:LG/j0$a;

    const-string v0, "camerax.core.useCase.captureConfigUnpacker"

    const-class v1, LG/h0$b;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->z:LG/j0$a;

    const-string v0, "camerax.core.useCase.surfaceOccupancyPriority"

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->A:LG/j0$a;

    const-string v0, "camerax.core.useCase.sessionType"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->B:LG/j0$a;

    const-string v0, "camerax.core.useCase.targetFrameRate"

    const-class v2, Landroid/util/Range;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->C:LG/j0$a;

    const-string v0, "camerax.core.useCase.isStrictFrameRateRequired"

    const-class v2, Ljava/lang/Boolean;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->D:LG/j0$a;

    const-string v0, "camerax.core.useCase.zslDisabled"

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->E:LG/j0$a;

    const-string v0, "camerax.core.useCase.highResolutionDisabled"

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->F:LG/j0$a;

    const-string v0, "camerax.core.useCase.captureType"

    const-class v2, LG/B1$b;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->G:LG/j0$a;

    const-string v0, "camerax.core.useCase.previewStabilizationMode"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->H:LG/j0$a;

    const-string v0, "camerax.core.useCase.videoStabilizationMode"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->I:LG/j0$a;

    const-string v0, "camerax.core.useCase.takePictureManagerProvider"

    const-class v1, LF/Y$b;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->J:LG/j0$a;

    const-string v0, "camerax.core.useCase.streamUseCase"

    const-class v1, LG/m1;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/A1;->K:LG/j0$a;

    return-void
.end method


# virtual methods
.method public A(Z)Z
    .locals 1

    sget-object v0, LG/A1;->E:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public I()LG/m1;
    .locals 2

    sget-object v0, LG/A1;->K:LG/j0$a;

    sget-object v1, LG/m1;->g:LG/m1;

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/m1;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p0
.end method

.method public J()LG/B1$b;
    .locals 1

    sget-object v0, LG/A1;->G:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/B1$b;

    return-object p0
.end method

.method public K()I
    .locals 2

    sget-object v0, LG/A1;->I:LG/j0$a;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public M(Landroid/util/Range;)Landroid/util/Range;
    .locals 1

    sget-object v0, LG/A1;->C:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/util/Range;

    return-object p0
.end method

.method public Q(I)I
    .locals 1

    sget-object v0, LG/A1;->A:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public T()I
    .locals 2

    sget-object v0, LG/A1;->H:LG/j0$a;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public V()Z
    .locals 2

    sget-object v0, LG/A1;->D:LG/j0$a;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public Y(Z)Z
    .locals 1

    sget-object v0, LG/A1;->F:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public Z(LG/h1;)LG/h1;
    .locals 1

    sget-object v0, LG/A1;->w:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/h1;

    return-object p0
.end method

.method public b0()Z
    .locals 1

    sget-object v0, LG/A1;->C:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->g(LG/j0$a;)Z

    move-result p0

    return p0
.end method

.method public e0(LG/h0;)LG/h0;
    .locals 1

    sget-object v0, LG/A1;->x:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/h0;

    return-object p0
.end method

.method public o(LG/h0$b;)LG/h0$b;
    .locals 1

    sget-object v0, LG/A1;->z:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/h0$b;

    return-object p0
.end method

.method public s(I)I
    .locals 1

    sget-object v0, LG/A1;->B:LG/j0$a;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public v()LF/Y$b;
    .locals 2

    sget-object v0, LG/A1;->J:LG/j0$a;

    new-instance v1, LG/A1$a;

    invoke-direct {v1, p0}, LG/A1$a;-><init>(LG/A1;)V

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LF/Y$b;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p0, LF/Y$b;

    return-object p0
.end method

.method public x(LG/h1$e;)LG/h1$e;
    .locals 1

    sget-object v0, LG/A1;->y:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/h1$e;

    return-object p0
.end method

.method public z()LG/h1;
    .locals 1

    sget-object v0, LG/A1;->w:LG/j0$a;

    invoke-interface {p0, v0}, LG/e1;->a(LG/j0$a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/h1;

    return-object p0
.end method
