.class public final synthetic LG/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/E$a;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
