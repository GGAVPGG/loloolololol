.class public final enum LG/A;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum f:LG/A;

.field public static final enum g:LG/A;

.field public static final enum h:LG/A;

.field public static final enum i:LG/A;

.field private static final synthetic j:[LG/A;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, LG/A;

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, LG/A;-><init>(Ljava/lang/String;I)V

    sput-object v0, LG/A;->f:LG/A;

    new-instance v0, LG/A;

    const-string v1, "NONE"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, LG/A;-><init>(Ljava/lang/String;I)V

    sput-object v0, LG/A;->g:LG/A;

    new-instance v0, LG/A;

    const-string v1, "READY"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, LG/A;-><init>(Ljava/lang/String;I)V

    sput-object v0, LG/A;->h:LG/A;

    new-instance v0, LG/A;

    const-string v1, "FIRED"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, LG/A;-><init>(Ljava/lang/String;I)V

    sput-object v0, LG/A;->i:LG/A;

    invoke-static {}, LG/A;->c()[LG/A;

    move-result-object v0

    sput-object v0, LG/A;->j:[LG/A;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static synthetic c()[LG/A;
    .locals 4

    sget-object v0, LG/A;->f:LG/A;

    sget-object v1, LG/A;->g:LG/A;

    sget-object v2, LG/A;->h:LG/A;

    sget-object v3, LG/A;->i:LG/A;

    filled-new-array {v0, v1, v2, v3}, [LG/A;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LG/A;
    .locals 1

    const-class v0, LG/A;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LG/A;

    return-object p0
.end method

.method public static values()[LG/A;
    .locals 1

    sget-object v0, LG/A;->j:[LG/A;

    invoke-virtual {v0}, [LG/A;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LG/A;

    return-object v0
.end method


# virtual methods
.method public d()I
    .locals 3

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eq p0, v1, :cond_2

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    if-eq p0, v2, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    return v1

    :cond_1
    return v2

    :cond_2
    return v0
.end method
