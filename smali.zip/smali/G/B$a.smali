.class public final LG/B$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/B;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LG/B;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static l()LG/B;
    .locals 1

    new-instance v0, LG/B$a;

    invoke-direct {v0}, LG/B$a;-><init>()V

    return-object v0
.end method


# virtual methods
.method public a()J
    .locals 2

    const-wide/16 v0, -0x1

    return-wide v0
.end method

.method public b()LG/r1;
    .locals 0

    invoke-static {}, LG/r1;->b()LG/r1;

    move-result-object p0

    return-object p0
.end method

.method public c()LG/A;
    .locals 0

    sget-object p0, LG/A;->f:LG/A;

    return-object p0
.end method

.method public e()LG/z;
    .locals 0

    sget-object p0, LG/z;->f:LG/z;

    return-object p0
.end method

.method public f()LG/y;
    .locals 0

    sget-object p0, LG/y;->f:LG/y;

    return-object p0
.end method

.method public g()LG/w;
    .locals 0

    sget-object p0, LG/w;->f:LG/w;

    return-object p0
.end method

.method public h()LG/v;
    .locals 0

    sget-object p0, LG/v;->f:LG/v;

    return-object p0
.end method

.method public i()Landroid/hardware/camera2/CaptureResult;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public j()LG/u;
    .locals 0

    sget-object p0, LG/u;->f:LG/u;

    return-object p0
.end method

.method public k()LG/x;
    .locals 0

    sget-object p0, LG/x;->f:LG/x;

    return-object p0
.end method
