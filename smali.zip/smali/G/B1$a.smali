.class LG/B1$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/B1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LG/B1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(LG/B1$b;I)LG/j0;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method
