.class public interface abstract LG/B;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LG/B$a;
    }
.end annotation


# virtual methods
.method public abstract a()J
.end method

.method public abstract b()LG/r1;
.end method

.method public abstract c()LG/A;
.end method

.method public d(LI/i$b;)V
    .locals 0

    invoke-interface {p0}, LG/B;->c()LG/A;

    move-result-object p0

    invoke-virtual {p1, p0}, LI/i$b;->g(LG/A;)LI/i$b;

    return-void
.end method

.method public abstract e()LG/z;
.end method

.method public abstract f()LG/y;
.end method

.method public abstract g()LG/w;
.end method

.method public abstract h()LG/v;
.end method

.method public i()Landroid/hardware/camera2/CaptureResult;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public abstract j()LG/u;
.end method

.method public abstract k()LG/x;
.end method
