.class public interface abstract LG/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LG/e1;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LG/E$a;
    }
.end annotation


# static fields
.field public static final a:LG/j0$a;

.field public static final b:LG/j0$a;

.field public static final c:LG/j0$a;

.field public static final d:LG/j0$a;

.field public static final e:LG/j0$a;

.field public static final f:LG/j0$a;

.field public static final g:LG/j0$a;

.field public static final h:LG/j0$a;

.field public static final i:LG/E$a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const-string v0, "camerax.core.camera.useCaseConfigFactory"

    const-class v1, LG/B1;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->a:LG/j0$a;

    const-string v0, "camerax.core.camera.compatibilityId"

    const-class v1, LG/A0;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->b:LG/j0$a;

    const-string v0, "camerax.core.camera.useCaseCombinationRequiredRule"

    const-class v1, Ljava/lang/Integer;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->c:LG/j0$a;

    const-string v0, "camerax.core.camera.SessionProcessor"

    const-class v1, LG/j1;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->d:LG/j0$a;

    const-string v0, "camerax.core.camera.isZslDisabled"

    const-class v1, Ljava/lang/Boolean;

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->e:LG/j0$a;

    const-string v0, "camerax.core.camera.isPostviewSupported"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->f:LG/j0$a;

    const-string v0, "camerax.core.camera.PostviewFormatSelector"

    const-class v2, LG/E$a;

    invoke-static {v0, v2}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->g:LG/j0$a;

    const-string v0, "camerax.core.camera.isCaptureProcessProgressSupported"

    invoke-static {v0, v1}, LG/j0$a;->a(Ljava/lang/String;Ljava/lang/Class;)LG/j0$a;

    move-result-object v0

    sput-object v0, LG/E;->h:LG/j0$a;

    new-instance v0, LG/D;

    invoke-direct {v0}, LG/D;-><init>()V

    sput-object v0, LG/E;->i:LG/E$a;

    return-void
.end method


# virtual methods
.method public B()Z
    .locals 2

    sget-object v0, LG/E;->f:LG/j0$a;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public G()I
    .locals 2

    sget-object v0, LG/E;->c:LG/j0$a;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0
.end method

.method public abstract W()LG/A0;
.end method

.method public X()Z
    .locals 2

    sget-object v0, LG/E;->h:LG/j0$a;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0
.end method

.method public j()LG/B1;
    .locals 2

    sget-object v0, LG/E;->a:LG/j0$a;

    sget-object v1, LG/B1;->a:LG/B1;

    invoke-interface {p0, v0, v1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, LG/B1;

    return-object p0
.end method

.method public k(LG/j1;)LG/j1;
    .locals 1

    sget-object v0, LG/E;->d:LG/j0$a;

    invoke-interface {p0, v0, p1}, LG/e1;->e(LG/j0$a;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Landroid/support/v4/media/session/b;->a(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method
