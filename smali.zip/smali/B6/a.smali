.class public interface abstract LB6/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;
.implements Landroidx/lifecycle/o;
.implements LN4/i;


# virtual methods
.method public abstract close()V
    .annotation runtime Landroidx/lifecycle/z;
        value = .enum Landroidx/lifecycle/i$a;->ON_DESTROY:Landroidx/lifecycle/i$a;
    .end annotation
.end method

.method public abstract t1(LH6/a;)Lv5/l;
.end method
