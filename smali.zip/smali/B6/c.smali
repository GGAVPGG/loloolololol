.class public abstract LB6/c;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(LB6/b;)LB6/a;
    .locals 2

    const-string v0, "You must provide a valid BarcodeScannerOptions."

    invoke-static {p0, v0}, LP4/p;->l(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Lz6/i;->c()Lz6/i;

    move-result-object v0

    const-class v1, LE6/f;

    invoke-virtual {v0, v1}, Lz6/i;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LE6/f;

    invoke-virtual {v0, p0}, LE6/f;->a(LB6/b;)LE6/g;

    move-result-object p0

    return-object p0
.end method
