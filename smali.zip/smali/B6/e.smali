.class public abstract synthetic LB6/e;
.super Ljava/lang/Object;
.source "SourceFile"
