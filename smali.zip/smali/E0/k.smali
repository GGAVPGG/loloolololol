.class public abstract LE0/k;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LE0/k$a;
    }
.end annotation


# direct methods
.method public static a(Landroid/content/Context;)Z
    .locals 0

    invoke-static {p0}, LE0/k$a;->a(Landroid/content/Context;)Z

    move-result p0

    return p0
.end method
