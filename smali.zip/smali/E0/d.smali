.class public abstract LE0/d;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LE0/d$a;
    }
.end annotation


# direct methods
.method public static a(Landroid/content/res/Configuration;)LE0/f;
    .locals 0

    invoke-static {p0}, LE0/d$a;->a(Landroid/content/res/Configuration;)Landroid/os/LocaleList;

    move-result-object p0

    invoke-static {p0}, LE0/f;->i(Landroid/os/LocaleList;)LE0/f;

    move-result-object p0

    return-object p0
.end method
