.class public final LF2/k;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF2/k$a;
    }
.end annotation


# static fields
.field public static final d:LF2/k$a;

.field private static final e:Ljava/util/concurrent/ConcurrentHashMap;


# instance fields
.field private final a:LW2/d;

.field private final b:I

.field private final c:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LF2/k$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LF2/k$a;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LF2/k;->d:LF2/k$a;

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, LF2/k;->e:Ljava/util/concurrent/ConcurrentHashMap;

    return-void
.end method

.method public constructor <init>(LW2/d;II)V
    .locals 1

    const-string v0, "platformBitmapFactory"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF2/k;->a:LW2/d;

    iput p2, p0, LF2/k;->b:I

    iput p3, p0, LF2/k;->c:I

    return-void
.end method

.method public static final synthetic a()Ljava/util/concurrent/ConcurrentHashMap;
    .locals 1

    sget-object v0, LF2/k;->e:Ljava/util/concurrent/ConcurrentHashMap;

    return-object v0
.end method


# virtual methods
.method public final b(Ljava/lang/String;LB2/c;LA2/d;)LF2/j;
    .locals 8

    const-string v0, "cacheKey"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapFrameRenderer"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "animationInformation"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    sget-object v1, LF2/k;->e:Ljava/util/concurrent/ConcurrentHashMap;

    monitor-enter v1

    :try_start_0
    invoke-virtual {v1, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LF2/m;

    if-eqz v0, :cond_0

    invoke-virtual {v1, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, LF2/m;->a()LF2/j;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    return-object p0

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_0

    :cond_0
    :try_start_1
    sget-object p1, Ly9/A;->a:Ly9/A;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v1

    new-instance v2, LF2/g;

    iget-object v3, p0, LF2/k;->a:LW2/d;

    new-instance v5, LE2/c;

    iget p1, p0, LF2/k;->b:I

    invoke-direct {v5, p1}, LE2/c;-><init>(I)V

    iget v7, p0, LF2/k;->c:I

    move-object v4, p2

    move-object v6, p3

    invoke-direct/range {v2 .. v7}, LF2/g;-><init>(LW2/d;LB2/c;LE2/c;LA2/d;I)V

    return-object v2

    :goto_0
    monitor-exit v1

    throw p0
.end method
