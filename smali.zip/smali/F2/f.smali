.class public final synthetic LF2/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:LF2/g;

.field public final synthetic g:I

.field public final synthetic h:I


# direct methods
.method public synthetic constructor <init>(LF2/g;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF2/f;->f:LF2/g;

    iput p2, p0, LF2/f;->g:I

    iput p3, p0, LF2/f;->h:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, LF2/f;->f:LF2/g;

    iget v1, p0, LF2/f;->g:I

    iget p0, p0, LF2/f;->h:I

    invoke-static {v0, v1, p0}, LF2/g;->e(LF2/g;II)V

    return-void
.end method
