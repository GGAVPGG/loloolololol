.class public final LF2/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LF2/j;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF2/g$a;,
        LF2/g$b;
    }
.end annotation


# static fields
.field public static final n:LF2/g$b;


# instance fields
.field private final a:LW2/d;

.field private final b:LB2/c;

.field private final c:LE2/c;

.field private final d:LA2/d;

.field private final e:I

.field private final f:I

.field private final g:Ljava/util/concurrent/ConcurrentHashMap;

.field private volatile h:I

.field private volatile i:Z

.field private final j:LF2/h;

.field private k:I

.field private l:Ljava/util/Map;

.field private m:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LF2/g$b;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LF2/g$b;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, LF2/g;->n:LF2/g$b;

    return-void
.end method

.method public constructor <init>(LW2/d;LB2/c;LE2/c;LA2/d;I)V
    .locals 1

    const-string v0, "platformBitmapFactory"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "bitmapFrameRenderer"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "fpsCompressor"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "animationInformation"

    invoke-static {p4, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF2/g;->a:LW2/d;

    iput-object p2, p0, LF2/g;->b:LB2/c;

    iput-object p3, p0, LF2/g;->c:LE2/c;

    iput-object p4, p0, LF2/g;->d:LA2/d;

    iput p5, p0, LF2/g;->e:I

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object p1

    invoke-direct {p0, p1}, LF2/g;->k(LA2/d;)I

    move-result p1

    mul-int/2addr p1, p5

    div-int/lit16 p1, p1, 0x3e8

    const/4 p2, 0x1

    invoke-static {p1, p2}, LU9/g;->d(II)I

    move-result p1

    iput p1, p0, LF2/g;->f:I

    new-instance p2, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p2, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance p2, LF2/h;

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object p3

    invoke-interface {p3}, LA2/d;->c()I

    move-result p3

    invoke-direct {p2, p3}, LF2/h;-><init>(I)V

    iput-object p2, p0, LF2/g;->j:LF2/h;

    const/4 p2, -0x1

    iput p2, p0, LF2/g;->k:I

    invoke-static {}, Lz9/L;->h()Ljava/util/Map;

    move-result-object p2

    iput-object p2, p0, LF2/g;->l:Ljava/util/Map;

    invoke-static {}, Lz9/U;->d()Ljava/util/Set;

    move-result-object p2

    iput-object p2, p0, LF2/g;->m:Ljava/util/Set;

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object p2

    invoke-direct {p0, p2}, LF2/g;->k(LA2/d;)I

    move-result p2

    invoke-virtual {p0, p2}, LF2/g;->d(I)V

    int-to-float p1, p1

    const/high16 p2, 0x3f000000    # 0.5f

    mul-float/2addr p1, p2

    float-to-int p1, p1

    iput p1, p0, LF2/g;->h:I

    return-void
.end method

.method public static synthetic e(LF2/g;II)V
    .locals 0

    invoke-static {p0, p1, p2}, LF2/g;->n(LF2/g;II)V

    return-void
.end method

.method private final f(Lc2/a;)V
    .locals 1

    invoke-virtual {p1}, Lc2/a;->X0()Z

    move-result p0

    if-eqz p0, :cond_0

    new-instance p0, Landroid/graphics/Canvas;

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/Bitmap;

    invoke-direct {p0, p1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 p1, 0x0

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {p0, p1, v0}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    :cond_0
    return-void
.end method

.method private final g(IIII)Z
    .locals 10

    iget-object p4, p0, LF2/g;->j:LF2/h;

    iget v0, p0, LF2/g;->f:I

    invoke-virtual {p4, p1, v0}, LF2/h;->d(II)Ljava/util/List;

    move-result-object p1

    new-instance p4, Ljava/util/ArrayList;

    invoke-direct {p4}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    iget-object v2, p0, LF2/g;->m:Ljava/util/Set;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p4, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    invoke-static {p4}, Lz9/q;->V0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    new-instance v0, Ljava/util/ArrayDeque;

    iget-object v1, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const-string v2, "<get-keys>(...)"

    invoke-static {v1, v2}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v1, p1}, Lz9/U;->h(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayDeque;-><init>(Ljava/util/Collection;)V

    invoke-interface {p4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    iget-object v5, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_2

    goto :goto_1

    :cond_2
    iget v5, p0, LF2/g;->k:I

    const/4 v6, -0x1

    if-eq v5, v6, :cond_3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {p1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_3

    return v4

    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    if-eqz v5, :cond_4

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v6

    :cond_4
    iget-object v5, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LF2/g$a;

    const/4 v7, 0x0

    if-eqz v5, :cond_5

    invoke-virtual {v5}, LF2/g$a;->a()Lc2/a;

    move-result-object v8

    if-eqz v8, :cond_5

    invoke-virtual {v8}, Lc2/a;->t()Lc2/a;

    move-result-object v8

    goto :goto_2

    :cond_5
    move-object v8, v7

    :goto_2
    if-eqz v8, :cond_6

    goto :goto_3

    :cond_6
    new-instance v5, LF2/g$a;

    iget-object v8, p0, LF2/g;->a:LW2/d;

    invoke-virtual {v8, p2, p3}, LW2/d;->a(II)Lc2/a;

    move-result-object v8

    const-string v9, "createBitmap(...)"

    invoke-static {v8, v9}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v5, v8}, LF2/g$a;-><init>(Lc2/a;)V

    invoke-virtual {v5}, LF2/g$a;->a()Lc2/a;

    move-result-object v8

    invoke-virtual {v8}, Lc2/a;->l()Lc2/a;

    move-result-object v8

    :goto_3
    invoke-virtual {v5, v3}, LF2/g$a;->d(Z)V

    :try_start_0
    invoke-direct {p0, v8, v2, p2, p3}, LF2/g;->o(Lc2/a;III)V

    sget-object v3, Ly9/A;->a:Ly9/A;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {v8, v7}, LK9/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    iget-object v3, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v5, v4}, LF2/g$a;->d(Z)V

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget-object v3, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-interface {v3, v2, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_1

    :catchall_0
    move-exception p0

    :try_start_1
    throw p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception p1

    invoke-static {v8, p0}, LK9/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :cond_7
    invoke-interface {p4}, Ljava/util/List;->isEmpty()Z

    move-result p1

    const/high16 p2, 0x3f000000    # 0.5f

    if-eqz p1, :cond_8

    iget p1, p0, LF2/g;->f:I

    int-to-float p1, p1

    mul-float/2addr p1, p2

    float-to-int p1, p1

    goto :goto_4

    :cond_8
    invoke-interface {p4}, Ljava/util/List;->size()I

    move-result p1

    int-to-float p3, p1

    mul-float/2addr p3, p2

    float-to-int p2, p3

    sub-int/2addr p1, v3

    invoke-static {p2, v4, p1}, LU9/g;->k(III)I

    move-result p1

    invoke-interface {p4, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    :goto_4
    iput p1, p0, LF2/g;->h:I

    return v3
.end method

.method static synthetic h(LF2/g;IIIIILjava/lang/Object;)Z
    .locals 0

    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_0

    const/4 p4, 0x0

    :cond_0
    invoke-direct {p0, p1, p2, p3, p4}, LF2/g;->g(IIII)Z

    move-result p0

    return p0
.end method

.method private final i(I)LF2/a;
    .locals 5

    new-instance v0, LU9/c;

    iget-object v1, p0, LF2/g;->j:LF2/h;

    invoke-virtual {v1}, LF2/h;->b()I

    move-result v1

    const/4 v2, 0x0

    invoke-direct {v0, v2, v1}, LU9/c;-><init>(II)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_3

    move-object v1, v0

    check-cast v1, Lz9/J;

    invoke-virtual {v1}, Lz9/J;->nextInt()I

    move-result v1

    iget-object v3, p0, LF2/g;->j:LF2/h;

    sub-int v1, p1, v1

    invoke-virtual {v3, v1}, LF2/h;->a(I)I

    move-result v1

    iget-object v3, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LF2/g$a;

    if-eqz v3, :cond_2

    invoke-virtual {v3}, LF2/g$a;->b()Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_0

    :cond_1
    move-object v3, v2

    :goto_0
    if-eqz v3, :cond_2

    new-instance v2, LF2/a;

    invoke-virtual {v3}, LF2/g$a;->a()Lc2/a;

    move-result-object v3

    invoke-direct {v2, v1, v3}, LF2/a;-><init>(ILc2/a;)V

    :cond_2
    if-eqz v2, :cond_0

    :cond_3
    return-object v2
.end method

.method private final j(I)LF2/l;
    .locals 2

    invoke-direct {p0, p1}, LF2/g;->i(I)LF2/a;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-virtual {p1}, LF2/a;->d()Lc2/a;

    move-result-object v0

    invoke-virtual {v0}, Lc2/a;->l()Lc2/a;

    move-result-object v0

    const-string v1, "clone(...)"

    invoke-static {v0, v1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1}, LF2/a;->l()I

    move-result p1

    iput p1, p0, LF2/g;->k:I

    new-instance p0, LF2/l;

    sget-object p1, LF2/l$a;->g:LF2/l$a;

    invoke-direct {p0, v0, p1}, LF2/l;-><init>(Lc2/a;LF2/l$a;)V

    return-object p0

    :cond_0
    new-instance p0, LF2/l;

    const/4 p1, 0x0

    sget-object v0, LF2/l$a;->h:LF2/l$a;

    invoke-direct {p0, p1, v0}, LF2/l;-><init>(Lc2/a;LF2/l$a;)V

    return-object p0
.end method

.method private final k(LA2/d;)I
    .locals 4

    sget-object p0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v0, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/TimeUnit;->toMillis(J)J

    move-result-wide v2

    invoke-interface {p1}, LA2/d;->j()I

    move-result p0

    invoke-interface {p1}, LA2/d;->c()I

    move-result p1

    div-int/2addr p0, p1

    int-to-long p0, p0

    div-long/2addr v2, p0

    invoke-static {v2, v3, v0, v1}, LU9/g;->e(JJ)J

    move-result-wide p0

    long-to-int p0, p0

    return p0
.end method

.method private final m(II)V
    .locals 2

    iget-boolean v0, p0, LF2/g;->i:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, LF2/g;->i:Z

    sget-object v0, LE2/b;->a:LE2/b;

    new-instance v1, LF2/f;

    invoke-direct {v1, p0, p1, p2}, LF2/f;-><init>(LF2/g;II)V

    invoke-virtual {v0, v1}, LE2/b;->b(Ljava/lang/Runnable;)V

    return-void
.end method

.method private static final n(LF2/g;II)V
    .locals 9

    const-string v0, "this$0"

    invoke-static {p0, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_0
    iget v0, p0, LF2/g;->k:I

    const/4 v1, 0x0

    invoke-static {v0, v1}, LU9/g;->d(II)I

    move-result v3

    const/16 v7, 0x8

    const/4 v8, 0x0

    const/4 v6, 0x0

    move-object v2, p0

    move v4, p1

    move v5, p2

    invoke-static/range {v2 .. v8}, LF2/g;->h(LF2/g;IIIIILjava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    iput-boolean v1, v2, LF2/g;->i:Z

    return-void

    :cond_0
    move-object p0, v2

    move p1, v4

    move p2, v5

    goto :goto_0
.end method

.method private final o(Lc2/a;III)V
    .locals 4

    invoke-direct {p0, p2}, LF2/g;->i(I)LF2/a;

    move-result-object p3

    const-string p4, "get(...)"

    if-eqz p3, :cond_2

    invoke-virtual {p3}, LF2/a;->d()Lc2/a;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lc2/a;->t()Lc2/a;

    move-result-object v0

    if-eqz v0, :cond_2

    :try_start_0
    invoke-virtual {p3}, LF2/a;->l()I

    move-result p3

    const/4 v1, 0x0

    if-ge p3, p2, :cond_1

    invoke-virtual {v0}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2, p4}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v2, Landroid/graphics/Bitmap;

    invoke-direct {p0, p1, v2}, LF2/g;->p(Lc2/a;Landroid/graphics/Bitmap;)Lc2/a;

    new-instance v2, LU9/c;

    add-int/lit8 p3, p3, 0x1

    invoke-direct {v2, p3, p2}, LU9/c;-><init>(II)V

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_0

    move-object p3, p2

    check-cast p3, Lz9/J;

    invoke-virtual {p3}, Lz9/J;->nextInt()I

    move-result p3

    iget-object v2, p0, LF2/g;->b:LB2/c;

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3, p4}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v3, Landroid/graphics/Bitmap;

    invoke-interface {v2, p3, v3}, LB2/c;->c(ILandroid/graphics/Bitmap;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    invoke-static {v0, v1}, LK9/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-void

    :cond_1
    :try_start_1
    sget-object p3, Ly9/A;->a:Ly9/A;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-static {v0, v1}, LK9/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_2

    :goto_1
    :try_start_2
    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception p1

    invoke-static {v0, p0}, LK9/c;->a(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :cond_2
    :goto_2
    invoke-direct {p0, p1}, LF2/g;->f(Lc2/a;)V

    new-instance p3, LU9/c;

    const/4 v0, 0x0

    invoke-direct {p3, v0, p2}, LU9/c;-><init>(II)V

    invoke-interface {p3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_3
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_3

    move-object p3, p2

    check-cast p3, Lz9/J;

    invoke-virtual {p3}, Lz9/J;->nextInt()I

    move-result p3

    iget-object v0, p0, LF2/g;->b:LB2/c;

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, p4}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, Landroid/graphics/Bitmap;

    invoke-interface {v0, p3, v1}, LB2/c;->c(ILandroid/graphics/Bitmap;)Z

    goto :goto_3

    :cond_3
    return-void
.end method

.method private final p(Lc2/a;Landroid/graphics/Bitmap;)Lc2/a;
    .locals 2

    invoke-virtual {p1}, Lc2/a;->X0()Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0, p2}, LO9/l;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    new-instance p0, Landroid/graphics/Canvas;

    invoke-virtual {p1}, Lc2/a;->t0()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/Bitmap;

    invoke-direct {p0, v0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v0, 0x0

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {p0, v0, v1}, Landroid/graphics/Canvas;->drawColor(ILandroid/graphics/PorterDuff$Mode;)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p2, v1, v1, v0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    :cond_0
    return-object p1
.end method


# virtual methods
.method public a()V
    .locals 0

    invoke-static {p0}, LF2/j$a;->a(LF2/j;)V

    return-void
.end method

.method public b(IILN9/a;)V
    .locals 1

    const-string v0, "onAnimationLoaded"

    invoke-static {p3, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0, p1, p2}, LF2/g;->m(II)V

    invoke-interface {p3}, LN9/a;->invoke()Ljava/lang/Object;

    return-void
.end method

.method public c(III)LF2/l;
    .locals 4

    iget-object v0, p0, LF2/g;->l:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iput p1, p0, LF2/g;->k:I

    iget-object v1, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LF2/g$a;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LF2/g$a;->b()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    move-object v0, v1

    :goto_0
    if-eqz v0, :cond_2

    iget-object v1, p0, LF2/g;->j:LF2/h;

    iget v2, p0, LF2/g;->h:I

    iget v3, p0, LF2/g;->f:I

    invoke-virtual {v1, v2, p1, v3}, LF2/h;->c(III)Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-direct {p0, p2, p3}, LF2/g;->m(II)V

    :cond_1
    new-instance p0, LF2/l;

    invoke-virtual {v0}, LF2/g$a;->a()Lc2/a;

    move-result-object p1

    invoke-virtual {p1}, Lc2/a;->l()Lc2/a;

    move-result-object p1

    sget-object p2, LF2/l$a;->f:LF2/l$a;

    invoke-direct {p0, p1, p2}, LF2/l;-><init>(Lc2/a;LF2/l$a;)V

    return-object p0

    :cond_2
    invoke-direct {p0, p2, p3}, LF2/g;->m(II)V

    invoke-direct {p0, p1}, LF2/g;->j(I)LF2/l;

    move-result-object p0

    return-object p0

    :cond_3
    invoke-direct {p0, p1}, LF2/g;->j(I)LF2/l;

    move-result-object p0

    return-object p0
.end method

.method public clear()V
    .locals 2

    iget-object v0, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    const-string v1, "<get-values>(...)"

    invoke-static {v0, v1}, LO9/l;->f(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LF2/g$a;

    invoke-virtual {v1}, LF2/g$a;->c()V

    goto :goto_0

    :cond_0
    iget-object v0, p0, LF2/g;->g:Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->clear()V

    const/4 v0, -0x1

    iput v0, p0, LF2/g;->k:I

    return-void
.end method

.method public d(I)V
    .locals 4

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object v0

    invoke-interface {v0}, LA2/d;->j()I

    move-result v0

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object v1

    invoke-interface {v1}, LA2/d;->d()I

    move-result v1

    const/4 v2, 0x1

    invoke-static {v1, v2}, LU9/g;->d(II)I

    move-result v1

    mul-int/2addr v0, v1

    iget-object v1, p0, LF2/g;->c:LE2/c;

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object v2

    invoke-interface {v2}, LA2/d;->c()I

    move-result v2

    invoke-virtual {p0}, LF2/g;->l()LA2/d;

    move-result-object v3

    invoke-direct {p0, v3}, LF2/g;->k(LA2/d;)I

    move-result v3

    invoke-static {p1, v3}, LU9/g;->h(II)I

    move-result p1

    invoke-virtual {v1, v0, v2, p1}, LE2/c;->a(III)Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, LF2/g;->l:Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    invoke-static {p1}, Lz9/q;->V0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object p1

    iput-object p1, p0, LF2/g;->m:Ljava/util/Set;

    return-void
.end method

.method public l()LA2/d;
    .locals 0

    iget-object p0, p0, LF2/g;->d:LA2/d;

    return-object p0
.end method
