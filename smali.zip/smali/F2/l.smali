.class public final LF2/l;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LF2/l$a;
    }
.end annotation


# instance fields
.field private final a:Lc2/a;

.field private final b:LF2/l$a;


# direct methods
.method public constructor <init>(Lc2/a;LF2/l$a;)V
    .locals 1

    const-string v0, "type"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF2/l;->a:Lc2/a;

    iput-object p2, p0, LF2/l;->b:LF2/l$a;

    return-void
.end method


# virtual methods
.method public final a()Lc2/a;
    .locals 0

    iget-object p0, p0, LF2/l;->a:Lc2/a;

    return-object p0
.end method

.method public final b()LF2/l$a;
    .locals 0

    iget-object p0, p0, LF2/l;->b:LF2/l$a;

    return-object p0
.end method
