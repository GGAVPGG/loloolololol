.class public final LF2/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field private f:I

.field private final g:Lc2/a;


# direct methods
.method public constructor <init>(ILc2/a;)V
    .locals 1

    const-string v0, "bitmap"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LF2/a;->f:I

    iput-object p2, p0, LF2/a;->g:Lc2/a;

    return-void
.end method


# virtual methods
.method public close()V
    .locals 0

    iget-object p0, p0, LF2/a;->g:Lc2/a;

    invoke-virtual {p0}, Lc2/a;->close()V

    return-void
.end method

.method public final d()Lc2/a;
    .locals 0

    iget-object p0, p0, LF2/a;->g:Lc2/a;

    return-object p0
.end method

.method public final l()I
    .locals 0

    iget p0, p0, LF2/a;->f:I

    return p0
.end method
