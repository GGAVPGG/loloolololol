.class final LF2/m;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:LF2/j;

.field private final b:Ljava/util/Date;


# direct methods
.method public constructor <init>(LF2/j;Ljava/util/Date;)V
    .locals 1

    const-string v0, "frameLoader"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "insertedTime"

    invoke-static {p2, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF2/m;->a:LF2/j;

    iput-object p2, p0, LF2/m;->b:Ljava/util/Date;

    return-void
.end method


# virtual methods
.method public final a()LF2/j;
    .locals 0

    iget-object p0, p0, LF2/m;->a:LF2/j;

    return-object p0
.end method

.method public final b()Ljava/util/Date;
    .locals 0

    iget-object p0, p0, LF2/m;->b:Ljava/util/Date;

    return-object p0
.end method
