.class final LF2/g$a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF2/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field private final a:Lc2/a;

.field private b:Z


# direct methods
.method public constructor <init>(Lc2/a;)V
    .locals 1

    const-string v0, "bitmapRef"

    invoke-static {p1, v0}, LO9/l;->g(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LF2/g$a;->a:Lc2/a;

    return-void
.end method


# virtual methods
.method public final a()Lc2/a;
    .locals 0

    iget-object p0, p0, LF2/g$a;->a:Lc2/a;

    return-object p0
.end method

.method public final b()Z
    .locals 1

    iget-boolean v0, p0, LF2/g$a;->b:Z

    if-nez v0, :cond_0

    iget-object p0, p0, LF2/g$a;->a:Lc2/a;

    invoke-virtual {p0}, Lc2/a;->X0()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final c()V
    .locals 0

    iget-object p0, p0, LF2/g$a;->a:Lc2/a;

    invoke-static {p0}, Lc2/a;->a0(Lc2/a;)V

    return-void
.end method

.method public final d(Z)V
    .locals 0

    iput-boolean p1, p0, LF2/g$a;->b:Z

    return-void
.end method
