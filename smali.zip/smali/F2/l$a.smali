.class public final enum LF2/l$a;
.super Ljava/lang/Enum;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LF2/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "a"
.end annotation


# static fields
.field public static final enum f:LF2/l$a;

.field public static final enum g:LF2/l$a;

.field public static final enum h:LF2/l$a;

.field private static final synthetic i:[LF2/l$a;

.field private static final synthetic j:Lkotlin/enums/EnumEntries;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    new-instance v0, LF2/l$a;

    const-string v1, "SUCCESS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, LF2/l$a;-><init>(Ljava/lang/String;I)V

    sput-object v0, LF2/l$a;->f:LF2/l$a;

    new-instance v0, LF2/l$a;

    const-string v1, "NEAREST"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, LF2/l$a;-><init>(Ljava/lang/String;I)V

    sput-object v0, LF2/l$a;->g:LF2/l$a;

    new-instance v0, LF2/l$a;

    const-string v1, "MISSING"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, LF2/l$a;-><init>(Ljava/lang/String;I)V

    sput-object v0, LF2/l$a;->h:LF2/l$a;

    invoke-static {}, LF2/l$a;->c()[LF2/l$a;

    move-result-object v0

    sput-object v0, LF2/l$a;->i:[LF2/l$a;

    invoke-static {v0}, LG9/a;->a([Ljava/lang/Enum;)Lkotlin/enums/EnumEntries;

    move-result-object v0

    sput-object v0, LF2/l$a;->j:Lkotlin/enums/EnumEntries;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method private static final synthetic c()[LF2/l$a;
    .locals 3

    sget-object v0, LF2/l$a;->f:LF2/l$a;

    sget-object v1, LF2/l$a;->g:LF2/l$a;

    sget-object v2, LF2/l$a;->h:LF2/l$a;

    filled-new-array {v0, v1, v2}, [LF2/l$a;

    move-result-object v0

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)LF2/l$a;
    .locals 1

    const-class v0, LF2/l$a;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, LF2/l$a;

    return-object p0
.end method

.method public static values()[LF2/l$a;
    .locals 1

    sget-object v0, LF2/l$a;->i:[LF2/l$a;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [LF2/l$a;

    return-object v0
.end method
