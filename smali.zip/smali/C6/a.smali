.class public LC6/a;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        LC6/a$l;,
        LC6/a$k;,
        LC6/a$j;,
        LC6/a$g;,
        LC6/a$d;,
        LC6/a$f;,
        LC6/a$i;,
        LC6/a$h;,
        LC6/a$e;,
        LC6/a$c;,
        LC6/a$b;,
        LC6/a$a;
    }
.end annotation


# instance fields
.field private final a:LD6/a;

.field private final b:Landroid/graphics/Rect;

.field private final c:[Landroid/graphics/Point;


# direct methods
.method public constructor <init>(LD6/a;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, p1, v0}, LC6/a;-><init>(LD6/a;Landroid/graphics/Matrix;)V

    return-void
.end method

.method public constructor <init>(LD6/a;Landroid/graphics/Matrix;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, LP4/p;->k(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LD6/a;

    iput-object v0, p0, LC6/a;->a:LD6/a;

    .line 3
    invoke-interface {p1}, LD6/a;->c()Landroid/graphics/Rect;

    move-result-object v0

    if-eqz v0, :cond_0

    if-eqz p2, :cond_0

    .line 4
    invoke-static {v0, p2}, LI6/b;->c(Landroid/graphics/Rect;Landroid/graphics/Matrix;)V

    :cond_0
    iput-object v0, p0, LC6/a;->b:Landroid/graphics/Rect;

    .line 5
    invoke-interface {p1}, LD6/a;->k()[Landroid/graphics/Point;

    move-result-object p1

    if-eqz p1, :cond_1

    if-eqz p2, :cond_1

    .line 6
    invoke-static {p1, p2}, LI6/b;->b([Landroid/graphics/Point;Landroid/graphics/Matrix;)V

    :cond_1
    iput-object p1, p0, LC6/a;->c:[Landroid/graphics/Point;

    return-void
.end method


# virtual methods
.method public a()LC6/a$c;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->e()LC6/a$c;

    move-result-object p0

    return-object p0
.end method

.method public b()LC6/a$d;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->h()LC6/a$d;

    move-result-object p0

    return-object p0
.end method

.method public c()[Landroid/graphics/Point;
    .locals 0

    iget-object p0, p0, LC6/a;->c:[Landroid/graphics/Point;

    return-object p0
.end method

.method public d()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->i()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public e()LC6/a$e;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->b()LC6/a$e;

    move-result-object p0

    return-object p0
.end method

.method public f()LC6/a$f;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->l()LC6/a$f;

    move-result-object p0

    return-object p0
.end method

.method public g()I
    .locals 2

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->getFormat()I

    move-result p0

    const/16 v0, 0x1000

    const/4 v1, -0x1

    if-gt p0, v0, :cond_1

    if-nez p0, :cond_0

    return v1

    :cond_0
    return p0

    :cond_1
    return v1
.end method

.method public h()LC6/a$g;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->m()LC6/a$g;

    move-result-object p0

    return-object p0
.end method

.method public i()LC6/a$i;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->a()LC6/a$i;

    move-result-object p0

    return-object p0
.end method

.method public j()[B
    .locals 1

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->j()[B

    move-result-object p0

    if-eqz p0, :cond_0

    array-length v0, p0

    invoke-static {p0, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p0

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public k()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public l()LC6/a$j;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->g()LC6/a$j;

    move-result-object p0

    return-object p0
.end method

.method public m()LC6/a$k;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->getUrl()LC6/a$k;

    move-result-object p0

    return-object p0
.end method

.method public n()I
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->f()I

    move-result p0

    return p0
.end method

.method public o()LC6/a$l;
    .locals 0

    iget-object p0, p0, LC6/a;->a:LD6/a;

    invoke-interface {p0}, LD6/a;->n()LC6/a$l;

    move-result-object p0

    return-object p0
.end method
