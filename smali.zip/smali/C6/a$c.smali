.class public LC6/a$c;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = LC6/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/String;

.field private final c:Ljava/lang/String;

.field private final d:Ljava/lang/String;

.field private final e:Ljava/lang/String;

.field private final f:LC6/a$b;

.field private final g:LC6/a$b;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LC6/a$b;LC6/a$b;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LC6/a$c;->a:Ljava/lang/String;

    iput-object p2, p0, LC6/a$c;->b:Ljava/lang/String;

    iput-object p3, p0, LC6/a$c;->c:Ljava/lang/String;

    iput-object p4, p0, LC6/a$c;->d:Ljava/lang/String;

    iput-object p5, p0, LC6/a$c;->e:Ljava/lang/String;

    iput-object p6, p0, LC6/a$c;->f:LC6/a$b;

    iput-object p7, p0, LC6/a$c;->g:LC6/a$b;

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LC6/a$c;->b:Ljava/lang/String;

    return-object p0
.end method

.method public b()LC6/a$b;
    .locals 0

    iget-object p0, p0, LC6/a$c;->g:LC6/a$b;

    return-object p0
.end method

.method public c()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LC6/a$c;->c:Ljava/lang/String;

    return-object p0
.end method

.method public d()LC6/a$b;
    .locals 0

    iget-object p0, p0, LC6/a$c;->f:LC6/a$b;

    return-object p0
.end method

.method public e()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, LC6/a$c;->a:Ljava/lang/String;

    return-object p0
.end method
